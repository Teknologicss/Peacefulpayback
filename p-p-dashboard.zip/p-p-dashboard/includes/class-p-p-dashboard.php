<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://www.teknologics.net
 * @since      1.0.0
 *
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/includes
 * @author     Joshua Victor <joshua.teknologics@gmail.com>
 */
class P_P_Dashboard {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      P_P_Dashboard_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function __construct() {
        if (defined('P_P_DASHBOARD_VERSION')) {
            $this->version = P_P_DASHBOARD_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'p-p-dashboard';

        $this->load_dependencies();
        $this->load_shortcodes();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    public function load_shortcodes() {


        /**
         * Adding plugin shortcodes
         * 
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/shortcodes/pp-signin-shortcode.php';

        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/shortcodes/pp-signup-shortcode.php';

        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/shortcodes/pp-dashboard-shortcode.php';
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * Include the following files that make up the plugin:
     *
     * - P_P_Dashboard_Loader. Orchestrates the hooks of the plugin.
     * - P_P_Dashboard_i18n. Defines internationalization functionality.
     * - P_P_Dashboard_Admin. Defines all hooks for the admin area.
     * - P_P_Dashboard_Public. Defines all hooks for the public side of the site.
     *
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {

        /**
         * The class responsible for orchestrating the actions and filters of the
         * core plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-p-p-dashboard-loader.php';

        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-p-p-dashboard-i18n.php';
        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/p-p-dashboard-functions.php';
        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/pp-dashboard-html.php';

        /**
         * The class responsible for defining all actions that occur in the admin area.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-p-p-dashboard-admin.php';

        /**
         * The class responsible for defining all actions that occur in the public-facing
         * side of the site.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'public/class-p-p-dashboard-public.php';

        $this->loader = new P_P_Dashboard_Loader();
    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * Uses the P_P_Dashboard_i18n class in order to set the domain and to register the hook
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function set_locale() {

        $plugin_i18n = new P_P_Dashboard_i18n();

        $this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks() {

        $plugin_admin = new P_P_Dashboard_Admin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');




        //add_filter('current_screen', array($this, 'pp_dashboard_current_screen'));
    }

    public function pp_dashboard_current_screen() {

        $pp_current_screen = get_current_screen();
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks() {

        $plugin_public = new P_P_Dashboard_Public($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');

        add_filter('template_include', array($this, 'pp_templates_pages'));
        add_filter('theme_page_templates', array($this, 'pp_page_templates_callback'), 1, 1);

        //add_filter('body_class', array($this, 'wpdocs_sp_body_class'),10);


        //pp-dashboard.php
    }

    public function wpdocs_sp_body_class($classes) {
        //die();
        $templates = array('pp-signin.php', 'pp-signup.php', 'pp-dashboard.php');

        if (is_page_template($templates)) {
            $classes[] = 'your-custom-class'; // add your class here
        }
    }

    public function pp_page_templates_callback($page_templates) {

        $page_templates['pp-signin.php'] = __('P P Signin', 'wp-jobsearch');
        $page_templates['pp-signup.php'] = __('P P Signup', 'wp-jobsearch');
        $page_templates['pp-dashboard.php'] = __('P P Dashboard', 'wp-jobsearch');

        return $page_templates;
    }

    /*
     * Adding Single templates
     */

    public function pp_templates_pages($single_template) {

        global $post;

        if (!isset($post)) {

            return $single_template;
        }


        if ('pp-signin.php' === get_post_meta($post->ID, '_wp_page_template', true)) {

            $template_file = plugin_dir_path(__FILE__) . 'page-templates/pp-signin.php';

            add_filter('show_admin_bar', '__return_false');


            if (file_exists($template_file)) {
                return $template_file;
            }
        }

        if ('pp-signup.php' === get_post_meta($post->ID, '_wp_page_template', true)) {

            $template_file = plugin_dir_path(__FILE__) . 'page-templates/pp-signup.php';

            add_filter('show_admin_bar', '__return_false');

            if (file_exists($template_file)) {
                return $template_file;
            }
        }

        if ('pp-dashboard.php' === get_post_meta($post->ID, '_wp_page_template', true)) {

            $template_file = plugin_dir_path(__FILE__) . 'page-templates/pp-dashboard.php';

            add_filter('show_admin_bar', '__return_false');

            if (file_exists($template_file)) {
                return $template_file;
            }
        }

        return $single_template;
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since     1.0.0
     * @return    string    The name of the plugin.
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since     1.0.0
     * @return    P_P_Dashboard_Loader    Orchestrates the hooks of the plugin.
     */
    public function get_loader() {
        return $this->loader;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since     1.0.0
     * @return    string    The version number of the plugin.
     */
    public function get_version() {
        return $this->version;
    }

}

if (!function_exists('pp_dashboard_user_authentication')) {

    function pp_dashboard_user_authentication($user, $password) {

        $user_status = get_user_meta($user->ID, 'cosigner_user_status', true);

        if (isset($user_status) && $user_status == 'pending') {

            $not_verified = new WP_Error('not_verified_user', __('<strong>ERROR</strong>: Your account is not verified yet.', 'pp-dashboard'));
            return $not_verified;
        }
        return $user;
    }

}
add_filter('wp_authenticate_user', 'pp_dashboard_user_authentication', 10, 2);
