<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.teknologics.net
 * @since      1.0.0
 *
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/includes
 * @author     Joshua Victor <joshua.teknologics@gmail.com>
 */
class P_P_Dashboard_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
