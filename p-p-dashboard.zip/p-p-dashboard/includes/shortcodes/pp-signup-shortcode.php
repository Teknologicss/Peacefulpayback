<?php

/*
 * Peaceful Payback Signup
 */


add_shortcode('pp_signup', 'pp_signup_shortcode_callback');

function pp_signup_shortcode_callback($atts) {
    
    $atts = shortcode_atts(array(
        'foo' => 'no foo',
        'baz' => 'default baz'
            ), $atts, 'pp_signup');
    

    echo  "foo = {$atts['foo']}";
}
