<?php

/*
 * Peaceful Payback Dashboard
 */


add_shortcode('pp_dashboard', 'pp_dashboard_shortcode_callback');

function pp_dashboard_shortcode_callback($atts) {
    
    $atts = shortcode_atts(array(
        'foo' => 'no foo',
        'baz' => 'default baz'
            ), $atts, 'pp_dashboard');
    

    echo  "foo = {$atts['foo']}";
}
