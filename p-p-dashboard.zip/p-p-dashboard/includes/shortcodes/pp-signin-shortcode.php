<?php

/*
 * Peaceful Payback Signin
 */


add_shortcode('pp_signin', 'pp_signin_shortcode_callback');

function pp_signin_shortcode_callback($atts) {
    
    $atts = shortcode_atts(array(
        'foo' => 'no foo',
        'baz' => 'default baz'
            ), $atts, 'pp_signin');
    

    echo  "foo = {$atts['foo']}";
}
