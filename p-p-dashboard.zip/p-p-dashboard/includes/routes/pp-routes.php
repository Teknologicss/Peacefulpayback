<?php
if (!defined('WPINC')) {
    die;
}

/**
 * Responsible for pp routes
 * Signin/signup/dashboard
 * 
 */
class P_P_Dashboard_Routes {

    public function __construct() {
        add_action('rest_api_init', array($this, 'pp_dashboard_register_routes'));
    }

    public function pp_dashboard_register_routes() {

        register_rest_route('p-p-dashboard/v1', '/cosigner-register', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_cosigner_register'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/cosigner-signin', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_cosigner_signin'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/dashboard', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_actions'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/load-more', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_load_more_posts'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/course-detail', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_course_detail'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/add-borrower', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_register_borrower'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/update-profile', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_update_profile'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/search', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_search_data'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/get-course', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_get_course'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/password-update', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_password_update'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));

        register_rest_route('p-p-dashboard/v1', '/forgot-password', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'pp_dashboard_forgot_password'),
            'permission_callback' => function () {
                return array($this, 'pp_dashboard_auth_callback');
            },
        ));
    }

    public function pp_dashboard_invalid_security_token() {

        return esc_html__('Invalid security token sent....', 'pp-dashboard');
    }

    public function pp_dashboard_auth_callback() {
        return __return_true;
    }

    public function pp_dashboard_forgot_password(WP_REST_Request $request) {

        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return array('status' => 'error', 'message' => $this->pp_dashboard_invalid_security_token());
        }


        $password_data = array();

        parse_str($get_parms['password_data'], $password_data);

        $reset_email = $password_data['registered_email'];


        if ($reset_email == '') {

            return array(
                'status' => 'error',
                'message' => __('Email cannot be empty.', 'pp-dashboard'),
            );
        }

        if (!filter_var($reset_email, FILTER_VALIDATE_EMAIL)) {

            return array(
                'status' => 'error',
                'message' => __('Invalid email address', 'pp-dashboard'),
            );
        }

        if (!email_exists($reset_email)) {
            return array(
                'status' => 'error',
                'message' => __('Email is not registered.', 'pp-dashboard'),
            );
        }


        $user_data = get_user_by('email', $reset_email);


        /*
         * password Generation
         */

        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';

        $pass = array();
        $random_pass = '';

        $alphaLength = strlen($alphabet) - 1;

        for ($i = 0; $i < 8; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        $random_pass = implode($pass);

        /*
         * Mail to user
         */

        $template_title = $user_data->data->display_name;

        $pp_dashboard_logo = P_P_DASHBOARD_PLUGIN_URL . 'public/images/logo.png';

        $template_message = 'Your Password Reset Successfully.';
        $template_email = sprintf(__('User Email : %s', 'pp-dashboard'), $reset_email);
        $template_password = sprintf(__('Your Changed Password is : %s', 'pp-dashboard'), $random_pass);

        $html_user_template = '<!DOCTYPE html>
                                <html>
                                   <head>
                                      <title>' . __("User Registeration", "pp-dashboard") . '</title>
                                   </head>
                                   <body>
                                      <table class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #f6f6f6; width: 100%;" border="0" cellspacing="0" cellpadding="0">
                                         <tbody>
                                            <tr>
                                               <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;"></td>
                                               <td class="container" style="font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 580px; padding: 10px; width: 580px; margin: 0 auto !important;">
                                                  <div class="content" style="box-sizing: border-box; display: block; margin: 0 auto; max-width: 580px; padding: 10px;">
                                                     <table class="main" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background: #fff; border-radius: 3px; width: 100%;">
                                                        <tbody>
                                                           <tr>
                                                              <td class="wrapper" style="font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 20px;">
                                                                 <table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;" border="0" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                       <tr style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                                          <td class="alert" style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 16px; vertical-align: top; color: #000; font-weight: 500; text-align: center; border-radius: 3px 3px 0 0; background-color: #fff; margin: 0; padding: 20px;" align="center" valign="top" bgcolor="#fff">
                                                                             <img class="alignnone size-full wp-image-1437" src="' . $pp_dashboard_logo . '" width="80" height="80" alt="site logo"/>
                                                                          </td>
                                                                       </tr>
                                                                       <tr>
                                                                          <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;"><span style="font-family: sans-serif; font-weight: normal;">Hello </span><span style="font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;"><b> ' . $template_title . ',</b></span></p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $template_message . '</p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $template_email . '</p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $template_password . '</p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;"><strong>Thanks!</strong>
                                                                          </td>
                                                                       </tr>
                                                                    </tbody>
                                                                 </table>
                                                              </td>
                                                           </tr>
                                                        </tbody>
                                                     </table>                     
                                                     &nbsp;
                                                  </div>
                                               </td>               
                                            </tr>
                                         </tbody>
                                      </table>
                                   </body>
                                </html>';

        
        $subject_user = 'Forgot Password Reset';
        $from_d = get_bloginfo('name') . ' <' . get_option('admin_email') . '>';
        $headers = array('Content-Type: text/html; charset=UTF-8', 'From: ' . $from_d . '');

        if (wp_mail($reset_email, $subject_user, $html_user_template, $headers)) {

            wp_set_password($random_pass, $user_data->data->ID);
            
            return array(
                'status' => 'success',
                'message' => __('Please check you mail for login information.', 'pp-dashboard'),
            );
            
        } else {

            return array(
                'status' => 'error',
                'message' => __('Something went wrong please check your mail information.', 'pp-dashboard'),
            );
        }
    }

    public function pp_dashboard_password_update(WP_REST_Request $request) {

        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return array('status' => 'error', 'message' => $this->pp_dashboard_invalid_security_token());
        }

        global $PPDashboard_options;

        $PPDashboard_options = get_option('p-p-dash-options');
        $pp_signin_page = isset($PPDashboard_options['pp-signin-page']) && $PPDashboard_options['pp-signin-page'] != '' ? get_the_permalink($PPDashboard_options['pp-signin-page']) : 'javascript:void(0)';

        $password_data = array();

        parse_str($get_parms['password_data'], $password_data);

        if (trim($password_data['old_pass']) == '') {

            return array(
                'status' => 'error',
                'message' => __('Old Password cannot be empty.', 'pp-dashboard'),
            );
        }

        if (trim($password_data['new_pass']) == '') {

            return array(
                'status' => 'error',
                'message' => __('New Password cannot be empty.', 'pp-dashboard'),
            );
        }

        if (trim($password_data['retype_pass']) == '') {

            return array(
                'status' => 'error',
                'message' => __('Re Password cannot be empty.', 'pp-dashboard'),
            );
        }



        if ($password_data['new_pass'] <> $password_data['retype_pass']) {

            return array(
                'status' => 'error',
                'message' => __('New Password do not match.', 'pp-dashboard'),
            );
        }

        //echo '(('.$password_data['cosigner_id'].'))';

        $user_data = get_user_by('ID', $password_data['cosigner_id']);

        if ($user_data && wp_check_password($password_data['old_pass'], $user_data->data->user_pass, $user_data->data->ID)) {

            wp_set_password($password_data['new_pass'], $password_data['cosigner_id']);

            return array(
                'status' => 'success',
                'message' => __('User Password Updated.', 'pp-dashboard'),
                'redirect' => $pp_signin_page,
            );
        } else {

            return array(
                'status' => 'error',
                'message' => __('Current Password issue.', 'pp-dashboard'),
            );
        }
    }

    public function pp_dashboard_get_course(WP_REST_Request $request) {

        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';

        $display_course = (isset($get_parms['display_course'])) ? $get_parms['display_course'] : '';
        $course_id = (isset($get_parms['course_id'])) ? $get_parms['course_id'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return array('status' => 'error', 'message' => $this->pp_dashboard_invalid_security_token());
        }


        ob_start();
        pp_course_detail_html($course_id, $display_course);
        $course_html = ob_get_contents();
        ob_end_clean();





        return array(
            'status' => 'success',
            'course_html' => $course_html,
        );
    }

    public function pp_dashboard_search_data(WP_REST_Request $request) {

        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';
        $search_key = (isset($get_parms['search_key'])) ? $get_parms['search_key'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return array('status' => 'error', 'message' => $this->pp_dashboard_invalid_security_token());
        }

        $action_val = 'search';

        ob_start();
        pp_dashboard_nav_html($action_val);
        $das_nav_html = ob_get_contents();
        ob_end_clean();

        ob_start();
        pp_search_html($search_key);
        $html_content = ob_get_contents();
        ob_end_clean();



        return array(
            'status' => 'success',
            'content_html' => $html_content,
            'nav_html' => $das_nav_html,
        );
    }

    public function pp_dashboard_update_profile(WP_REST_Request $request) {

        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            $return = array('success' => false, 'data' => '', 'message' => $this->pp_dashboard_invalid_security_token());
            wp_send_json_error($return);
        }

        $cosigner_data = array();
        parse_str($get_parms['cosigner_data'], $cosigner_data);

        $cosigner_id = $cosigner_data['cosigner_id'];

        if (isset($cosigner_data) && $cosigner_data != '') {

            foreach ($cosigner_data as $cosigner_key => $cosigner_val) {

                if ($cosigner_val == '') {

                    return array(
                        'status' => 'error',
                        'message' => 'Seems some of form fields are empty.',
                    );

                    break;
                }
            }

            foreach ($cosigner_data as $cosigner_key => $cosigner_val) {

                if ($cosigner_key == 'cosigner_id') {
                    continue;
                }

                update_post_meta($cosigner_id, $cosigner_key, $cosigner_val);
            }

            return array(
                'status' => 'success',
                'message' => 'Profile Data Updated Successfully.',
            );
        }
    }

    public function pp_dashboard_register_borrower(WP_REST_Request $request) {


        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            $return = array('success' => false, 'data' => '', 'message' => $this->pp_dashboard_invalid_security_token());
            wp_send_json_error($return);
        }

        $borrower_data = array();
        parse_str($get_parms['borrower_data'], $borrower_data);




//        global $PPDashboard_options;
//
//        $PPDashboard_options = get_option('p-p-dash-options');
//
//        $pp_admin_email = isset($PPDashboard_options['pp-cosigner-admin-mail']) && $PPDashboard_options['pp-cosigner-admin-mail'] != '' ? $PPDashboard_options['pp-cosigner-admin-mail'] : get_option('admin_email');

        if (isset($borrower_data) && $borrower_data != '') {

            foreach ($borrower_data as $borrower_key => $borrower_val) {

                if ($borrower_val == '') {

                    return array(
                        'status' => 'error',
                        'message' => 'Seems some of form fields are empty.',
                    );

                    break;
                }
            }
        }



        /*
         * Insert new Client post
         */

        $post_params = array(
            'post_title' => wp_strip_all_tags($borrower_data['bowrer_name']),
            'post_status' => 'pending',
            'post_type' => 'pp-client',
            'post_author' => $borrower_data['pp_cosigner_id'],
        );

        $client_id = wp_insert_post($post_params);

        if (is_wp_error($client_id)) {

            return array(
                'status' => 'error',
                'message' => $client_id->get_error_message(),
            );
        } else {

            if (isset($borrower_data) && $borrower_data != '') {

                foreach ($borrower_data as $borrower_key => $borrower_val) {

                    update_post_meta($client_id, $borrower_key, $borrower_val);
                }
            }

            return array(
                'status' => 'success',
                'message' => __('You\'re successfully added a borrower please wait till the admin approval.', 'pp-dashboard'),
            );
        }
    }

    public function pp_dashboard_course_detail(WP_REST_Request $request) {


        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';
        $course_id = (isset($get_parms['course_id'])) ? $get_parms['course_id'] : '';
        $redirection = (isset($get_parms['redirection'])) ? $get_parms['redirection'] : '';


        if (!wp_verify_nonce($nonce, 'wp_rest')) {

            $return = array('success' => false, 'data' => '', 'message' => $this->pp_dashboard_invalid_security_token());
            wp_send_json_error($return);
        }

        $course_detail_html = '';

        ob_start();
        echo
        pp_course_detail_html($course_id);
        $course_detail_html = ob_get_contents();
        ob_end_clean();

        $course_nav_html = '';

        ob_start();
        pp_dashboard_course_nav_html($course_id, $redirection);
        $course_nav_html = ob_get_contents();
        ob_end_clean();


        return array(
            'status' => 'success',
            'message' => 'successfully ',
            'content_html' => $course_detail_html,
            'nav_html' => $course_nav_html,
        );
    }

    public function pp_dashboard_load_more_posts(WP_REST_Request $request) {


        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';
        $post_type = (isset($get_parms['post_type'])) ? $get_parms['post_type'] : '';
        $page = (isset($get_parms['page'])) ? $get_parms['page'] : '';
        $offset = (isset($get_parms['offset'])) ? $get_parms['offset'] : '';
        $number = (isset($get_parms['number'])) ? $get_parms['number'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            $return = array('success' => false, 'data' => '', 'message' => $this->pp_dashboard_invalid_security_token());
            wp_send_json_error($return);
        }


        ob_start();

        $page = $page >= 1 ? ($page + 1) : 1;

        $offset = ( $page - 1 ) * $number;


        $load_more_args = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => $number,
            'order' => 'DESC',
            'orderby' => 'date',
            'fields' => 'ids',
            //'number' => $display_count,
            'page' => $page,
            'offset' => $offset
        );

        //print_r($load_more_args);

        $load_more_query = new WP_Query($load_more_args);

        // The Loop
        if ($load_more_query->have_posts()) :
            while ($load_more_query->have_posts()) : $load_more_query->the_post();

                global $post;

                if ($post_type == 'pp-meeting') {

                    $meeting_price = get_post_meta($post, 'meeting_price', true);
                    $meeting_price = isset($meeting_price) && $meeting_price != '' ? $meeting_price : '';

                    $meeting_client_name = get_post_meta($post, 'meeting_client_name', true);
                    $meeting_client_name = isset($meeting_client_name) && $meeting_client_name != '' ? $meeting_client_name : '';

                    $meeting_location = get_post_meta($post, 'meeting_location', true);
                    $meeting_location = isset($meeting_location) && $meeting_location != '' ? $meeting_location : '';

                    $meeting_link = get_post_meta($post, 'meeting_link', true);
                    $meeting_link = isset($meeting_link) && $meeting_link != '' ? $meeting_link : '';
                    ?>
                    <div class="pp-upcoming-meetings-card col-lg-7">

                        <div class="pp-date">
                            <div>
                                <p><?php echo get_the_date('D'); ?></p>
                                <span><?php echo get_the_date('j'); ?></span>
                            </div>
                        </div>
                        <div class="pp-meeting-informations d-flex flex-column ml-3">
                            <h1><?php echo get_the_title($post); ?></h1>
                            <p>
                                <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/credit card.svg" alt="" />
                    <?php if ($meeting_price != '') { ?>
                                    <span>Price: <?php echo $meeting_price; ?></span>
                                <?php } ?>
                            </p>
                            <p class="pp-clients">
                                <span class="pp-client-name">Client: <?php echo $meeting_client_name; ?></span>
                                <span class="pp-location">
                                    Location: <?php echo $meeting_location; ?>
                                </span>
                            </p>
                        </div>
                    <?php if ($meeting_link != '') { ?>
                            <div class="pp-join-meeting">
                                <a href="<?php echo $meeting_link; ?>" class="" download id="pp-join-meeting"> Join </a>
                            </div>
                    <?php } ?>

                    </div>
                        <?php
                    } else {

                        $course_author = get_post_meta($post, 'course_author', true);
                        $course_author = isset($course_author) && $course_author != '' ? $course_author : '';

                        $course_tagline = get_post_meta($post, 'course_tagline', true);
                        $course_tagline = isset($course_tagline) && $course_tagline != '' ? $course_tagline : '';

                        $course_hours = get_post_meta($post, 'course_hours', true);
                        $course_hours = isset($course_hours) && $course_hours != '' ? $course_hours : '';

                        $course_img_url = get_the_post_thumbnail_url($post, 'thumbnail');
                        ?>
                    <div class="col-md-6">
                        <div class="pp-upcomming-courses-cards">
                            <img src="<?php echo $course_img_url; ?>" alt="" />
                            <div class="pp-course-outline">
                                <div class="pp-course-name">
                                    <div class="pp-swiper-text d-flex gap-2">
                                        <p><?php echo get_the_title($post); ?></p>
                                    </div>
                                    <div class="pp-time">
                                        <span><?php echo $course_hours; ?></span>
                                    </div>
                                </div>
                                <p class="pp-offered-by">By <?php echo $course_author; ?></p>
                                <div class="pp-overveiw">
                                    <p class="mb-0"><?php echo $course_tagline; ?></p>                                    
                                    <a href="javascript:void(0)" data-course-id="<?php echo $post; ?>" class="pp-course-det" data-redirect="courses"> Explore </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }


            endwhile;
        endif;
        // Reset Post Data
        wp_reset_postdata();


        $load_more_content = ob_get_contents();
        ob_end_clean();


        if ($load_more_content == "") {
            return array(
                'status' => 'error',
                'message' => 'There is no Post to display',
                'offset' => $offset,
                'page' => $page,
                'html' => $load_more_content,
            );
        } else {
            return array(
                'status' => 'success',
                'offset' => $offset,
                'page' => $page,
                'html' => $load_more_content,
            );
        }
    }

    public function pp_dashboard_actions(WP_REST_Request $request) {


        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';
        $action_val = (isset($get_parms['action_val'])) ? $get_parms['action_val'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {

            return array('status' => 'error', 'message' => $this->pp_dashboard_invalid_security_token());
        }

        $html_content = '';

        switch ($action_val) {
            case 'dashboard':

                ob_start();
                pp_dashboard_html();
                $html_content = ob_get_contents();
                ob_end_clean();

                break;

            case 'courses':

                ob_start();
                pp_courses_html();
                $html_content = ob_get_contents();
                ob_end_clean();
                break;

            case 'loans':

                ob_start();
                pp_loans_html();
                $html_content = ob_get_contents();
                ob_end_clean();
                break;

            case 'meetings':

                ob_start();
                pp_meetings_html();
                $html_content = ob_get_contents();
                ob_end_clean();
                break;

            case 'help':

                ob_start();
                pp_help_html();
                $html_content = ob_get_contents();
                ob_end_clean();
                break;

            case 'profile-view':

                ob_start();
                pp_profile_view_html();
                $html_content = ob_get_contents();
                ob_end_clean();
                break;

            case 'profile-edit':

                ob_start();
                pp_profile_html();
                $html_content = ob_get_contents();
                ob_end_clean();
                break;

            case 'notifications':

                ob_start();
                pp_notifications_html();
                $html_content = ob_get_contents();
                ob_end_clean();
                break;

            case 'change-pass':

                ob_start();
                pp_change_pass_html();
                $html_content = ob_get_contents();
                ob_end_clean();
                break;

            default:
                break;
        }

        $das_nav_html = '';
        ob_start();
        pp_dashboard_nav_html($action_val);
        $das_nav_html = ob_get_contents();
        ob_end_clean();


        if ($html_content != '') {

            return array(
                'status' => 'success',
                'content_html' => $html_content,
                'nav_html' => $das_nav_html,
            );
        } else {

            return array(
                'status' => 'error',
                'message' => 'something went wrong.',
            );
        }
    }

    public function pp_dashboard_cosigner_register(WP_REST_Request $request) {


        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            $return = array('success' => false, 'data' => '', 'message' => $this->pp_dashboard_invalid_security_token());
            wp_send_json_error($return);
        }

        $cosigner_data = array();
        parse_str($get_parms['cosigner_data'], $cosigner_data);

        global $PPDashboard_options;

        $PPDashboard_options = get_option('p-p-dash-options');

        $pp_admin_email = isset($PPDashboard_options['pp-cosigner-admin-mail']) && $PPDashboard_options['pp-cosigner-admin-mail'] != '' ? $PPDashboard_options['pp-cosigner-admin-mail'] : get_option('admin_email');

        if (isset($cosigner_data) && $cosigner_data != '') {

            foreach ($cosigner_data as $cosigner_key => $cosigner_val) {

                if ($cosigner_val == '') {

                    return array(
                        'status' => 'error',
                        'message' => 'Seems some of form fields are empty.',
                    );

                    break;
                }
            }
        }

        /*
         * Upload Docs
         */

        $multi_files = $request->get_file_params(); // get upload docs


        $pp_documents = array();
        $count = 0;

        if (isset($multi_files) && $multi_files != '') {

            $file_name_array = array();
            foreach ($multi_files as $multi_key => $multi_value) {
                if ($multi_value['name']) {

                    $loop_file = array(
                        'name' => $multi_value['name'],
                        'type' => $multi_value['type'],
                        'tmp_name' => $multi_value['tmp_name'],
                        'error' => $multi_value['error'],
                        'size' => $multi_value['size']
                    );

                    require_once ABSPATH . 'wp-admin/includes/image.php';
                    require_once ABSPATH . 'wp-admin/includes/file.php';
                    require_once ABSPATH . 'wp-admin/includes/media.php';

                    $upload_file_status = wp_handle_upload($loop_file, array('test_form' => false, 'mimes' => array('pdf' => 'application/pdf')));

                    if (empty($upload_file_status['error'])) {

                        $wp_upload_dir = wp_upload_dir();
                        $file_name_array[] = isset($upload_file_status['url']) ? $upload_file_status['url'] : '';
                        $filename = $file_name_array[$count];
                        $filetype = wp_check_filetype(basename($filename), null);

                        if ($filename != '') {
                            $attachment = array(
                                'guid' => ($filename),
                                'post_mime_type' => $filetype['type'],
                                'post_title' => preg_replace('/\.[^.]+$/', '', ($loop_file['name'])),
                                'post_content' => '',
                                'post_status' => 'inherit'
                            );
                            require_once( ABSPATH . 'wp-admin/includes/image.php' );
                            $attach_id = wp_insert_attachment($attachment, $upload_file_status['file']);
                            $attach_data = wp_generate_attachment_metadata($attach_id, $upload_file_status['file']);
                            wp_update_attachment_metadata($attach_id, $attach_data);
                            $pp_documents[] = $attach_id;
                            $count ++;
                        }
                    } else {
                        return array(
                            'status' => 'error',
                            'message' => $upload_file_status['error'],
                        );
                    }
                }
            }
        } else {

            return array(
                'status' => 'error',
                'message' => 'Please upload the required files.',
            );
        }


        /*
         * End load docs
         */

        $your_name = $cosigner_data['your_name'];
        $your_email = $cosigner_data['your_email'];

        if ($your_name == "" || $your_email == "") {

            return array(
                'status' => 'error',
                'message' => __('Please don\'t leave blank the required fields', 'pp-dashboard'),
            );
        }

        if (!filter_var($your_email, FILTER_VALIDATE_EMAIL)) {

            return array(
                'status' => 'error',
                'message' => __('Invalid user email address', 'pp-dashboard'),
            );
        }

        if (email_exists($your_email)) {

            return array(
                'status' => 'error',
                'message' => __('A user with same email address already exist.', 'pp-dashboard'),
            );
        }

        $user_name = explode('@', $your_email);

        if (username_exists($user_name[0])) {

            return array(
                'status' => 'error',
                'message' => __('A user with same username already exists', 'pp-dashboard'),
            );
        }


        /*
         * password Generation
         */

        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';

        $pass = array();
        $random_pass = '';

        $alphaLength = strlen($alphabet) - 1;
        for ($i = 0; $i < 8; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        $random_pass = implode($pass);


        /*
         * Regsiter User
         */

        $user_id = wp_insert_user(
                array(
                    'user_pass' => $random_pass,
                    'user_login' => $user_name[0],
                    'user_email' => $your_email,
                    'role' => 'subscriber'
                )
        );

        if (is_wp_error($user_id)) {

            return array(
                'status' => 'error',
                'message' => __('Error on user creation.', 'pp-dashboard'),
            );
        } else {


            $user_data = wp_update_user(array('ID' => $user_id, 'display_name' => $your_name));
            update_user_meta($user_id, 'cosigner_user_status', 'pending');
            update_user_meta($user_id, 'pp_user_role', 'cosigner');



            if (is_wp_error($user_data)) {

                return array(
                    'status' => 'error',
                    'message' => __('Error on user updation.', 'pp-dashboard'),
                );
            }
        }

        /*
         * Insert new Co-Signer post
         */

        $post_params = array(
            'post_title' => wp_strip_all_tags($your_name),
            'post_status' => 'pending',
            'post_type' => 'pp-cosigner',
            'post_author' => 1,
        );

        $cosigner_post_id = wp_insert_post($post_params);

        if (is_wp_error($cosigner_post_id)) {

            return array(
                'status' => 'error',
                'message' => $cosigner_post_id->get_error_message(),
            );
        } else {

            update_post_meta($cosigner_post_id, 'cosigner_user_id', $user_id);
            update_user_meta($user_id, 'cosigner_post_id', $cosigner_post_id);
            update_post_meta($cosigner_post_id, 'pp_uploads_files', $pp_documents);


            if (isset($cosigner_data) && $cosigner_data != '') {

                foreach ($cosigner_data as $cosigner_key => $cosigner_val) {

                    update_post_meta($cosigner_post_id, $cosigner_key, $cosigner_val);
                }
            }



            /*
             * Admin Email
             */

            $pp_dashboard_logo = P_P_DASHBOARD_PLUGIN_URL . 'public/images/logo.png';


            $fields_arr = array(
                'your_name' => 'User Name',
                'your_address' => 'User Address',
                'your_dob' => 'User Date of Birth',
                'your_phone' => 'User Phone Number',
                'your_email' => 'User Email',
                'business_name' => 'User Business Name',
                'business_address' => 'User Business Address',
                'business_position' => 'User Business Name',
                'basic_salary' => 'User salary',
                'getpaid' => 'User get paid',
                'job_duration' => 'User job Months',
                'hiring_party_mail' => 'Hiring Party Email',
                'hiring_party_phone' => 'Hiring Party Phone',
                'bank_money' => 'User Bank Deposit',
            );


            $template_admin_message = sprintf(__('New user has registered on your site %s. Below are the user details and also find the attachments.'), get_bloginfo('name'));

            $user_details_html = '';

            if (isset($cosigner_data) && $cosigner_data != '') {

                foreach ($cosigner_data as $cosigner_key => $cosigner_val) {

                    $user_record = sprintf(__('%s : %s', 'pp-dashboard'), $fields_arr[$cosigner_key], $cosigner_val);
                    $user_details_html .= '<p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $user_record . '</p>';
                }
            }


            $html_admin_template = '<!DOCTYPE html>
                                <html>
                                   <head>
                                      <title>' . __("User Registeration", "pp-dashboard") . '</title>
                                   </head>
                                   <body>
                                      <table class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #f6f6f6; width: 100%;" border="0" cellspacing="0" cellpadding="0">
                                         <tbody>
                                            <tr>
                                               <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;"></td>
                                               <td class="container" style="font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 580px; padding: 10px; width: 580px; margin: 0 auto !important;">
                                                  <div class="content" style="box-sizing: border-box; display: block; margin: 0 auto; max-width: 580px; padding: 10px;">
                                                     <table class="main" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background: #fff; border-radius: 3px; width: 100%;">
                                                        <tbody>
                                                           <tr>
                                                              <td class="wrapper" style="font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 20px;">
                                                                 <table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;" border="0" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                       <tr style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                                          <td class="alert" style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 16px; vertical-align: top; color: #000; font-weight: 500; text-align: center; border-radius: 3px 3px 0 0; background-color: #fff; margin: 0; padding: 20px;" align="center" valign="top" bgcolor="#fff">
                                                                             <img class="alignnone size-full wp-image-1437" src="' . $pp_dashboard_logo . '" width="80" height="80" alt="site logo"/>
                                                                          </td>
                                                                       </tr>
                                                                       <tr>
                                                                          <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;"><span style="font-family: sans-serif; font-weight: normal;">Hello </span><span style="font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;"><b> Admin,</b></span></p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $template_admin_message . '</p><br/>
                                                                             ' . $user_details_html . '
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;"><strong>Thanks!</strong>
                                                                          </td>
                                                                       </tr>
                                                                    </tbody>
                                                                 </table>
                                                              </td>
                                                           </tr>
                                                        </tbody>
                                                     </table>                     
                                                     &nbsp;
                                                  </div>
                                               </td>               
                                            </tr>
                                         </tbody>
                                      </table>
                                   </body>
                                </html>';


            $subject_admin = 'New Registeration';
            $from_d = get_bloginfo('name') . ' <' . get_option('admin_email') . '>';
            $headers = array('Content-Type: text/html; charset=UTF-8', 'From: ' . $from_d . '');

            $mail_attachments = array();

            if (isset($pp_documents) && !empty($pp_documents)) {

                foreach ($pp_documents as $attach_id) {
                    array_push($mail_attachments, get_attached_file($attach_id));
                }
            }

            wp_mail($pp_admin_email, $subject_admin, $html_admin_template, $headers, $mail_attachments);

            /*
             * Admin Template End
             */



            /*
             * Mail to user
             */

            $template_title = $your_name;



            $template_message = 'Congratulation ! you are successfully register as a co-signer below are your login details.';
            $template_email = sprintf(__('User Email : %s', 'pp-dashboard'), $your_email);
            $template_password = sprintf(__('Your Password : %s', 'pp-dashboard'), $random_pass);

            $html_user_template = '<!DOCTYPE html>
                                <html>
                                   <head>
                                      <title>' . __("User Registeration", "pp-dashboard") . '</title>
                                   </head>
                                   <body>
                                      <table class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #f6f6f6; width: 100%;" border="0" cellspacing="0" cellpadding="0">
                                         <tbody>
                                            <tr>
                                               <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;"></td>
                                               <td class="container" style="font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 580px; padding: 10px; width: 580px; margin: 0 auto !important;">
                                                  <div class="content" style="box-sizing: border-box; display: block; margin: 0 auto; max-width: 580px; padding: 10px;">
                                                     <table class="main" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background: #fff; border-radius: 3px; width: 100%;">
                                                        <tbody>
                                                           <tr>
                                                              <td class="wrapper" style="font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 20px;">
                                                                 <table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;" border="0" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                       <tr style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                                          <td class="alert" style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 16px; vertical-align: top; color: #000; font-weight: 500; text-align: center; border-radius: 3px 3px 0 0; background-color: #fff; margin: 0; padding: 20px;" align="center" valign="top" bgcolor="#fff">
                                                                             <img class="alignnone size-full wp-image-1437" src="' . $pp_dashboard_logo . '" width="80" height="80" alt="site logo"/>
                                                                          </td>
                                                                       </tr>
                                                                       <tr>
                                                                          <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;"><span style="font-family: sans-serif; font-weight: normal;">Hello </span><span style="font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;"><b> ' . $template_title . ',</b></span></p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $template_message . '</p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $template_email . '</p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $template_password . '</p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;"><strong>Thanks!</strong>
                                                                          </td>
                                                                       </tr>
                                                                    </tbody>
                                                                 </table>
                                                              </td>
                                                           </tr>
                                                        </tbody>
                                                     </table>                     
                                                     &nbsp;
                                                  </div>
                                               </td>               
                                            </tr>
                                         </tbody>
                                      </table>
                                   </body>
                                </html>';

            $subject_user = 'Peaceful Payback Registeration';
            $from_d = get_bloginfo('name') . ' <' . get_option('admin_email') . '>';
            $headers = array('Content-Type: text/html; charset=UTF-8', 'From: ' . $from_d . '');

            if (wp_mail($your_email, $subject_user, $html_user_template, $headers)) {

                return array(
                    'status' => 'success',
                    'message' => __('You\'re successfully register. Please check you mail for login information.', 'pp-dashboard'),
                );
            } else {

                return array(
                    'status' => 'error',
                    'message' => __('User Created but something went wrong to mail you.', 'pp-dashboard'),
                );
            }
        }
    }

    public function pp_dashboard_cosigner_signin(WP_REST_Request $request) {


        global $PPDashboard_options;
        $PPDashboard_options = get_option('p-p-dash-options');
        $pp_signin_redirect = isset($PPDashboard_options['pp-signin-redirect']) && $PPDashboard_options['pp-signin-redirect'] != '' ? get_the_permalink($PPDashboard_options['pp-signin-redirect']) : 'javascript:void(0)';


        $get_parms = $request->get_params();
        $nonce = (isset($get_parms['nonce'])) ? $get_parms['nonce'] : '';

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            $return = array('success' => false, 'data' => '', 'message' => $this->pp_dashboard_invalid_security_token());
            wp_send_json_error($return);
        }

        $cosigner_data = array();
        parse_str($get_parms['signin_data'], $cosigner_data);


        $your_password = stripslashes(trim($cosigner_data['your_password']));
        $your_email = stripslashes(trim($cosigner_data['your_email']));

        if ($your_password == "" || $your_email == "") {

            return array(
                'status' => 'error',
                'message' => __('Please don\'t leave blank the required fields', 'pp-dashboard'),
            );
        }

        if (!filter_var($your_email, FILTER_VALIDATE_EMAIL)) {

            return array(
                'status' => 'error',
                'message' => __('Invalid user email address', 'pp-dashboard'),
            );
        }

        if (email_exists($your_email)) {

            $user = wp_authenticate($your_email, $your_password);

            if (!is_wp_error($user)) {


                $user_status = get_user_meta($user->ID, 'cosigner_user_status', true);


                if (isset($user_status) && $user_status == 'pending') {

                    return array(
                        'status' => 'error',
                        'message' => __('Your Account approval is in process.', 'pp-dashboard'),
                    );
                }


                if (isset($user_status) && $user_status == 'approved') {

                    $pp_cred = array();

                    $pp_cred['user_login'] = $your_email;
                    $pp_cred['user_password'] = $your_password;
                    $pp_cred['remember'] = false;

                    $safe_user = wp_signon($pp_cred, false);

                    if (!is_wp_error($safe_user)) {

                        return array(
                            'status' => 'success',
                            'message' => __('You\'re successfully Login.', 'pp-dashboard'),
                            'redirect' => $pp_signin_redirect,
                        );
                    } else {

                        return array(
                            'status' => 'error',
                            'message' => $user->get_error_message(),
                        );
                    }
                } else {

                    return array(
                        'status' => 'error',
                        'message' => __('Seems you are not co-signer', 'pp-dashboard'),
                    );
                }
            } else {

                return array(
                    'status' => 'error',
                    'message' => $user->get_error_message(),
                );
            }
        } else {
            return array(
                'status' => 'error',
                'message' => __('Please provide valid credentials.', 'pp-dashboard'),
            );
        }
    }

}

new P_P_Dashboard_Routes();
