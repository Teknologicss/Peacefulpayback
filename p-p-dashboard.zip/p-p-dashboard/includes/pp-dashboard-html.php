<?php
/*
 * responsible for dashboard html
 */


/*
 * Course Detail HTML
 */

function pp_course_detail_html($course_id, $counter_val = 0)
{

    $det_item_list = get_post_meta($course_id, 'course_detail_title', true);
    $before_vid_text = get_post_meta($course_id, 'before_vid_text', true);
    $course_video_url = get_post_meta($course_id, 'course_video_url', true);
    $after_vid_text = get_post_meta($course_id, 'after_vid_text', true);
    $course_img_arr = get_post_meta($course_id, 'course_img', true);


    //if (isset($det_item_list) && !empty($det_item_list) && is_array($det_item_list) && sizeof($det_item_list) > 0) {

    $det_item_counter = $counter_val;

    //foreach ($det_item_list as $det_item) {
    $rand_num = rand(1000000, 99999999);

    $det_item = isset($det_item_list[$det_item_counter]) ? $det_item_list[$det_item_counter] : '';

    $each_before_vid_text = isset($before_vid_text[$det_item_counter]) ? $before_vid_text[$det_item_counter] : '';
    $each_course_video_url = isset($course_video_url[$det_item_counter]) ? $course_video_url[$det_item_counter] : '';
    $each_after_vid_text = isset($after_vid_text[$det_item_counter]) ? $after_vid_text[$det_item_counter] : '';
    $course_img = isset($course_img_arr[$det_item_counter]) ? $course_img_arr[$det_item_counter] : '';


    //if ($det_item_counter == 0) {

    $content_active = ' style="display:block"';
    $courser_data_class = ' active';
    //            } else {
    //
    //                $content_active = ' style="display:none"';
    //                $courser_data_class = '';
    //            }


    $image_course_arr = wp_get_attachment_image_src($course_img, 'full');
    $image_course_url = isset($image_course_arr[0]) && $image_course_arr[0] != '' ? $image_course_arr[0] : '';
?>
    <div class="pp-course-data <?php echo $courser_data_class; ?>" <?php echo $content_active; ?> id="pp-course-det-<?php echo $det_item_counter; ?>">
        <div class="row m-auto pt-4 px-3">
            <div class="col-lg-7 pp-course-content">
                <h1>
                    Case Study:
                    <span><?php echo $det_item; ?></span>
                </h1>
                <div class="pp-inner-details">
                    <p> <?php echo nl2br($each_before_vid_text); ?></p>
                </div>
                <?php
                if ($each_course_video_url != "") {

                    preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $each_course_video_url, $match);

                    if (isset($match[1]) && $match[1] != "") {
                        $video_id = $match[1];
                ?>
                        <div class="pp-course-video">
                            <?php
                            $iframe = 'iframe';
                            echo '<' . $iframe . ' id="player" width="100%" height="450" src="https://www.youtube.com/embed/' . esc_attr($video_id) . '?enablejsapi=1" frameborder="0" allowfullscreen></' . $iframe . '>';
                            ?>
                        </div>
                <?php
                    }
                }
                ?>
                <div class="pp-inner-details">
                    <?php echo nl2br($each_after_vid_text); ?>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="pp-content-imgs">
                    <img src="<?php echo $image_course_url; ?>" alt="course image" width="100%">
                </div>
            </div>
        </div>
    </div>





<?php
    //$det_item_counter ++;
    // if($det_item_counter == 1){
    // break;
    //}
    //}
    //}
}

/*
 * Course Detail nav HTML
 */

function pp_dashboard_course_nav_html($course_id, $redirection)
{
?>
    <div class="course-detail l-navbar show" id="nav-bar">
        <nav class="nav">
            <div>
                <div class="nav_list">
                    <a href="javascript:void(0)" class="nav_link d-flex align-items-center gap-3 pp-go-back" data-action="<?php echo $redirection; ?>">
                        <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/Path 254.svg" alt="">
                        <p class="nav_name ml-1">Back </p>
                    </a>
                    <?php
                    $det_item_list = get_post_meta($course_id, 'course_detail_title', true);

                    if (isset($det_item_list) && !empty($det_item_list) && is_array($det_item_list) && sizeof($det_item_list) > 0) {

                        $det_item_counter = 0;


                        foreach ($det_item_list as $det_item) {

                            //$enable_class = ' course-disable';
                            //if ($det_item_counter == 0) {
                            $enable_class = ' pp-course-title';
                            //}
                    ?>
                            <a href="javascript:void(0)" class="nav_link<?php echo $enable_class; ?>" data-active-id="<?php echo $det_item_counter; ?>" data-course-id="<?php echo $course_id; ?>">
                                <i class='bx bx-check'></i>
                                <div class="nav_name">Video:
                                    <span><?php echo $det_item; ?></span>
                                </div>
                            </a>
                    <?php
                            $det_item_counter++;
                        }
                    }
                    ?>

                </div>
            </div>
        </nav>
    </div>

<?php
}

/*
 * Dashboard nav html
 */

function pp_dashboard_nav_html($action_val)
{
?>
    <div class="l-navbar show pp-dash-link-sidebar" id="nav-bar">
        <nav class="nav">
            <div>
                <div class="nav_list">

                    <a href="javascript:void(0)" class="nav_link<?php echo isset($action_val) && $action_val == 'dashboard' ? ' active' : ''; ?>" data-action="dashboard">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                            <path id="dashboard" d="M5,5V29H29V5ZM7.182,7.182h5.455v5.455H7.182Zm7.636,0h4.364v5.455H14.818Zm6.545,0h5.455v5.455H21.364ZM7.182,14.818h5.455v4.364H7.182Zm7.636,0h4.364v4.364H14.818Zm6.545,0h5.455v4.364H21.364ZM7.182,21.364h5.455v5.455H7.182Zm7.636,0h4.364v5.455H14.818Zm6.545,0h5.455v5.455H21.364Z" transform="translate(-5 -5)" />
                        </svg>
                        <span class="nav_name">Dashboard</span>
                    </a>

                    <a href="javascript:void(0)" class="nav_link<?php echo isset($action_val) && $action_val == 'courses' ? ' active' : ''; ?>" data-action="courses">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24.985" height="14.991" viewBox="0 0 24.985 14.991">
                            <path id="Path_68" data-name="Path 68" d="M173.236,101.313l-11.66-5a.826.826,0,0,0-.655,0l-11.654,4.994,0,0h0a.819.819,0,0,0-.236.16.738.738,0,0,0-.055.062.813.813,0,0,0-.117.175.834.834,0,0,0-.037.078.82.82,0,0,0-.059.29v6.663a.833.833,0,0,0,1.666,0v-5.4l3.331,1.428v5.638a.833.833,0,0,0,.833.833h13.325a.833.833,0,0,0,.833-.833v-5.638l4.492-1.925a.833.833,0,0,0,0-1.531Zm-6.158,8.261h-11.66v-4.091l5.5,2.358a.831.831,0,0,0,.657,0l5.5-2.358Zm.512-6.123-.007,0-6.334,2.716-6.334-2.716-.007,0-3.2-1.373,9.545-4.091,9.545,4.091Z" transform="translate(-148.756 -96.248)" />
                        </svg>

                        <span class="nav_name">Courses</span>
                    </a>

                    <a href="javascript:void(0)" class="nav_link<?php echo isset($action_val) && $action_val == 'loans' ? ' active' : ''; ?>" data-action="loans">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                            <path id="Path_86" data-name="Path 86" d="M74.98,19.42A10.038,10.038,0,0,0,90.132,17.5l1.652,1.055a11.99,11.99,0,0,1-18.245,2.2Zm4.572-9.636a2.4,2.4,0,0,1,.393-1.44,1.851,1.851,0,0,1,1.18-.709V6.982h1.222v.653a1.833,1.833,0,0,1,1.2.7,2.4,2.4,0,0,1,.4,1.451v.276H82.536V9.694a.916.916,0,0,0-.2-.669.865.865,0,0,0-1.1,0,.916.916,0,0,0-.2.669,1.378,1.378,0,0,0,.216.779,3.058,3.058,0,0,0,.542.61c.219.189.452.371.7.551a4.942,4.942,0,0,1,.7.61,3,3,0,0,1,.542.785,2.4,2.4,0,0,1,.219,1.072,2.406,2.406,0,0,1-.407,1.457,1.85,1.85,0,0,1-1.208.7V16.9H81.126v-.641a1.83,1.83,0,0,1-1.214-.7,2.425,2.425,0,0,1-.4-1.457v-.6h1.411v.692a.857.857,0,0,0,.211.664.936.936,0,0,0,1.127,0,.857.857,0,0,0,.211-.664,1.384,1.384,0,0,0-.216-.779,3.133,3.133,0,0,0-.542-.61c-.219-.189-.452-.371-.7-.551a4.941,4.941,0,0,1-.7-.61,3,3,0,0,1-.542-.785,2.4,2.4,0,0,1-.216-1.072Zm2.183-5.817A8.014,8.014,0,1,1,73.73,11.98,8.012,8.012,0,0,1,81.736,3.967Zm0,1.7A6.313,6.313,0,1,1,75.43,11.98a6.31,6.31,0,0,1,6.306-6.312Zm.722-5.676A12.014,12.014,0,0,1,93.175,8.338l-1.961.318a10.049,10.049,0,0,0-8.756-6.7ZM93.529,9.747a12.187,12.187,0,0,1,.208,2.233A11.992,11.992,0,0,1,92.5,17.293L90.84,16.23a10.076,10.076,0,0,0,.753-6.171l1.936-.312ZM72.544,19.7A12.013,12.013,0,0,1,81.013-.007V1.957a10.054,10.054,0,0,0-7.028,16.415L72.544,19.7Z" transform="translate(-69.737 0.007)" fill-rule="evenodd" />
                        </svg>

                        <span class="nav_name">Active Loans</span>
                    </a>

                    <a href="javascript:void(0)" class="nav_link<?php echo isset($action_val) && $action_val == 'meetings' ? ' active' : ''; ?>" data-action="meetings">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24">
                            <path d="M7 11h2v2H7zm0 4h2v2H7zm4-4h2v2h-2zm0 4h2v2h-2zm4-4h2v2h-2zm0 4h2v2h-2z"></path>
                            <path d="M5 22h14c1.103 0 2-.897 2-2V6c0-1.103-.897-2-2-2h-2V2h-2v2H9V2H7v2H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2zM19 8l.001 12H5V8h14z">
                            </path>
                        </svg>

                        <span class="nav_name">Meetings</span>
                    </a>

                    <a href="javascript:void(0)" class="nav_link<?php echo isset($action_val) && $action_val == 'help' ? ' active' : ''; ?>" data-action="help">
                        <svg id="settings" xmlns="http://www.w3.org/2000/svg" width="24" height="24.652" viewBox="0 0 24 24.652">
                            <path id="settings-2" data-name="settings" d="M12.677,3l-.148.77-.563,2.815A9.424,9.424,0,0,0,9.507,8.037L6.751,7.089,6.01,6.852l-.385.681-1.9,3.259-.385.681.563.5L6.04,13.844a9.255,9.255,0,0,0-.178,1.481,9.255,9.255,0,0,0,.178,1.481L3.907,18.674l-.563.5.385.681,1.9,3.259.385.681.741-.237,2.756-.948a9.424,9.424,0,0,0,2.459,1.452l.563,2.815.148.77H18.01l.148-.77.563-2.815a9.424,9.424,0,0,0,2.459-1.452l2.756.948.741.237.385-.681,1.9-3.259.385-.681-.563-.5-2.133-1.867a9.255,9.255,0,0,0,.178-1.481,9.255,9.255,0,0,0-.178-1.481l2.133-1.867.563-.5-.385-.681-1.9-3.259-.385-.681-.741.237-2.756.948a9.424,9.424,0,0,0-2.459-1.452L18.159,3.77,18.01,3Zm1.541,1.9H16.47l.474,2.459.119.563L17.6,8.1A7.6,7.6,0,0,1,20.47,9.756l.415.385.533-.178,2.4-.83,1.126,1.926-1.9,1.689L22.6,13.1l.148.563a7.832,7.832,0,0,1,0,3.319l-.119.563.415.356,1.9,1.689-1.126,1.926-2.4-.83-.533-.178-.415.385A7.6,7.6,0,0,1,17.6,22.556l-.533.178-.119.563-.474,2.459H14.218L13.744,23.3l-.119-.563-.533-.178A7.6,7.6,0,0,1,10.218,20.9L9.8,20.511l-.533.178-2.4.83L5.744,19.593,7.64,17.9l.444-.356-.148-.563a7.832,7.832,0,0,1,0-3.319l.148-.563-.444-.356-1.9-1.689L6.87,9.133l2.4.83.533.178.415-.385A7.6,7.6,0,0,1,13.092,8.1l.533-.178.119-.563Zm1.126,5.689a4.741,4.741,0,1,0,4.741,4.741A4.755,4.755,0,0,0,15.344,10.585Zm0,1.9A2.844,2.844,0,1,1,12.5,15.326,2.831,2.831,0,0,1,15.344,12.481Z" transform="translate(-3.344 -3)" />
                        </svg>
                        <span class="nav_name">Help</span>
                    </a>

                </div>
            </div>
        </nav>
    </div>

<?php
}

/*
 * Dashboard content html
 */

function pp_dashboard_html()
{

    $c_user_id = get_current_user_ID();

    $cosigner_post_id = get_user_meta($c_user_id, 'cosigner_post_id', true);
    $cosigner_post_id = isset($cosigner_post_id) && $cosigner_post_id != '' ? $cosigner_post_id : '';

    $your_name = get_post_meta($cosigner_post_id, 'your_name', true);
    $your_name = isset($your_name) && $your_name != '' ? $your_name : '';
?>
    <header class="header" id="header">
        <div class="header_toggle">
            <i class="bx bx-menu" id="header-toggle"></i>
        </div>
    </header>
    <section>
        <div class="row m-auto pt-4 px-3">
            <!-- cards -->
            <div class="col-lg-7">
                <div>
                    <div class="pp-cards-heading">
                        <h1 class="text-capitalize">
                            Welcome
                            <span class=""><?php echo $your_name; ?>! </span>
                        </h1>
                    </div>
                </div>
                <div class="pp-assets-management p-4">
                    <h1 class="text-capitalize">Asset management Training</h1>
                    <p>Over View of Real Estate Challenges</p>
                    <div class="progress-bar">
                        <div class="bar" data-size="30">
                            <span class="perc"></span>
                        </div>
                    </div>
                </div>
                <div class="pp-upcoming-meetings">
                    <h1>Upcoming Meetings</h1>
                    <div class="pp-meating">


                        <?php
                        $up_cmng_args = array(
                            'post_type' => 'pp-meeting',
                            'post_status' => 'publish',
                            'posts_per_page' => 3,
                            'order' => 'DESC',
                            'orderby' => 'date',
                            'fields' => 'ids',
                        );


                        $up_cmng_query = new WP_Query($up_cmng_args);

                        // The Loop
                        if ($up_cmng_query->have_posts()) :
                            while ($up_cmng_query->have_posts()) : $up_cmng_query->the_post();
                                global $post;

                                $meeting_price = get_post_meta($post, 'meeting_price', true);
                                $meeting_price = isset($meeting_price) && $meeting_price != '' ? $meeting_price : '';

                                $meeting_client_name = get_post_meta($post, 'meeting_client_name', true);
                                $meeting_client_name = isset($meeting_client_name) && $meeting_client_name != '' ? $meeting_client_name : '';

                                $meeting_location = get_post_meta($post, 'meeting_location', true);
                                $meeting_location = isset($meeting_location) && $meeting_location != '' ? $meeting_location : '';

                                $meeting_link = get_post_meta($post, 'meeting_link', true);
                                $meeting_link = isset($meeting_link) && $meeting_link != '' ? $meeting_link : '';
                        ?>
                                <div class="pp-upcoming-meetings-card">

                                    <div class="pp-date-outer">
                                        <div class="pp-date" id="pp-date">
                                            <div>
                                                <p><?php echo get_the_date('D'); ?></p>
                                                <span><?php echo get_the_date('j'); ?></span>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="pp-meeting-informations d-flex flex-column ml-3">
                                        <h1><?php echo get_the_title($post); ?></h1>
                                        <p>
                                            <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/credit card.svg" alt="" />
                                            <?php if ($meeting_price != '') { ?>
                                                <span>Price: <?php echo $meeting_price; ?></span>
                                            <?php } ?>
                                        </p>

                                        <p class="pp-clients">
                                            <span class="pp-client-name">Client: <?php echo $meeting_client_name; ?></span>
                                            <span class="pp-location">
                                                Location: <?php echo $meeting_location; ?>
                                            </span>
                                        </p>

                                    </div>

                                    <?php if ($meeting_link != '') { ?>
                                        <div class="pp-join-meeting">
                                            <a href="<?php echo $meeting_link; ?>"> Join </a>
                                        </div>
                                    <?php } ?>

                                </div>
                        <?php
                            endwhile;
                        endif;

                        // Reset Post Data
                        wp_reset_postdata();
                        ?>

                    </div>
                </div>
                <div class="pp-active-loans">
                    <h1>Active Loans</h1>
                    <div class="pp-meating">
                        <?php
                        $client_args = array(
                            'post_type' => 'pp-client',
                            'post_status' => 'publish',
                            'posts_per_page' => 2,
                            'order' => 'DESC',
                            'orderby' => 'date',
                            'fields' => 'ids',
                            'meta_query' => array(
                                array(
                                    'key' => 'pp_cosigner_id',
                                    'value' => get_current_user_id(),
                                    'compare' => '=',
                                ),
                            ),
                        );

                        $client_query = new WP_Query($client_args);
                        // The Loop
                        if ($client_query->have_posts()) {
                            while ($client_query->have_posts()) : $client_query->the_post();

                                global $post;

                                $bowrer_name = get_post_meta($post, 'bowrer_name', true);
                                $bowrer_name = isset($bowrer_name) && $bowrer_name != '' ? $bowrer_name : '';

                                $bowrer_due_amount = get_post_meta($post, 'bowrer_due_amount', true);
                                $bowrer_due_amount = isset($bowrer_due_amount) && $bowrer_due_amount != '' ? $bowrer_due_amount : '';

                                $bowrer_phone = get_post_meta($post, 'bowrer_phone', true);
                                $bowrer_phone = isset($bowrer_phone) && $bowrer_phone != '' ? $bowrer_phone : '';

                                $bowrer_address = get_post_meta($post, 'bowrer_address', true);
                                $bowrer_address = isset($bowrer_address) && $bowrer_address != '' ? $bowrer_address : '';
                        ?>

                                <div class="pp-upcoming-meetings-card">
                                    <div class="pp-date-outer   ">
                                        <div class="pp-date">
                                            <div>
                                                <p>Due On</p>
                                                <span><?php echo get_the_date('d/m/Y'); ?></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="pp-meeting-informations d-flex flex-column ml-3">
                                        <h1><?php echo $bowrer_name; ?></h1>
                                        <p>
                                            <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/credit card.svg" alt="" />
                                            <?php if ($bowrer_due_amount != '') { ?>
                                                <span>Price: <?php echo $bowrer_due_amount; ?></span>
                                            <?php } ?>
                                        </p>
                                        <p class="pp-clients">
                                            <span class="pp-client-name">Phone: <?php echo $bowrer_phone; ?></span>
                                            <span class="pp-location">
                                                <?php echo $bowrer_address; ?>
                                            </span>
                                        </p>
                                    </div>
                                    <div class="pp-join-meeting">
                                        <a href="javascript:void(0)" data-client-id="<?php echo $post; ?>" data-bs-toggle="modal" data-bs-target="#ppclientmodal" class="pp-client-view"> View </a>
                                    </div>
                                </div>

                            <?php
                            endwhile;
                        } else {
                            ?>
                            <div class="pp-upcoming-meetings-card">
                                <p> There are no active loans </p>
                            </div>
                        <?php
                        }

                        // Reset Post Data
                        wp_reset_postdata();
                        ?>

                    </div>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="pp-cards-heading">
                    <h1 class="text-capitalize">
                        Signed
                        <span class="">Documents</span>
                    </h1>
                </div>

                <?php
                $pp_uploads_files = get_post_meta($cosigner_post_id, 'pp_uploads_files', true);
                $pp_uploads_files = isset($pp_uploads_files) && $pp_uploads_files != '' ? $pp_uploads_files : '';


                if (isset($pp_uploads_files) && $pp_uploads_files != '') {
                    foreach ($pp_uploads_files as $key => $attach_id) {

                        $attach_url = wp_get_attachment_url($attach_id);
                        $attach_title = get_the_title($attach_id);
                ?>
                        <div class="pp-dashboard-outer">
                            <p class="m-0">
                                <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/noun-documents-857991.svg" alt="" />
                                <span><?php echo $attach_title; ?></span>
                            </p>
                            <a href="<?php echo $attach_url; ?>" download> Download </a>
                        </div>
                    <?php
                    }
                } else {
                    ?>

                    <div class="pp-dashboard-outer">
                        <p class="m-0">
                        <h4>There is no file to display</h4>
                        </p>
                    </div>

                <?php
                }
                ?>
            </div>

            <?php
            $display_count = 10;


            $up_courses_args = array(
                'post_type' => 'pp-course',
                'post_status' => 'publish',
                'posts_per_page' => $display_count,
                'order' => 'DESC',
                'orderby' => 'date',
                'fields' => 'ids',
            );

            $up_courses_query = new WP_Query($up_courses_args);

            // The Loop
            if ($up_courses_query->have_posts()) :
            ?>
                <div class="col-md-12">
                    <div class="pp-upcoming-trainings">
                        <h1>Upcoming Trainings</h1>
                        <div class="swiper pp-upcomming-Swiper">
                            <div class="swiper-wrapper">
                                <?php
                                while ($up_courses_query->have_posts()) : $up_courses_query->the_post();
                                    global $post;

                                    $course_author = get_post_meta($post, 'course_author', true);
                                    $course_author = isset($course_author) && $course_author != '' ? $course_author : '';

                                    $course_tagline = get_post_meta($post, 'course_tagline', true);
                                    $course_tagline = isset($course_tagline) && $course_tagline != '' ? $course_tagline : '';

                                    $course_hours = get_post_meta($post, 'course_hours', true);
                                    $course_hours = isset($course_hours) && $course_hours != '' ? $course_hours : '';

                                    $course_img_url = get_the_post_thumbnail_url($post, 'thumbnail');
                                ?>
                                    <div class="swiper-slide">
                                        <div class="pp-upcomming-courses-cards">
                                            <img src="<?php echo $course_img_url; ?>" alt="Course Image" />
                                            <div class="pp-course-outline">
                                                <div class="pp-course-name">
                                                    <div class="pp-swiper-text d-flex gap-2">
                                                        <p><?php echo get_the_title($post); ?></p>
                                                    </div>
                                                    <div class="pp-time">
                                                        <span><?php echo $course_hours; ?></span>
                                                    </div>
                                                </div>
                                                <p class="pp-offered-by">By <?php echo $course_author; ?></p>
                                                <div class="pp-overveiw">
                                                    <p class="mb-0"><?php echo $course_tagline; ?></p>
                                                    <a href="javascript:void(0)" data-course-id="<?php echo $post; ?>" class="pp-course-det" data-redirect="dashboard"> Explore </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                endwhile;
                                wp_reset_postdata();
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
            endif;
            wp_reset_postdata();
            ?>
            <!-- cards end -->
        </div>
    </section>
<?php
}

/*
 * PP Dashboard Courses HTML
 */

function pp_courses_html()
{
?>
    <section>
        <div class="row m-auto pt-4 px-3 pp-post-content">
            <div class="pp-upcoming-courses-trainings col-md-12">
                <h1>Upcoming Trainings</h1>
            </div>

            <?php
            $display_count = 3;
            $page = get_query_var('paged') ? get_query_var('paged') : 1;
            $offset = ($page - 1) * $display_count;



            $up_courses_args = array(
                'post_type' => 'pp-course',
                'post_status' => 'publish',
                'posts_per_page' => $display_count,
                'order' => 'DESC',
                'orderby' => 'date',
                'fields' => 'ids',
                'page' => $page,
                'offset' => $offset
            );


            $up_courses_query = new WP_Query($up_courses_args);




            // The Loop
            if ($up_courses_query->have_posts()) :
                while ($up_courses_query->have_posts()) : $up_courses_query->the_post();
                    global $post;

                    $course_author = get_post_meta($post, 'course_author', true);
                    $course_author = isset($course_author) && $course_author != '' ? $course_author : '';

                    $course_tagline = get_post_meta($post, 'course_tagline', true);
                    $course_tagline = isset($course_tagline) && $course_tagline != '' ? $course_tagline : '';

                    $course_hours = get_post_meta($post, 'course_hours', true);
                    $course_hours = isset($course_hours) && $course_hours != '' ? $course_hours : '';

                    $course_img_url = get_the_post_thumbnail_url($post, 'thumbnail');
            ?>
                    <div class="col-md-6">
                        <div class="pp-upcomming-courses-cards">
                            <img src="<?php echo $course_img_url; ?>" alt="Course Image" />
                            <div class="pp-course-outline">
                                <div class="pp-course-name">
                                    <div class="pp-swiper-text d-flex gap-2">
                                        <p><?php echo get_the_title($post); ?></p>
                                    </div>
                                    <div class="pp-time">
                                        <span><?php echo $course_hours; ?></span>
                                    </div>
                                </div>
                                <p class="pp-offered-by">By <?php echo $course_author; ?></p>
                                <div class="pp-overveiw">
                                    <p class="mb-0"><?php echo $course_tagline; ?></p>
                                    <a href="javascript:void(0)" data-course-id="<?php echo $post; ?>" class="pp-course-det">
                                        Explore </a>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php
                endwhile;
            endif;

            // Reset Post Data
            wp_reset_postdata();
            ?>

        </div>

        <?php if ($up_courses_query->found_posts > $up_courses_query->post_count) { ?>

            <a href="javascript:void(0)" class="pp-load-more" data-post="pp-course" data-page="<?php echo $page; ?>" data-offset="<?php echo $offset; ?>" data-number="<?php echo $display_count; ?>"> Load More Courses
            </a>

        <?php } ?>

    </section>

<?php
}

/*
 * PP Dashboard Loans HTML
 */

function pp_loans_html()
{
?>
    <section class="pp-active-loans-tab">
        <div class="row m-auto pt-4 px-3">


            <div class="pp-active-loans">

                <div class="pp-active-loans col-md-12 mb-0">
                    <h1>Active Loans</h1>
                </div>

                <div class="pp-meating">
                    <?php
                    $client_args = array(
                        'post_type' => 'pp-client',
                        'post_status' => 'publish',
                        'posts_per_page' => 2,
                        'order' => 'DESC',
                        'orderby' => 'date',
                        'fields' => 'ids',
                        'meta_query' => array(
                            array(
                                'key' => 'pp_cosigner_id',
                                'value' => get_current_user_id(),
                                'compare' => '=',
                            ),
                        ),
                    );

                    $client_query = new WP_Query($client_args);
                    // The Loop
                    if ($client_query->have_posts()) {

                        while ($client_query->have_posts()) : $client_query->the_post();

                            global $post;

                            $bowrer_name = get_post_meta($post, 'bowrer_name', true);
                            $bowrer_name = isset($bowrer_name) && $bowrer_name != '' ? $bowrer_name : '';

                            $bowrer_due_amount = get_post_meta($post, 'bowrer_due_amount', true);
                            $bowrer_due_amount = isset($bowrer_due_amount) && $bowrer_due_amount != '' ? $bowrer_due_amount : '';

                            $bowrer_phone = get_post_meta($post, 'bowrer_phone', true);
                            $bowrer_phone = isset($bowrer_phone) && $bowrer_phone != '' ? $bowrer_phone : '';

                            $bowrer_address = get_post_meta($post, 'bowrer_address', true);
                            $bowrer_address = isset($bowrer_address) && $bowrer_address != '' ? $bowrer_address : '';
                    ?>

                            <div class="pp-upcoming-meetings-card col-lg-7">
                                <div class="pp-date-outer">
                                    <div class="pp-date">
                                        <div>
                                            <p>Due On</p>
                                            <span><?php echo get_the_date('d/m/Y'); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="pp-meeting-informations d-flex flex-column ml-3">
                                    <h1><?php echo $bowrer_name; ?></h1>
                                    <p>
                                        <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/credit card.svg" alt="" />
                                        <?php if ($bowrer_due_amount != '') { ?>
                                            <span>Price: <?php echo $bowrer_due_amount; ?></span>
                                        <?php } ?>
                                    </p>
                                    <p class="pp-clients">
                                        <span class="pp-client-name">Phone: <?php echo $bowrer_phone; ?></span>
                                        <span class="pp-location">
                                            Location: <?php echo $bowrer_address; ?>
                                        </span>
                                    </p>
                                </div>
                                <div class="pp-join-meeting">
                                    <a href="javascript:void(0)" data-client-id="<?php echo $post; ?>" data-bs-toggle="modal" data-bs-target="#ppclientmodal" class="pp-client-view"> View </a>
                                </div>
                            </div>

                        <?php
                        endwhile;
                    } else {
                        ?>
                        <div class="pp-upcoming-meetings-card">
                            <p> There are no active loans </p>
                        </div>
                    <?php
                    }

                    // Reset Post Data
                    wp_reset_postdata();
                    ?>

                </div>

            </div>

        </div>
    </section>

<?php
}

/*
 * PP Dashboard Meetings HTML
 */

function pp_meetings_html()
{
?>

    <section class="pp-meetings-tab">
        <div class="row m-auto pt-4 px-3 pp-post-content">
            <div class="pp-active-loans col-md-12 mb-0">
                <h1>Upcoming Meetings</h1>
            </div>
            <div class="pp-meating">
                <?php
                $display_count = 3;
                $page = get_query_var('paged') ? get_query_var('paged') : 1;
                $offset = ($page - 1) * $display_count;

                $up_cmng_args = array(
                    'post_type' => 'pp-meeting',
                    'post_status' => 'publish',
                    'posts_per_page' => $display_count,
                    'order' => 'DESC',
                    'orderby' => 'date',
                    'fields' => 'ids',
                    'page' => $page,
                    'offset' => $offset
                );

                $up_cmng_query = new WP_Query($up_cmng_args);

                // The Loop
                if ($up_cmng_query->have_posts()) :
                    while ($up_cmng_query->have_posts()) : $up_cmng_query->the_post();
                        global $post;

                        $meeting_price = get_post_meta($post, 'meeting_price', true);
                        $meeting_price = isset($meeting_price) && $meeting_price != '' ? $meeting_price : '';

                        $meeting_client_name = get_post_meta($post, 'meeting_client_name', true);
                        $meeting_client_name = isset($meeting_client_name) && $meeting_client_name != '' ? $meeting_client_name : '';

                        $meeting_location = get_post_meta($post, 'meeting_location', true);
                        $meeting_location = isset($meeting_location) && $meeting_location != '' ? $meeting_location : '';

                        $meeting_link = get_post_meta($post, 'meeting_link', true);
                        $meeting_link = isset($meeting_link) && $meeting_link != '' ? $meeting_link : '';
                ?>




                        <div class="pp-upcoming-meetings-card col-lg-7">

                            <div class="pp-date">
                                <div>
                                    <p><?php echo get_the_date('D'); ?></p>
                                    <span><?php echo get_the_date('j'); ?></span>
                                </div>
                            </div>
                            <div class="pp-meeting-informations d-flex flex-column ml-3">
                                <h1><?php echo get_the_title($post); ?></h1>
                                <p>
                                    <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/credit card.svg" alt="" />
                                    <?php if ($meeting_price != '') { ?>
                                        <span>Price: <?php echo $meeting_price; ?></span>
                                    <?php } ?>
                                </p>
                                <p class="pp-clients">
                                    <span class="pp-client-name">Client: <?php echo $meeting_client_name; ?></span>
                                    <span class="pp-location">
                                        Location: <?php echo $meeting_location; ?>
                                    </span>
                                </p>
                            </div>
                            <?php if ($meeting_link != '') { ?>
                                <div class="pp-join-meeting">
                                    <a href="<?php echo $meeting_link; ?>"> Join </a>
                                </div>
                            <?php } ?>
                        </div>

                <?php
                    endwhile;
                endif;
                // Reset Post Data
                wp_reset_postdata();
                ?>
            </div>
        </div>


        <?php if ($up_cmng_query->found_posts > $up_cmng_query->post_count) { ?>

            <div class="col-md-7 col-sm-12">
                <a href="javascript:void(0)" class="pp-load-more" data-post="pp-meeting" data-page="<?php echo $page; ?>" data-offset="<?php echo $offset; ?>" data-number="<?php echo $display_count; ?>">
                    Load More Meetings
                </a>
            </div>

        <?php } ?>

    </section>
<?php
}

/*
 * PP Dashboard profile HTML
 */

function pp_profile_html()
{

    $c_user_id = get_current_user_ID();

    $cosigner_post_id = get_user_meta($c_user_id, 'cosigner_post_id', true);
    $cosigner_post_id = isset($cosigner_post_id) && $cosigner_post_id != '' ? $cosigner_post_id : '';
?>

    <header class="header" id="header">
        <div class="header_toggle">
            <i class="bx bx-menu" id="header-toggle"></i>
        </div>
    </header>


    <section>
        <div class="row m-auto pt-4 px-md-3 px-0">
            <!-- cards -->
            <div class="col-lg-7">

                <div>
                    <div class="pp-cards-heading">

                        <h1 class="text-capitalize">
                            Your Profile
                        </h1>

                        <h5> <a href="javascript:void(0)" class="pp-change-pass" data-action="change-pass"> Change Password
                            </a> </h5>

                    </div>
                </div>

                <div class="pp-profile-section">

                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="personal-info-tab" data-bs-toggle="tab" data-bs-target="#personal-info" type="button" role="tab" aria-controls="personal-info" aria-selected="true">Personal Information</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="Business-info-tab" data-bs-toggle="tab" data-bs-target="#Business-info" type="button" role="tab" aria-controls="Business-info" aria-selected="false">Business Information</button>
                        </li>

                    </ul>
                    <div class="tab-content">

                        <?php
                        // personal information

                        $your_name = get_post_meta($cosigner_post_id, 'your_name', true);
                        $your_name = isset($your_name) && $your_name != '' ? $your_name : '';

                        $your_email = get_post_meta($cosigner_post_id, 'your_email', true);
                        $your_email = isset($your_email) && $your_email != '' ? $your_email : '';

                        $your_address = get_post_meta($cosigner_post_id, 'your_address', true);
                        $your_address = isset($your_address) && $your_address != '' ? $your_address : '';

                        $your_dob = get_post_meta($cosigner_post_id, 'your_dob', true);
                        $your_dob = isset($your_dob) && $your_dob != '' ? $your_dob : '';

                        $your_phone = get_post_meta($cosigner_post_id, 'your_phone', true);
                        $your_phone = isset($your_phone) && $your_phone != '' ? $your_phone : '';

                        // business info

                        $business_name = get_post_meta($cosigner_post_id, 'business_name', true);
                        $business_name = isset($business_name) && $business_name != '' ? $business_name : '';

                        $business_address = get_post_meta($cosigner_post_id, 'business_address', true);
                        $business_address = isset($business_address) && $business_address != '' ? $business_address : '';

                        $business_position = get_post_meta($cosigner_post_id, 'business_position', true);
                        $business_position = isset($business_position) && $business_position != '' ? $business_position : '';

                        $basic_salary = get_post_meta($cosigner_post_id, 'basic_salary', true);
                        $basic_salary = isset($basic_salary) && $basic_salary != '' ? $basic_salary : '';

                        $getpaid = get_post_meta($cosigner_post_id, 'getpaid', true);
                        $getpaid = isset($getpaid) && $getpaid != '' ? $getpaid : '';

                        $job_duration = get_post_meta($cosigner_post_id, 'job_duration', true);
                        $job_duration = isset($job_duration) && $job_duration != '' ? $job_duration : '';

                        $hiring_party_mail = get_post_meta($cosigner_post_id, 'hiring_party_mail', true);
                        $hiring_party_mail = isset($hiring_party_mail) && $hiring_party_mail != '' ? $hiring_party_mail : '';

                        $hiring_party_phone = get_post_meta($cosigner_post_id, 'hiring_party_phone', true);
                        $hiring_party_phone = isset($hiring_party_phone) && $hiring_party_phone != '' ? $hiring_party_phone : '';

                        $bank_money = get_post_meta($cosigner_post_id, 'bank_money', true);
                        $bank_money = isset($bank_money) && $bank_money != '' ? $bank_money : '';
                        ?>


                        <div class="pp-signup-outer pp-updation-form">

                            <div class="pp-signup-inner">

                                <form class="pp-profile-update">

                                    <div class="tab-pane fade show active" id="personal-info" role="tabpanel" aria-labelledby="personal-info-tab">

                                        <div>
                                            <label for="fname">Full Name</label>
                                            <input type="text" placeholder="Your Name" value="<?php echo $your_name; ?>" name="your_name" />
                                        </div>
                                        <div>
                                            <label for="address">Address</label>
                                            <input type="text" placeholder="Address Here" value="<?php echo $your_address; ?>" name="your_address" />
                                        </div>
                                        <div>
                                            <label for="dob">Date of Birth</label>
                                            <input type="date" placeholder="Date Here" value="<?php echo $your_dob; ?>" name="your_dob" />
                                        </div>
                                        <div>
                                            <label for="phoneNumber">Phone Number</label>
                                            <input type="text" placeholder="Date Here" value="<?php echo $your_phone; ?>" name="your_phone" />
                                        </div>
                                        <div>
                                            <label for="email">Email</label>
                                            <input type="email" placeholder="Email Here" value="<?php echo $your_email; ?>" disabled="disabled" readonly="readonly" />
                                        </div>

                                    </div>

                                    <div class="tab-pane fade" id="Business-info" role="tabpanel" aria-labelledby="Business-info-tab">

                                        <div>
                                            <label for="bname">Business Name</label>
                                            <input type="text" placeholder="Business Name" value="<?php echo $business_name; ?>" name="business_name" />
                                        </div>
                                        <div>
                                            <label for="baddress">Business Address</label>
                                            <input type="text" placeholder="Business Address" value="<?php echo $business_address; ?>" name="business_address" />
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="bposition">Position</label>
                                                <input type="text" placeholder="Type Position" value="<?php echo $business_position; ?>" name="business_position" />
                                            </div>
                                            <div class="col-md-6">
                                                <label for="bsalary">Salary</label>
                                                <input type="text" placeholder="$5555" value="<?php echo $basic_salary; ?>" name="basic_salary" />
                                            </div>
                                        </div>
                                        <label for="pay">How often You get paid</label>
                                        <div class="paid-buttons">

                                            <div class="pp-Business-check pp-paid-profile">


                                                <div class="pp-paid-btn">
                                                    <div class="selecotr-item">
                                                        <input type="radio" id="paid-daily" name="getpaid" class="selector-item_radio" value="Daily" <?php echo $getpaid == 'Daily' ? 'checked' : ''; ?>>
                                                        <label for="paid-daily" class="selector-item_label">Daily</label>
                                                    </div>
                                                </div>
                                                <div class="pp-paid-btn">
                                                    <div class="selecotr-item">
                                                        <input type="radio" id="paid-weekly" name="getpaid" class="selector-item_radio" value="Weekly" <?php echo $getpaid == 'Weekly' ? 'checked' : ''; ?>>
                                                        <label for="paid-weekly" class="selector-item_label">Weekly</label>
                                                    </div>
                                                </div>
                                                <div class="pp-paid-btn">
                                                    <div class="selecotr-item">
                                                        <input type="radio" id="paid-bweek" name="getpaid" class="selector-item_radio" value="BiWeekly" <?php echo $getpaid == 'BiWeekly' ? 'checked' : ''; ?>>
                                                        <label for="paid-bweek" class="selector-item_label">Byweek</label>
                                                    </div>
                                                </div>
                                                <div class="pp-paid-btn">
                                                    <div class="selecotr-item">
                                                        <input type="radio" id="paid-monthly" name="getpaid" class="selector-item_radio" value="Monthly" <?php echo $getpaid == 'Monthly' ? 'checked' : ''; ?>>
                                                        <label for="paid-monthly" class="selector-item_label">Monthly</label>
                                                    </div>
                                                </div>
                                            </div>


                                        </div>
                                        <div>
                                            <label for="job-duration">Length of time in months worked on job</label>
                                            <input type="text" id="job-duration" placeholder="2 years" value="<?php echo $job_duration; ?>" name="job_duration" />
                                        </div>
                                        <div>
                                            <label for="hpmail">Email Adress of Hiring Party</label>
                                            <input type="email" placeholder="Hiring Party Email" value="<?php echo $hiring_party_mail; ?>" id="hpmail" name="hiring_party_mail" />
                                        </div>
                                        <div>
                                            <label for="hpphone">Phone Number of Hiring Party</label>
                                            <input type="text" placeholder="Hiring Party Phone Number" value="<?php echo $hiring_party_phone; ?>" id="hpphone" name="hiring_party_phone" />
                                        </div>

                                    </div>
                                    <div class="pp-submit-sec">
                                        <input type="hidden" name="cosigner_id" value="<?php echo $cosigner_post_id; ?>" />
                                        <button type="submit" class="update-profile">Update Profile</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div>



            </div>

            <div class="col-lg-5">
                <div class="pp-cards-heading">
                    <h1 class="text-capitalize">
                        Signed
                        <span class="">Documents</span>
                    </h1>
                </div>

                <?php
                $pp_uploads_files = get_post_meta($cosigner_post_id, 'pp_uploads_files', true);
                $pp_uploads_files = isset($pp_uploads_files) && $pp_uploads_files != '' ? $pp_uploads_files : '';


                if (isset($pp_uploads_files) && $pp_uploads_files != '') {
                    foreach ($pp_uploads_files as $key => $attach_id) {

                        $attach_url = wp_get_attachment_url($attach_id);
                        $attach_title = get_the_title($attach_id);
                ?>
                        <div class="pp-dashboard-outer">
                            <p class="m-0">
                                <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/noun-documents-857991.svg" alt="" />
                                <span><?php echo $attach_title; ?></span>
                            </p>
                            <a href="<?php echo $attach_url; ?>" download> Download </a>
                        </div>
                    <?php
                    }
                } else {
                    ?>

                    <div class="pp-dashboard-outer">
                        <p class="m-0">
                        <h4>There is no file to display</h4>
                        </p>
                    </div>

                <?php
                }
                ?>
            </div>

        </div>
    </section>



<?php
}

/*
 * PP Dashboard profile HTML
 */

function pp_profile_view_html()
{

    $c_user_id = get_current_user_ID();

    $cosigner_post_id = get_user_meta($c_user_id, 'cosigner_post_id', true);
    $cosigner_post_id = isset($cosigner_post_id) && $cosigner_post_id != '' ? $cosigner_post_id : '';
?>

    <header class="header" id="header">
        <div class="header_toggle">
            <i class="bx bx-menu" id="header-toggle"></i>
        </div>
    </header>


    <section>
        <div class="row m-auto pt-4 px-md-3 px-0">
            <!-- cards -->
            <div class="col-lg-7">

                <!-- <div>
                    <div class="pp-cards-heading">
                        <h1 class="text-capitalize">
                            Your Profile Data
                        </h1>
                    </div>
                </div> -->

                <div class="pp-profile-section">




                    <?php
                    // personal information

                    $your_name = get_post_meta($cosigner_post_id, 'your_name', true);
                    $your_name = isset($your_name) && $your_name != '' ? $your_name : '';

                    $your_email = get_post_meta($cosigner_post_id, 'your_email', true);
                    $your_email = isset($your_email) && $your_email != '' ? $your_email : '';

                    $your_address = get_post_meta($cosigner_post_id, 'your_address', true);
                    $your_address = isset($your_address) && $your_address != '' ? $your_address : '';

                    $your_dob = get_post_meta($cosigner_post_id, 'your_dob', true);
                    $your_dob = isset($your_dob) && $your_dob != '' ? $your_dob : '';

                    $your_phone = get_post_meta($cosigner_post_id, 'your_phone', true);
                    $your_phone = isset($your_phone) && $your_phone != '' ? $your_phone : '';

                    // business info

                    $business_name = get_post_meta($cosigner_post_id, 'business_name', true);
                    $business_name = isset($business_name) && $business_name != '' ? $business_name : '';

                    $business_address = get_post_meta($cosigner_post_id, 'business_address', true);
                    $business_address = isset($business_address) && $business_address != '' ? $business_address : '';

                    $business_position = get_post_meta($cosigner_post_id, 'business_position', true);
                    $business_position = isset($business_position) && $business_position != '' ? $business_position : '';

                    $basic_salary = get_post_meta($cosigner_post_id, 'basic_salary', true);
                    $basic_salary = isset($basic_salary) && $basic_salary != '' ? $basic_salary : '';

                    $getpaid = get_post_meta($cosigner_post_id, 'getpaid', true);
                    $getpaid = isset($getpaid) && $getpaid != '' ? $getpaid : '';

                    $job_duration = get_post_meta($cosigner_post_id, 'job_duration', true);
                    $job_duration = isset($job_duration) && $job_duration != '' ? $job_duration : '';

                    $hiring_party_mail = get_post_meta($cosigner_post_id, 'hiring_party_mail', true);
                    $hiring_party_mail = isset($hiring_party_mail) && $hiring_party_mail != '' ? $hiring_party_mail : '';

                    $hiring_party_phone = get_post_meta($cosigner_post_id, 'hiring_party_phone', true);
                    $hiring_party_phone = isset($hiring_party_phone) && $hiring_party_phone != '' ? $hiring_party_phone : '';

                    $bank_money = get_post_meta($cosigner_post_id, 'bank_money', true);
                    $bank_money = isset($bank_money) && $bank_money != '' ? $bank_money : '';
                    ?>

                    <div class="table-responsive pp-profile-edit">
                        <h3><?php echo $bowrer_name; ?></h3>




                        <div class="pp-main-profile">
                            <div class="pp-profile-head">
                                <div class="pp-profile-image">
                                    <img src="<?php echo get_avatar_url($c_user_id, array('size' => 200)); ?>" alt="" />
                                </div>
                                <div class="pp-profile-name">
                                    <h3><?php echo $your_name; ?></h3>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                                            <path d="M20 4H4c-1.103 0-2 .897-2 2v12c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V6c0-1.103-.897-2-2-2zm0 2v.511l-8 6.223-8-6.222V6h16zM4 18V9.044l7.386 5.745a.994.994 0 0 0 1.228 0L20 9.044 20.002 18H4z"></path>
                                        </svg><?php echo $your_email; ?>
                                    </span>
                                    <span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                                            <path d="M17.707 12.293a.999.999 0 0 0-1.414 0l-1.594 1.594c-.739-.22-2.118-.72-2.992-1.594s-1.374-2.253-1.594-2.992l1.594-1.594a.999.999 0 0 0 0-1.414l-4-4a.999.999 0 0 0-1.414 0L3.581 5.005c-.38.38-.594.902-.586 1.435.023 1.424.4 6.37 4.298 10.268s8.844 4.274 10.269 4.298h.028c.528 0 1.027-.208 1.405-.586l2.712-2.712a.999.999 0 0 0 0-1.414l-4-4.001zm-.127 6.712c-1.248-.021-5.518-.356-8.873-3.712-3.366-3.366-3.692-7.651-3.712-8.874L7 4.414 9.586 7 8.293 8.293a1 1 0 0 0-.272.912c.024.115.611 2.842 2.271 4.502s4.387 2.247 4.502 2.271a.991.991 0 0 0 .912-.271L17 14.414 19.586 17l-2.006 2.005z"></path>
                                        </svg><?php echo $your_phone; ?></span>
                                    <span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                                            <path d="M12 14c2.206 0 4-1.794 4-4s-1.794-4-4-4-4 1.794-4 4 1.794 4 4 4zm0-6c1.103 0 2 .897 2 2s-.897 2-2 2-2-.897-2-2 .897-2 2-2z"></path>
                                            <path d="M11.42 21.814a.998.998 0 0 0 1.16 0C12.884 21.599 20.029 16.44 20 10c0-4.411-3.589-8-8-8S4 5.589 4 9.995c-.029 6.445 7.116 11.604 7.42 11.819zM12 4c3.309 0 6 2.691 6 6.005.021 4.438-4.388 8.423-6 9.73-1.611-1.308-6.021-5.294-6-9.735 0-3.309 2.691-6 6-6z"></path>
                                        </svg><?php echo $your_address; ?></span>
                                </div>
                            </div>
                            <div class="pp-user-personal-info">
                                <div class="row">


                                    <div class="col-xl-6 col-12">
                                        <h4>date of Birth</h4>
                                        <p><?php echo $your_dob; ?></p>
                                        <h4>Hiring Party Email</h4>
                                        <p><?php echo $hiring_party_mail; ?></p>
                                        <h4> Hiring Party Phone</h4>
                                        <p><?php echo $hiring_party_phone; ?></p>
                                        <h4> Bank Deposite Money</h4>
                                        <p><?php echo $bank_money; ?></p>
                                        <h4> Pay Duration</h4>
                                        <p><?php echo $getpaid; ?></td>
                                    </div>
                                    <div class="col-xl-6 col-12">
                                        <h4> Business Name</h4>
                                        <p><?php echo $business_name; ?></p>
                                        <h4> Business Address</h4>
                                        <p><?php echo $business_address; ?></p>
                                        <h4> Business Position</h4>
                                        <p><?php echo $business_position; ?></p>
                                        <h4> Basic Salary</h4>
                                        <p><?php echo $basic_salary; ?></p>

                                        <h4> job Duration</h4>
                                        <p><?php echo $job_duration; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>




                </div>



            </div>

            <div class="col-lg-5">
                <div class="pp-cards-heading">
                    <h1 class="text-capitalize">
                        Signed
                        <span class="">Documents</span>
                    </h1>
                </div>

                <?php
                $pp_uploads_files = get_post_meta($cosigner_post_id, 'pp_uploads_files', true);
                $pp_uploads_files = isset($pp_uploads_files) && $pp_uploads_files != '' ? $pp_uploads_files : '';


                if (isset($pp_uploads_files) && $pp_uploads_files != '') {
                    foreach ($pp_uploads_files as $key => $attach_id) {

                        $attach_url = wp_get_attachment_url($attach_id);
                        $attach_title = get_the_title($attach_id);
                ?>
                        <div class="pp-dashboard-outer">
                            <p class="m-0">
                                <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/noun-documents-857991.svg" alt="" />
                                <span><?php echo $attach_title; ?></span>
                            </p>
                            <a href="<?php echo $attach_url; ?>" download> Download </a>
                        </div>
                    <?php
                    }
                } else {
                    ?>

                    <div class="pp-dashboard-outer">
                        <p class="m-0">
                        <h4>There is no file to display</h4>
                        </p>
                    </div>

                <?php
                }
                ?>
            </div>



        </div>
    </section>



<?php
}

/*
 * PP Dashboard Search HTML
 */

function pp_search_html($search_keyword)
{


    $c_user_id = get_current_user_ID();

    $search_q_1 = new WP_Query(array(
        'post_type' => array('pp-course', 'pp-meeting'),
        'post_status' => 'publish',
        's' => $search_keyword,
    ));

    $search_q_2 = new WP_Query(array(
        'post_type' => 'pp-client',
        'post_status' => 'publish',
        's' => $search_keyword,
        'meta_query' => array(
            array(
                'key' => 'pp_cosigner_id',
                'value' => $c_user_id,
                'compare' => '=',
            ),
        ),
    ));

    $search_q = new WP_Query();
    $search_q->posts = array_merge($search_q_1->posts, $search_q_2->posts);

?>

    <header class="header" id="header">
        <div class="header_toggle">
            <i class="bx bx-menu" id="header-toggle"></i>
        </div>
    </header>

    <section>
        <div class="row m-auto pt-4 px-3">
            <!-- cards -->
            <div class="col-lg-7">

                <div>
                    <div class="pp-cards-heading">
                        <h1 class="text-capitalize">
                            Your Search Results
                        </h1>
                    </div>
                </div>

                <div class="pp-meating">
                    <?php
                    // The Loop
                    if ($search_q->posts) {
                        foreach ($search_q->posts as $key => $value) {
                    ?>
                            <div class="pp-upcoming-meetings-card col-lg-7">
                                <div class="pp-meeting-informations d-flex flex-column ml-3">
                                    <h1><?php echo get_the_title($value->ID); ?></h1>
                                </div>
                            </div>
                        <?php
                        }
                    } else {
                        ?>
                        <div class="pp-upcoming-meetings-card col-lg-7">
                            <div class="pp-meeting-informations d-flex flex-column ml-3">
                                <h1>No Result Found</h1>
                            </div>
                        </div>
                    <?php
                    }
                    // Reset Post Data
                    wp_reset_postdata();
                    ?>
                </div>

            </div>
        </div>
    </section>
<?php
}

/*
 * PP Dashboard Meetings HTML
 */

function pp_help_html()
{

    global $PPDashboard_options;

    $PPDashboard_options = get_option('p-p-dash-options');
    $pp_help_mail = isset($PPDashboard_options['pp-help-email']) && $PPDashboard_options['pp-help-email'] != '' ? $PPDashboard_options['pp-help-email'] : '';


    $help_mail_html = '( Add help mail in the dashboard mail setting tab. )';
    if ($pp_help_mail != '') {
        $help_mail_html = '<a href="mailto:' . $pp_help_mail . '"><strong>' . $pp_help_mail . '</strong></a>';
    }
?>
    <header class="header" id="header">
        <div class="header_toggle">
            <i class="bx bx-menu" id="header-toggle"></i>
        </div>
    </header>
    <section>
        <div class="row m-auto pt-4 px-3">
            <div class="col-lg-7">
                <div>
                    <div class="pp-cards-heading">
                        <h1 class="text-capitalize">
                            Help Information
                        </h1>
                    </div>
                </div>
                <div class="pp-meating">
                    <h5 class="alert alert-info">If you need any kind of assistance or have any query, kindly contact to
                        this email <?php echo $help_mail_html; ?> </h5>
                </div>
            </div>
        </div>
    </section>
<?php
}

/*
 * PP Dashboard Meetings HTML
 */

function pp_notifications_html()
{



    $notification_q = new WP_Query(array(
        'post_type' => array('pp-notification'),
        'post_status' => 'publish',
    ));
?>

    <header class="header" id="header">
        <div class="header_toggle">
            <i class="bx bx-menu" id="header-toggle"></i>
        </div>
    </header>

    <section>
        <div class="row m-auto pt-4 px-3">
            <!-- cards -->
            <div class="col-lg-7">

                <div>
                    <div class="pp-cards-heading">
                        <h1 class="text-capitalize">
                            Notifications History
                        </h1>
                    </div>
                </div>

                <div class="pp-meating">
                    <?php
                    // The Loop
                    if ($notification_q->have_posts()) {
                        while ($notification_q->have_posts()) : $notification_q->the_post();
                            global $post;
                            $notification_category = get_post_meta($post->ID, 'notification_category', true);
                            $c_user_id = get_current_user_ID();
                            if ($notification_category == 'loans') {
                                $pp_cosigner_id = get_post_meta($post->ID, 'pp_cosigner_id', true);
                                if ($c_user_id != $pp_cosigner_id) {
                                    continue;
                                }
                            }
                    ?>
                            <div class="pp-upcoming-meetings-card col-lg-7">
                                <div class="pp-meeting-informations d-flex flex-column ml-3">
                                    <h1><a href="javascript:void(0)" class="pp-notify-link" data-action="<?php echo $notification_category; ?>"><?php echo get_the_title($post->ID); ?></a>
                                    </h1>
                                </div>
                            </div>
                        <?php
                        endwhile;
                    } else {
                        ?>
                        <div class="pp-upcoming-meetings-card col-lg-7">
                            <div class="pp-meeting-informations d-flex flex-column ml-3">
                                <h1>No Result Found</h1>
                            </div>
                        </div>
                    <?php
                    }
                    // Reset Post Data
                    wp_reset_postdata();
                    ?>
                </div>

            </div>
        </div>
    </section>
<?php
}

/*
 * PP Dashboard Meetings HTML
 */

function pp_change_pass_html()
{
    $c_user_id = get_current_user_ID();

    $cosigner_post_id = get_user_meta($c_user_id, 'cosigner_post_id', true);
    $cosigner_post_id = isset($cosigner_post_id) && $cosigner_post_id != '' ? $cosigner_post_id : '';
?>

    <header class="header" id="header">
        <div class="header_toggle">
            <i class="bx bx-menu" id="header-toggle"></i>
        </div>
    </header>

    <section>
        <div class="row m-auto pt-4 px-3">
            <!-- cards -->
            <div class="col-lg-7">

                <div>
                    <div class="pp-cards-heading">

                        <h1 class="text-capitalize">
                            Change Password
                        </h1>


                    </div>
                </div>

                <div class="pp-profile-section">

                    <div class="tab-content">

                        <div class="pp-signup-outer pp-updation-form">

                            <div class="pp-signup-inner">

                                <form class="pp-password-update">

                                    <div class="tab-pane fade show active" id="personal-info" role="tabpanel" aria-labelledby="personal-info-tab">

                                        <div>
                                            <label for="old-password">Old Password</label>
                                            <input type="password" placeholder="Old Password" id="old-password" name="old_pass" />
                                        </div>
                                        <div>
                                            <label for="new-password">New Password</label>
                                            <input type="password" placeholder="New Password" id="old-password" name="new_pass" />
                                        </div>
                                        <div>
                                            <label for="retype-password">Re-Type Password</label>
                                            <input type="password" placeholder="Re-Type Password" id="old-password" name="retype_pass" />
                                        </div>

                                    </div>

                                    <div class="pp-submit-sec">
                                        <input type="hidden" name="cosigner_id" value="<?php echo $c_user_id; ?>" />
                                        <button type="submit" class="pp-update-pass">Change Password</button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-lg-5">
                <div class="pp-cards-heading">
                    <h1 class="text-capitalize">
                        Signed
                        <span class="">Documents</span>
                    </h1>
                </div>

                <?php
                $pp_uploads_files = get_post_meta($cosigner_post_id, 'pp_uploads_files', true);
                $pp_uploads_files = isset($pp_uploads_files) && $pp_uploads_files != '' ? $pp_uploads_files : '';


                if (isset($pp_uploads_files) && $pp_uploads_files != '') {
                    foreach ($pp_uploads_files as $key => $attach_id) {

                        $attach_url = wp_get_attachment_url($attach_id);
                        $attach_title = get_the_title($attach_id);
                ?>
                        <div class="pp-dashboard-outer">
                            <p class="m-0">
                                <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/noun-documents-857991.svg" alt="" />
                                <span><?php echo $attach_title; ?></span>
                            </p>
                            <a href="<?php echo $attach_url; ?>" download> Download </a>
                        </div>
                    <?php
                    }
                } else {
                    ?>

                    <div class="pp-dashboard-outer">
                        <p class="m-0">
                        <h4>There is no file to display</h4>
                        </p>
                    </div>

                <?php
                }
                ?>
            </div>

        </div>
    </section>



<?php
}
