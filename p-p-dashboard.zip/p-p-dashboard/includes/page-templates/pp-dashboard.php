<?php
/*
 * Page Template:Dashboard
 * 
 * Responsible for Dashboard Things
 */

if (is_user_logged_in()) {
    $c_user_id = get_current_user_ID();

    $cosigner_post_id = get_user_meta($c_user_id, 'cosigner_post_id', true);
    $cosigner_post_id = isset($cosigner_post_id) && $cosigner_post_id != '' ? $cosigner_post_id : '';

    if ($cosigner_post_id == '') {

        wp_safe_redirect(home_url('/') . '?act=non-cosigner');
    }
}

wp_head();

if (is_user_logged_in()) {

    global $PPDashboard_options;

    $PPDashboard_options = get_option('p-p-dash-options');

    $pp_signin_page = isset($PPDashboard_options['pp-signin-page']) && $PPDashboard_options['pp-signin-page'] != '' ? get_the_permalink($PPDashboard_options['pp-signin-page']) : 'javascript:void(0)';
?>

    <div class="body-pd" id="body-pd">

        <section class="pp-main-header">
            <header class="pp-header">
                <div class="pp-header-main">
                    <div class="pp-header-logo">
                        <a href="<?php echo home_url('/') ?>"><img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/logo.png" alt="" />
                            <span class="pp-logo-text">Peaceful Payback</span>
                        </a>
                    </div>
                    <div class="pp-header-right-side">
                        <div class="pp-header-right-side-search" id="right-search">
                            <input class="nosubmit" type="search" placeholder="Search keywords" id="searchdropdown" />
                            <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/Search.svg" height="18px" width="18px" alt="" />
                        </div>
                        <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/Search.svg" height="18px" width="18px" alt="" id="open" onclick="openSearchDropdown()" />
                        <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/Search.svg" height="18px" width="18px" alt="" id="close" onclick="closeSearchDropdown()" />
                        <div class="pp-header-login">
                            <button type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Add
                                Client</button>
                        </div>
                        <div class="pp-header-right-side-notification">
                            <div class="notification-main">

                                <div class="notification-icon">
                                    <a href="javascript:void(0)" class="pp-user-notification" data-action="notifications"><img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/notifications.svg" class="notification" alt="" /></a>
                                </div>


                                <?php
                                $notification_q = new WP_Query(array(
                                    'post_type' => array('pp-notification'),
                                    'post_status' => 'publish',
                                    'post_per_page' => 5,
                                ));
                                ?>

                                <?php
                                // The Loop
                                if ($notification_q->have_posts()) {
                                ?>

                                    <ul class="notification-list">

                                        <?php
                                        while ($notification_q->have_posts()) : $notification_q->the_post();
                                            global $post;
                                            $notification_category = get_post_meta($post->ID, 'notification_category', true);
                                            $c_user_id = get_current_user_ID();
                                            if ($notification_category == 'loans') {
                                                $pp_cosigner_id = get_post_meta($post->ID, 'pp_cosigner_id', true);
                                                if ($c_user_id != $pp_cosigner_id) {
                                                    continue;
                                                }
                                            }
                                        ?>


                                            <li><a href="javascript:void(0)" class="pp-notify-link" data-action="<?php echo $notification_category; ?>"><?php echo get_the_title($post->ID); ?></a></li>

                                        <?php
                                        endwhile;
                                        ?>
                                    </ul>

                                <?php
                                } else {
                                ?>
                                    <ul class="notification-list">
                                        <li>No Result Found</li>
                                    </ul>
                                <?php
                                }
                                // Reset Post Data
                                wp_reset_postdata();
                                ?>









                            </div>
                            <div class="header_img pp-user-info">
                                <a href="javascript:void(0)" class="pp-user-tog"><img src="<?php echo get_avatar_url($c_user_id, array('size' => 50)); ?>" alt="" /></a>
                                <ul class="logout-drop">
                                    <li><a href="Javascript:void(0)" class="pp-profile-det" data-action="profile-view">View Profile</a></li>
                                    <li><a href="Javascript:void(0)" class="pp-profile-det" data-action="profile-edit">Edit Profile</a></li>
                                    <li><a href="<?php echo wp_logout_url($pp_signin_page); ?>">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
        </section>
        <!-- end header  -->
        <!-- Navbar section -->
        <section class="pp-dashboard-nav">

            <?php pp_dashboard_nav_html('dashboard'); ?>

        </section>
        <!-- Navbar section ends -->
        <!-- inner container starts dashboard -->

        <div class="main-container">
            <?php pp_dashboard_html(); ?>
        </div>

    </div>
<?php
} else {
?>
    <h1> Welcome to the dashboard </h1>
<?php
}
?>
<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pp-add-client">
                <div class="pp-signup">
                    <div class="pp-signup-outer">
                        <div class="pp-signup-inner">
                            <form id="pp-add-borrower">
                                <div class="col-md-10 col-12">
                                    <div class="pp-signup-heading">
                                        <h1 class="text-capitalize">
                                            Let's Add New
                                            <span class="">borrower</span>
                                        </h1>
                                        <p>
                                            Peaceful Payback client says so program exists to allow trustworthy people
                                            to co-signfor other people who are reliable with paying back and in return
                                            to get paid from us to do it.
                                        </p>
                                    </div>
                                    <h3 class="pp-signup-uppar" id="inner-text">
                                        Your Work Informations!
                                    </h3>

                                </div>
                                <div class="tabs">

                                    <div class="mb-3">
                                        <label for="bowrer_bname">Work Name</label>
                                        <input type="text" placeholder="Your Work Name" id="bowrer_bname" name="bowrer_bname" class="form-control" />
                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_baddress">Work Address</label>
                                        <input type="text" placeholder="Your Work Address" id="bowrer_baddress" name="bowrer_baddress" class="form-control" />
                                    </div>

                                    <div class="row mb-3">

                                        <div class="col-md-6">
                                            <label for="bowrer_position">Position</label>
                                            <input type="text" placeholder="Developer" id="bowrer_position" name="bowrer_position" class="form-control" />
                                        </div>

                                        <div class="col-md-6">
                                            <label for="bowrer_salary">Salary</label>
                                            <input type="text" placeholder="$5555" name="bowrer_salary" id="bowrer_salary" class="form-control" />
                                        </div>

                                    </div>

                                    <label for="pay">How often You get paid</label>

                                    <div class="row paid-buttons mb-3">

                                        <div class="row pp-Business-check">

                                            <div class="col-md-3 col-6">
                                                <div class="selecotr-item">
                                                    <input type="radio" id="Daily" name="bowrer_paid" value="Daily" class="selector-item_radio" />
                                                    <label for="Daily" class="selector-item_label">Daily</label>
                                                </div>
                                            </div>

                                            <div class="col-md-3 col-6">
                                                <div class="selecotr-item">
                                                    <input type="radio" id="Weekly" name="bowrer_paid" value="Weekly" class="selector-item_radio" />
                                                    <label for="Weekly" class="selector-item_label">Weekly</label>
                                                </div>
                                            </div>

                                            <div class="col-md-3 col-6">
                                                <div class="selecotr-item">
                                                    <input type="radio" id="Byweek" name="bowrer_paid" value="Byweek" class="selector-item_radio" />
                                                    <label for="Byweek" class="selector-item_label">Byweek</label>
                                                </div>
                                            </div>

                                            <div class="col-md-3 col-6">
                                                <div class="selecotr-item">
                                                    <input type="radio" id="Monthly" name="bowrer_paid" value="Monthly" class="selector-item_radio" checked />
                                                    <label for="Monthly" class="selector-item_label">Monthly</label>
                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_paid">Lengthof time in months worked on job</label>
                                        <input type="text" placeholder="2 years" name="bowrer_paid" id="bowrer_paid" class="form-control" />
                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_hiring_email">Email Adress of Hiring Party</label>
                                        <input type="email" placeholder="Date Here" name="bowrer_hiring_email" class="form-control" id="bowrer_hiring_email" />
                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_hiring_phone">Phone Number of Hiring Party</label>
                                        <input type="email" placeholder="Date Here" name="bowrer_hiring_phone" class="form-control" id="bowrer_hiring_phone" />
                                    </div>

                                    <div class="pp-signup-bottom" id="ppBtnBottom">
                                        <button class="pp-bottom-cancel" type="button" id="prevBtn" data-bs-dismiss="modal" onclick="popNextPrev(0)" aria-label="Close"> Cancel
                                        </button>
                                        <button class="pp-bottom-cont" type="button" id="nextBtn" onclick="popNextPrev(1)"> Continue </button>
                                    </div>

                                </div>
                                <div class="tabs pp-about-form" id="pp-about-form">

                                    <div class="mb-3">
                                        <label for="bowrer_name">Full Name</label>
                                        <input type="text" placeholder="Your Name" name="bowrer_name" id="bowrer_name" class="form-control" />
                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_address">Address</label>
                                        <input type="text" placeholder="Address Here" name="bowrer_address" class="form-control" id="bowrer_address" />
                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_dob">Date of Birth</label>
                                        <input type="date" placeholder="Date Here" name="bowrer_dob" class="form-control" id="bowrer_dob" />
                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_phone">Phone Number</label>
                                        <input type="text" placeholder="Phone Number" id="bowrer_phone" name="bowrer_phone" class="form-control" />
                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_email">Email</label>
                                        <input type="email" placeholder="Email" id="bowrer_email" name="bowrer_email" class="form-control" />
                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_doc_sb">Documents Submitted</label>
                                        <input type="text" placeholder="Yes" id="bowrer_doc_sb" name="bowrer_doc_sb" class="form-control" />
                                    </div>

                                    <div class="row mb-3">

                                        <div class="col-md-6">
                                            <label for="bowrer_due_amount">Amount Request</label>
                                            <input type="text" placeholder="$5555" id="bowrer_due_amount" name="bowrer_due_amount" class="form-control" />
                                        </div>

                                        <div class="col-md-6">
                                            <label for="bowrer_pay_date">Loan Pay-date</label>
                                            <input type="text" placeholder="$5555" id="bowrer_pay_date" name="bowrer_pay_date" class="form-control" />
                                        </div>

                                    </div>

                                    <div class="mb-3">
                                        <label for="bowrer_credit_score">PP's Credit Score for Borrower</label>
                                        <input type="text" placeholder="Yes" id="bowrer_credit_score" name="bowrer_credit_score" class="form-control" />
                                    </div>

                                    <div class="pp-signup-bottom" id="ppBtnBottom">

                                        <button class="pp-bottom-cancel" type="button" id="prevBtn" onclick="popNextPrev(-1)">
                                            Back
                                        </button>

                                        <button class="pp-bottom-cont pp-sb-borrower" type="button" id="nextBtn">
                                            Apply For Account
                                        </button>

                                    </div>

                                </div>

                                <input type="hidden" value="<?php echo get_current_user_id(); ?>" name="pp_cosigner_id" />

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Client Modal -->
<div class="modal fade" id="ppclientmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="ppclientmodalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pp-dis-client">



            </div>
        </div>
    </div>
</div>

<!-- inner container starts popups -->
<?php
wp_footer();
