<?php
/*
 * Page Template:Signin
 * 
 * Responsible for Dashboard Things
 */

global $PPDashboard_options;
$PPDashboard_options = get_option('p-p-dash-options');

$pp_signup_page = isset($PPDashboard_options['pp-signup-page']) && $PPDashboard_options['pp-signup-page'] != '' ? get_the_permalink($PPDashboard_options['pp-signup-page']) : 'javascript:void(0)';
$pp_privacy_page = isset($PPDashboard_options['pp-privacy-page']) && $PPDashboard_options['pp-privacy-page'] != '' ? get_the_permalink($PPDashboard_options['pp-privacy-page']) : 'javascript:void(0)';
$pp_terms_page = isset($PPDashboard_options['pp-terms-page']) && $PPDashboard_options['pp-terms-page'] != '' ? get_the_permalink($PPDashboard_options['pp-terms-page']) : 'javascript:void(0)';
$pp_dashboard_page = isset($PPDashboard_options['pp-adashboard-page']) && $PPDashboard_options['pp-adashboard-page'] != '' ? get_the_permalink($PPDashboard_options['pp-adashboard-page']) : 'javascript:void(0)';

if (is_user_logged_in()) {
    $c_user_id = get_current_user_ID();

    $pp_user_role = get_user_meta($c_user_id, 'pp_user_role', true);
    $pp_user_role = isset($pp_user_role) && $pp_user_role != '' ? $pp_user_role : '';

    if ($pp_user_role == 'cosigner') {

        wp_safe_redirect($pp_dashboard_page);
    }
}

wp_head();




if (is_user_logged_in()) {
    ?>
    <section class="pp-sign-main">
        <div class="pp-signin-main">
            <!-- circle  -->
            <span class="circle-big"></span>
            <span class="circle-orange"></span>
            <span class="circle-small"></span>
            <span class="circle-gray-medium"></span>
            <!-- end circle  -->
            <div class="pp-signin ">
                <div class="pp-signin-outer">
                    <span class="circle-gray"></span>
                    <div class="pp-signin-inner">

                        <div class="row">
                            <div class="col-lg-6 col-sm-12">
                                <div class="pp-signin-left">
                                    <div class="pp-sign-inner-left">
                                        <div class="pp-signon-logo">
                                            <a href="<?php echo home_url('/') ?>"><img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/pp-logo.png" alt=""></a>
                                        </div>
                                        <div class="pp-sign-left-image">
                                            <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/login-photo.png" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-12">
                                <div class="pp-signin-form-main">
                                    <div class="form-text">
                                        <div class="alert alert-info" role="alert"> Please signin with cosigner to access the dashboard.</div>
                                        <a href="<?php echo home_url('/'); ?>" class="pp-signin-gohome"><i class='bx bxs-home-circle'></i>Go to Home</a>
                                    </div>
                                </div>                                
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php
} else {
    ?>
    <section class="pp-sign-main">
        <div class="pp-signin-main">
            <!-- circle  -->
            <span class="circle-big"></span>
            <span class="circle-orange"></span>
            <span class="circle-small"></span>
            <span class="circle-gray-medium"></span>
            <!-- end circle  -->
            <div class="pp-signin ">
                <div class="pp-signin-outer">
                    <span class="circle-gray"></span>
                    <div class="pp-signin-inner">

                        <div class="row">
                            <div class="col-lg-6 col-sm-12">
                                <div class="pp-signin-left">
                                    <div class="pp-sign-inner-left">
                                        <div class="pp-signon-logo">
                                            <a href="<?php echo home_url('/') ?>"><img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/pp-logo.png" alt=""></a>
                                        </div>
                                        <div class="pp-sign-left-image">
                                            <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/login-photo.png" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-12">
                                <div>
                                    <span class="pp-signin-cross">
                                        <a href="<?php echo home_url('/'); ?>"><i class='bx bxs-home-circle'></i></a>
                                    </span>
                                </div>
                                <div class="pp-signin-form-main">
                                    <div class="form-text">
                                        <h2>Welcome to Peaceful Payback</h2>
                                        <p>Please Enter Your Details</p>
                                    </div>
                                    <div class="pp-signin-form">
                                        <form id="regForm" class="pp-signin-form">
                                            <label for="pp-signin-mail">Your Email</label>
                                            <input type="email" name="your_email" id="pp-signin-mail" placeholder="Joshua@someone.com">
                                            <label for="pp-signin-pass">Password</label>
                                            <input type="password" name="your_password" id="pp-signin-pass" placeholder="*****">
                                            <div class="pp-signin-form-btn">
                                                <button type="submit" id="pp-submit-signin" class="pp-signin-login">Login</button>
                                                <span class="pp-signin-or">OR</span>
                                                <a href="<?php echo $pp_signup_page; ?>" class="pp-signin-apply">Apply for Account</a>
                                                <div class="pp-signin-form-footer-btn">
                                                    <a href="<?php echo $pp_privacy_page; ?>"> Privacy Policy </a>
                                                    <a href="<?php echo $pp_terms_page; ?>"> Terms Of Use </a>

                                                    <a href="javascript:void(0)"  data-bs-toggle="modal" data-bs-target="#ppforgotpass"> Forgot Password ?</a>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> 

    <!-- Client Modal -->
    <div class="modal fade" id="ppforgotpass" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
         aria-labelledby="ppforgotpassLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Forgot Password</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pp-dis-forgot">

                    <div class="pp-signup-outer pp-forgot-form">

                        <div class="pp-signup-inner">
                            <form class="pp-forgot-form">

                                <div>
                                    <label for="forgot-email">Email Address</label>
                                    <input type="email" placeholder="Registered Email Address" id="forgot-email"  name="registered_email" />
                                </div>

                                <div class="pp-submit-sec">
                                    <button type="submit" class="pp-forgot-pass" >Change Password</button>
                                </div>

                            </form>
                        </div>

                    </div>


                </div>
            </div>
        </div>
    </div>
    <?php
}
?>





<?php
wp_footer();
