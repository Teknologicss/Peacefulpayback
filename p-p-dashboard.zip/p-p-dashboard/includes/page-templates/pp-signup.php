<?php
/*
 * Page Template:Signup
 * 
 * Responsible for Dashboard Things
 */


wp_head();


global $PPDashboard_options;
$PPDashboard_options = get_option('p-p-dash-options');
 
// doc 1
$pp_doc1_label = isset($PPDashboard_options['pp-doc1-label']) && $PPDashboard_options['pp-doc1-label'] != '' ? $PPDashboard_options['pp-doc1-label'] : 'Agreement Document';
$pp_doc1_link = isset($PPDashboard_options['pp-doc1-link']) && $PPDashboard_options['pp-doc1-link'] != '' ? $PPDashboard_options['pp-doc1-link'] : 'javascript:void(0)';

// doc 2
$pp_doc2_label = isset($PPDashboard_options['pp-doc2-label']) && $PPDashboard_options['pp-doc2-label'] != '' ? $PPDashboard_options['pp-doc2-label'] : 'Agreement Document';
$pp_doc2_link = isset($PPDashboard_options['pp-doc2-link']) && $PPDashboard_options['pp-doc2-link'] != '' ? $PPDashboard_options['pp-doc2-link'] : 'javascript:void(0)';

// doc 3
$pp_doc3_label = isset($PPDashboard_options['pp-doc3-label']) && $PPDashboard_options['pp-doc3-label'] != '' ? $PPDashboard_options['pp-doc3-label'] : 'Agreement Document';
$pp_doc3_link = isset($PPDashboard_options['pp-doc3-link']) && $PPDashboard_options['pp-doc3-link'] != '' ? $PPDashboard_options['pp-doc3-link'] : 'javascript:void(0)';

$pp_signin_page = isset($PPDashboard_options['pp-signin-page']) && $PPDashboard_options['pp-signin-page'] != '' ? get_the_permalink($PPDashboard_options['pp-signin-page']) : 'javascript:void(0)';

?>
<section>
    <header>
        <div class="pp-header-main">
            <div class="pp-header-logo">
                <a href="<?php echo home_url('/'); ?>"><img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/logo.png" alt=""> <span class="pp-logo-text">Peaceful Payback</span></a>
            </div>
            <div class="pp-header-login">
                <a href="<?php echo $pp_signin_page; ?>">Login</a>
            </div>
        </div>
    </header>
</section>
<!-- end header  -->
<section class="pp-sign-main">
    <!-- circle  -->
    <span class="circle-big"></span>
    <span class="circle-orange"></span>
    <span class="circle-small"></span>
    <span class="circle-gray-medium"></span>
    <!-- end circle  -->
    <div class="pp-signup">
        <div class="pp-signup-outer">
            <span class="circle-gray"></span>
            <?php
            if (is_user_logged_in()) {
                ?>
                <div class="pp-signup-inner">
                    <div class="pp-signup-heading">
                        <p>
                            Please Logout first to register new user.
                        </p>
                    </div>
                </div>
                <?php
            } else {
                ?>
                <div class="pp-signup-inner">
                    <form  id="pp-cosigner-signup" enctype="multipart/form-data">
                        <div class="tab">
                            <div class="col-md-10">
                                <div class="pp-signup-heading">
                                    <h1 class="text-capitalize">
                                        Let's Create account
                                        <span class="">with us</span>
                                    </h1>
                                    <p>
                                        Peaceful Payback Client Say So Program exists to allow trust Worth people to co-signfor other people who are reliable With paying back and in return to get paid from us to do it.
                                    </p>
                                </div>

                            </div>
                            <h3 class="pp-signup-uppar" id="inner-text">
                                Documents you need to reed!
                            </h3>

                            <!-- Doc 1 -->
                            <div class="pp-signup-onput-outer">
                                <p class="m-0">
                                    <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/noun-documents-857991.svg" alt=""> <span><?php echo $pp_doc1_label; ?></span>
                                </p>
                                <a href="<?php echo $pp_doc1_link; ?>" class="" download> Download </a>
                            </div>
                            <!-- Doc 2 -->
                            <div class="pp-signup-onput-outer">
                                <p class="m-0">
                                    <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/noun-documents-857991.svg" alt=""> <span><?php echo $pp_doc2_label; ?></span>
                                </p>
                                <a href="<?php echo $pp_doc2_link; ?>" class="" download> Download </a>
                            </div>
                            <!-- Doc 3 -->
                            <div class="pp-signup-onput-outer">
                                <p class="m-0">
                                    <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/noun-documents-857991.svg" alt=""> <span><?php echo $pp_doc3_label; ?></span>
                                </p>
                                <a href="<?php echo $pp_doc3_link; ?>" class="" download> Download </a>
                            </div>

                            <div class="pp-agreement-text d-block" id="needed-documents">
                                <h3 class="text-capitalize">
                                    Documents we required from you!
                                </h3>
                                <p class="text muted">
                                    <span> Nonocompete Agreement</span> <span>Bill in Name</span> <span>SS#</span> <span>Credit Score: PP Score or Experian</span>
                                </p>
                            </div>
                            <div class="pp-signup-bottom" id="ppBtnBottom0">
                                <button class="pp-bottom-cancel" type="button" id="prevBtn" onclick="nextPrev(-1)">
                                    Cancel
                                </button>
                                <button class="pp-bottom-cont" type="button" id="nextBtn" onclick="nextPrev(1)">
                                    Apply For Account
                                </button>
                            </div>

                        </div>
                        <div class="tab pp-about-form">
                            <div class="col-md-10">
                                <div class="pp-signup-heading">
                                    <h1 class="text-capitalize">
                                        Let's Create account
                                        <span class="">with us</span>
                                    </h1>
                                    <p>
                                        Peaceful Payback Client Say So Program exists to allow trust Worth people to co-signfor other people who are reliable With paying back and in return to get paid from us to do it.
                                    </p>
                                </div>
                                <h3 class="pp-signup-uppar" id="inner-text">
                                    About You!
                                </h3>
                            </div>
                            <div>
                                <label for="fname">Full Name</label>
                                <input type="text" placeholder="Your Name" oninput="this.className = ''" name="your_name" />
                            </div>
                            <div>
                                <label for="address">Address</label>
                                <input type="text" placeholder="Address Here" oninput="this.className = ''" name="your_address" />
                            </div>
                            <div>
                                <label for="dob">Date of Birth</label>
                                <input type="date" placeholder="Date Here" oninput="this.className = ''" name="your_dob" />
                            </div>
                            <div>
                                <label for="phoneNumber">Phone Number</label>
                                <input type="text" placeholder="Date Here" oninput="this.className = ''" name="your_phone" />
                            </div>
                            <div>
                                <label for="email">Email</label>
                                <input type="email" placeholder="Email Here" oninput="this.className = ''" name="your_email" />
                            </div>
                            <div class="pp-signup-bottom" id="ppBtnBottom1">
                                <button class="pp-bottom-cancel" type="button" id="prevBtn" onclick="nextPrev(-1)">
                                    Back
                                </button>
                                <button class="pp-bottom-cont" type="button" id="nextBtn" onclick="nextPrev(1)">
                                    Continue
                                </button>
                            </div>
                        </div>
                        <div class="tab">
                            <div class="col-md-10">
                                <div class="pp-signup-heading">
                                    <h1 class="text-capitalize">
                                        Let's Create account
                                        <span class="">with us</span>
                                    </h1>
                                    <p>
                                        Peaceful Payback Client Say So Program exists to allow trust Worth people to co-signfor other people who are reliable With paying back and in return to get paid from us to do it.
                                    </p>
                                </div>
                                <h3 class="pp-signup-uppar" id="inner-text">
                                    Your Business Informations!
                                </h3>
                            </div>

                            <div>
                                <label for="bname">Business Name</label>
                                <input type="text" placeholder="Business Name" oninput="this.className = ''" name="business_name" />
                            </div>
                            <div>
                                <label for="baddress">Business Address</label>
                                <input type="text" placeholder="Business Address" oninput="this.className = ''" name="business_address" />
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="bposition">Position</label>
                                    <input type="text" placeholder="Type Position" oninput="this.className = ''" name="business_position" />
                                </div>
                                <div class="col-md-6">
                                    <label for="bsalary">Salary</label>
                                    <input type="text" placeholder="$5555" oninput="this.className = ''" name="basic_salary" />
                                </div>
                            </div>
                            <label for="pay">How often You get paid</label>
                            <div class="paid-buttons">

                                <div class="row pp-Business-check">


                                    <div class="col-md-3">
                                        <div class="selecotr-item">
                                            <input type="radio" id="paid-daily" name="getpaid" class="selector-item_radio" value="Daily">
                                            <label for="paid-daily" class="selector-item_label">Daily</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="selecotr-item">
                                            <input type="radio" id="paid-weekly" name="getpaid" class="selector-item_radio" value="Weekly">
                                            <label for="paid-weekly" class="selector-item_label">Weekly</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="selecotr-item">
                                            <input type="radio" id="paid-bweek" name="getpaid" class="selector-item_radio" value="BiWeekly">
                                            <label for="paid-bweek" class="selector-item_label">Byweek</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="selecotr-item">
                                            <input type="radio" id="paid-monthly" name="getpaid" class="selector-item_radio" value="Monthly" checked>
                                            <label for="paid-monthly" class="selector-item_label">Monthly</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label for="job-duration">Length of time in months worked on job</label>
                                <input type="text" id="job-duration" placeholder="2 years" oninput="this.className = ''" name="job_duration" />
                            </div>
                            <div>
                                <label for="hpmail">Email Adress of Hiring Party</label>
                                <input type="email" placeholder="Hiring Party Email" oninput="this.className = ''" id="hpmail" name="hiring_party_mail" />
                            </div>
                            <div>
                                <label for="hpphone">Phone Number of Hiring Party</label>
                                <input type="text" placeholder="Hiring Party Phone Number" oninput="this.className = ''" id="hpphone" name="hiring_party_phone" />
                            </div>
                            <div class="pp-signup-bottom" id="ppBtnBottom2">
                                <button class="pp-bottom-cancel" type="button" id="prevBtn" onclick="nextPrev(-1)">
                                    Back
                                </button>
                                <button class="pp-bottom-cont" type="button" id="nextBtn" onclick="nextPrev(1)">
                                    Continue
                                </button>
                            </div>
                        </div>
                        <div class="tab">
                            <div class="col-md-10">
                                <div class="pp-signup-heading">
                                    <h1 class="text-capitalize">
                                        Let's Create account
                                        <span class="">with us</span>
                                    </h1>
                                    <p>
                                        Peaceful Payback Client Say So Program exists to allow trust Worth people to co-signfor other people who are reliable With paying back and in return to get paid from us to do it.
                                    </p>
                                </div>
                                <h3 class="pp-signup-uppar" id="inner-text">
                                    Assests Information
                                </h3>
                            </div>
                            <div>
                                <label for="money">How Much Money Do You Have In The Bank</label>
                                <input type="text" placeholder="$5555" oninput="this.className = ''" name="bank_money" />
                            </div>
                            <div>
                                <h3 class="text-capitalize pt-5 mb-0 fw-bold fs-3 text-start">
                                    File Uploads
                                </h3>
                            </div>
                            <div class="row pp-signup-upload">
                                <div class="col-md-6">
                                    <p>Noncompete Agrement</p>
                                    <label for="non-compare" class="choose-btn" >Upload File</label>
                                    <input accept="application/pdf" type="file" id="non-compare" class="pp-hiddenbtn" name="pp_uploads[non_compete_file]">
                                </div>
                                <div class="col-md-6">
                                    <p>Bill in Name</p>
                                    <label for="bill-in-files" class="choose-btn" >Upload File</label>
                                    <input accept="application/pdf" type="file" id="bill-in-files" class="pp-hiddenbtn" name="pp_uploads[bill_in_file]">

                                </div>
                                <div class="col-md-6">
                                    <p>SS*</p>
                                    <label for="ss-in-files" class="choose-btn" >Upload File</label>
                                    <input accept="application/pdf" type="file" id="ss-in-files" class="pp-hiddenbtn" name="pp_uploads[ss_in_file]">

                                </div>
                                <div class="col-md-6">
                                    <p>Credit Score</p>
                                    <label for="credit-score" class="choose-btn" id="chooseBtn">Upload File</label>
                                    <input accept="application/pdf" type="file" id="credit-score" class="pp-hiddenbtn" name="pp_uploads[credit_score_file]">

                                </div>
                                <div class="col-md-6">
                                    <p>PP Score or Experian</p>
                                    <label for="score-files" class="choose-btn" id="chooseBtn">Upload File</label>
                                    <input accept="application/pdf" type="file" id="score-files" class="pp-hiddenbtn" name="pp_uploads[pp_score_file]">

                                </div>
                            </div>
                            <div class="pp-signup-bottom" id="ppBtnBottom3">
                                <button class="pp-bottom-cancel" type="button" id="prevBtn" onclick="nextPrev(-1)">
                                    Back
                                </button>
                                <button class="pp-bottom-cont co-signer-submit" type="submit" id="nextBtn" onclick="nextPrev(0)">
                                    Submit
                                </button>
                            </div>
                        </div>

                    </form>

                    <div class="pp-done-last" style="display:none;">
                        <div class="pp-signup-heading">
                            <h1 class="text-capitalize">
                                You have successfully applied for the <span class="">Co-Signer Account</span>
                            </h1>
                            <p>
                                Peaceful Payback Client Say So Program exists to allow trust Worth people to co-signfor other people who are reliable With paying back and in return to get paid from us to do it.
                            </p>
                        </div>
                        <div class="pp-done-last-image">
                            <img src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/public/images/lastsearch.png" alt="">
                            <h5>We review your information and credentials And will get back to you!</h5>
                        </div>
                    </div>


                </div>


                <?php
            }
            ?>



        </div>
    </div>
</section>



<?php
wp_footer();
