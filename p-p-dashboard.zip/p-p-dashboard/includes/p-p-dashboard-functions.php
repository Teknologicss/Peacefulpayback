<?php
/*
 * Logout Redirection
 */

//add_filter('logout_redirect', 'pp_logout_redirects', 10, 3);

function pp_logout_redirects($redirect_to, $requested_redirect_to, $user) {

    global $PPDashboard_options;
    $PPDashboard_options = get_option('p-p-dash-options');

    $pp_signin_page = isset($PPDashboard_options['pp-signin-page']) && $PPDashboard_options['pp-signin-page'] != '' ? get_the_permalink($PPDashboard_options['pp-signin-page']) : 'javascript:void(0)';


    if (in_array('subscriber', $user->roles)) {

        $requested_redirect_to = $pp_signin_page;
    } else {

        $requested_redirect_to = $pp_signin_page;
    }

    return $requested_redirect_to;
}

/*
 * Co Signer Trash hook
 */

add_action('wp_trash_post', 'pp_dashboard_multiple_trash');

function pp_dashboard_multiple_trash($post_id = '') {
    // Verify if is trashing multiple posts
    if (isset($_GET['post']) && is_array($_GET['post'])) {
        foreach ($_GET['post'] as $post_id) {
            pp_cosigner_trash_action($post_id);
        }
    } else {
        pp_cosigner_trash_action($post_id);
    }
}

function pp_cosigner_trash_action($post_id) {

    $user_id = get_post_meta($post_id, 'cosigner_user_id', true);
    update_user_meta($user_id, 'cosigner_user_status', 'pending');
}

//function wpdocs_untrash_multiple_posts( $post_id = '' ) {
//    // Verify if is restoring multiple posts
//    if ( isset( $_GET['post'] ) && is_array( $_GET['post'] ) ) {
//        foreach( $_GET['post'] as $post_id ) {
//            wpdocs_your_function( $post_id );
//        }
//    } else {
//        wpdocs_your_function( $post_id );
//    }
//}
//add_action( 'untrash_post', 'wpdocs_untrash_multiple_posts' );



add_action('wp_ajax_pp_client_view', 'pp_client_view_callback');

function pp_client_view_callback() {

    $client_id = isset($_POST['client_id']) && $_POST['client_id'] != '' ? $_POST['client_id'] : '';

    $html_data = '';

    $return_arr = '';


    if (empty($client_id)) {

        $return_arr = array('status' => 'error', 'html' => 'Something went wrong there is no client id.');
        echo json_encode($return_arr);
        wp_die();
    }

    ob_start();
    $bowrer_name = get_post_meta($client_id, 'bowrer_name', true);
    $bowrer_name = isset($bowrer_name) && $bowrer_name != '' ? $bowrer_name : '';

    $bowrer_address = get_post_meta($client_id, 'bowrer_address', true);
    $bowrer_address = isset($bowrer_address) && $bowrer_address != '' ? $bowrer_address : '';

    $bowrer_dob = get_post_meta($client_id, 'bowrer_dob', true);
    $bowrer_dob = isset($bowrer_dob) && $bowrer_dob != '' ? $bowrer_dob : '';

    $bowrer_phone = get_post_meta($client_id, 'bowrer_phone', true);
    $bowrer_phone = isset($bowrer_phone) && $bowrer_phone != '' ? $bowrer_phone : '';

    $bowrer_email = get_post_meta($client_id, 'bowrer_email', true);
    $bowrer_email = isset($bowrer_email) && $bowrer_email != '' ? $bowrer_email : '';

    $bowrer_due_amount = get_post_meta($client_id, 'bowrer_due_amount', true);
    $bowrer_due_amount = isset($bowrer_due_amount) && $bowrer_due_amount != '' ? $bowrer_due_amount : '';

    $bowrer_pay_date = get_post_meta($client_id, 'bowrer_pay_date', true);
    $bowrer_pay_date = isset($bowrer_pay_date) && $bowrer_pay_date != '' ? $bowrer_pay_date : '';

    $bowrer_credit_score = get_post_meta($client_id, 'bowrer_credit_score', true);
    $bowrer_credit_score = isset($bowrer_credit_score) && $bowrer_credit_score != '' ? $bowrer_credit_score : '';

    $pp_cosigner_id = get_post_meta($client_id, 'pp_cosigner_id', true);
    $pp_cosigner_id = isset($pp_cosigner_id) && $pp_cosigner_id != '' ? $pp_cosigner_id : '';

    $cosigner_post_id = get_user_meta($pp_cosigner_id, 'cosigner_post_id', true);
    ?>
    <div class="table-responsive">
        <h3><?php echo $bowrer_name; ?></h3>
        <table class="table table-striped">


            <tbody>
                <tr>
                    <td>Borrower Address</td>
                    <td><?php echo $bowrer_address; ?></td>
                </tr>

                <tr>
                    <td>Borrower Date of Birth</td>
                    <td><?php echo $bowrer_dob; ?></td>
                </tr>

                <tr>
                    <td>Borrower Phone</td>
                    <td><?php echo $bowrer_phone; ?></td>
                </tr>

                <tr>
                    <td>Borrower Email</td>
                    <td><?php echo $bowrer_email; ?></td>
                </tr>
                <tr>
                    <td>Borrower Due Amount</td>
                    <td><?php echo $bowrer_due_amount; ?></td>
                </tr>

                <tr>
                    <td>Borrower Due Amount</td>
                    <td><?php echo $bowrer_due_amount; ?></td>
                </tr>

                <tr>
                    <td>Borrower Pay Date</td>
                    <td><?php echo $bowrer_pay_date; ?></td>
                </tr>

                <tr>
                    <td>Borrower Credit Scores</td>
                    <td><?php echo $bowrer_credit_score; ?></td>
                </tr>

                <tr>
                    <td>Borrower Refferal</td>
                    <td><?php echo get_the_title($cosigner_post_id); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php
    $html_data = ob_get_contents();
    ob_end_clean();

    $return_arr = array('status' => 'success', 'html' => $html_data);

    echo json_encode($return_arr);
    wp_die();
}

/*
 * // A function to perform actions when a post is published.
 */

function on_post_publish($ID, $post) {





    if (get_post_type($ID) == 'pp-course') {
        
    }
}

//add_action('publish_post', 'on_post_publish', 10, 2);



function so_post_40744782($new_status, $old_status, $post) {

    if ($new_status == 'publish' && $old_status != 'publish') {


        /*
         * Course Notification
         */

        if ($post->post_type == 'pp-course') {

            $course_title = get_the_title($post->ID);

            $course_notification = "A new course added {$course_title}";

            $course_post = array(
                'post_title' => wp_strip_all_tags($course_notification),
                'post_status' => 'publish',
                'post_author' => 1,
                'post_type' => 'pp-notification',
            );

            $course_notify_id = wp_insert_post($course_post);

            update_post_meta($course_notify_id, 'notification_status_id', $post->ID);
            update_post_meta($course_notify_id, 'notification_category', 'courses');
        }

        /*
         * Meetings Notifications
         */

        if ($post->post_type == 'pp-meeting') {

            $meeting_title = get_the_title($post->ID);

            $meeting_notification = "A new meeting added {$meeting_title}";

            $meet_post = array(
                'post_title' => wp_strip_all_tags($meeting_notification),
                'post_status' => 'publish',
                'post_author' => 1,
                'post_type' => 'pp-notification',
            );

            $meeting_notify_id = wp_insert_post($meet_post);

            update_post_meta($meeting_notify_id, 'notification_status_id', $post->ID);
            update_post_meta($meeting_notify_id, 'notification_category', 'meetings');
        }


        /*
         * Clients Notifications
         */

        if ($post->post_type == 'pp-client') {

            $client_title = get_the_title($post->ID);

            $cosigner_id = get_post_meta($post->ID, 'pp_cosigner_id', true);


            $client_notification = "client approved successfuly {$client_title}";

            $client_post = array(
                'post_title' => wp_strip_all_tags($client_notification),
                'post_status' => 'publish',
                'post_author' => 1,
                'post_type' => 'pp-notification',
            );

            $client_notify_id = wp_insert_post($client_post);

            update_post_meta($client_notify_id, 'notification_status_id', $post->ID);
            update_post_meta($client_notify_id, 'notification_category', 'loans');
            update_post_meta($client_notify_id, 'pp_cosigner_id', $cosigner_id);
        }
    }
}

add_action('transition_post_status', 'so_post_40744782', 10, 3);
