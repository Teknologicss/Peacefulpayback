<?php
/*
 * Admin Option Page
 */

add_action('admin_menu', 'Peaceful_add_admin_menu');
add_action('admin_init', 'Peaceful_settings_init');

function Peaceful_add_admin_menu() {

    add_menu_page('Peaceful Payback Dashboard', 'P P Dashboard', 'manage_options', 'peaceful_payback_dashboard', 'Peaceful_options_page');
}

function Peaceful_settings_init() {

    register_setting('pluginPage', 'Peaceful_settings');

    add_settings_section(
            'Peaceful_pluginPage_section', __('Your section description', 'p-p-dashboard'), 'Peaceful_settings_section_callback', 'pluginPage'
    );

    add_settings_field(
            'Peaceful_text_field_0', __('Settings field description', 'p-p-dashboard'), 'Peaceful_text_field_0_render', 'pluginPage', 'Peaceful_pluginPage_section'
    );

    add_settings_field(
            'Peaceful_checkbox_field_1', __('Settings field description', 'p-p-dashboard'), 'Peaceful_checkbox_field_1_render', 'pluginPage', 'Peaceful_pluginPage_section'
    );

    add_settings_field(
            'Peaceful_radio_field_2', __('Settings field description', 'p-p-dashboard'), 'Peaceful_radio_field_2_render', 'pluginPage', 'Peaceful_pluginPage_section'
    );

    add_settings_field(
            'Peaceful_textarea_field_3', __('Settings field description', 'p-p-dashboard'), 'Peaceful_textarea_field_3_render', 'pluginPage', 'Peaceful_pluginPage_section'
    );

    add_settings_field(
            'Peaceful_select_field_4', __('Settings field description', 'p-p-dashboard'), 'Peaceful_select_field_4_render', 'pluginPage', 'Peaceful_pluginPage_section'
    );
}

function Peaceful_text_field_0_render() {

    $options = get_option('Peaceful_settings');
    ?>
    <input type='text' name='Peaceful_settings[Peaceful_text_field_0]' value='<?php echo $options['Peaceful_text_field_0']; ?>'>
    <?php
}

function Peaceful_checkbox_field_1_render() {

    $options = get_option('Peaceful_settings');
    ?>
    <input type='checkbox' name='Peaceful_settings[Peaceful_checkbox_field_1]' <?php checked($options['Peaceful_checkbox_field_1'], 1); ?> value='1'>
    <?php
}

function Peaceful_radio_field_2_render() {

    $options = get_option('Peaceful_settings');
    ?>
    <input type='radio' name='Peaceful_settings[Peaceful_radio_field_2]' <?php checked($options['Peaceful_radio_field_2'], 1); ?> value='1'>
    <?php
}

function Peaceful_textarea_field_3_render() {

    $options = get_option('Peaceful_settings');
    ?>
    <textarea cols='40' rows='5' name='Peaceful_settings[Peaceful_textarea_field_3]'> 
        <?php echo $options['Peaceful_textarea_field_3']; ?>
    </textarea>
    <?php
}

function Peaceful_select_field_4_render() {

    $options = get_option('Peaceful_settings');
    ?>
    <select name='Peaceful_settings[Peaceful_select_field_4]'>
        <option value='1' <?php selected($options['Peaceful_select_field_4'], 1); ?>>Option 1</option>
        <option value='2' <?php selected($options['Peaceful_select_field_4'], 2); ?>>Option 2</option>
    </select>

    <?php
}

function Peaceful_settings_section_callback() {

    echo __('This section description', 'p-p-dashboard');
}

function Peaceful_options_page() {
    ?>
    <form action='options.php' method='post'>

        <h2>Peaceful Payback Dashboard</h2>

        <?php
        settings_fields('pluginPage');
        do_settings_sections('pluginPage');
        submit_button();
        ?>

    </form>
    <?php
}