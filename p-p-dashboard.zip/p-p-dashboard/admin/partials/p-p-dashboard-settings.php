<?php
if (!defined('ABSPATH'))
    exit;

class PPDashboard_Setting_Page {

    private $dir;
    private $file;
    private $plugin_name;
    private $plugin_slug;
    private $textdomain;
    private $options;
    private $settings;

    public function __construct($plugin_name, $plugin_slug, $file) {
        $this->file = $file;
        $this->plugin_slug = $plugin_slug;
        $this->plugin_name = $plugin_name;
        $this->textdomain = 'p-p-dashboard';
        add_action('admin_init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_menu_item'));
        add_filter('plugin_action_links_' . plugin_basename($this->file), array($this, 'add_settings_link'));
    }

    /**
     * Initialise settings
     * @return void
     */
    public function init() {
        $this->settings = $this->settings_fields();
        $this->options = $this->get_options();
        $this->register_settings();
    }

    /**
     * Add settings page to admin menu
     * @return void
     */
    public function add_menu_item() {
        global $PPDashboard_options;

        $PPDashboard_options = get_option('p-p-dash-options');

        add_menu_page('PP Setting', 'PP Dashboard', 'manage_options', 'PPDashboard-menu', array($this, 'ppdashboard_settings_page'), 'dashicons-admin-generic', 3);
    }

    /**
     * Add settings link to plugin list table
     * @param  array $links Existing links
     * @return array 		Modified links
     */
    public function add_settings_link($links) {
        $settings_link = '<a href="options-general.php?page=' . $this->plugin_slug . '">' . __('Settings', $this->textdomain) . '</a>';
        array_push($links, $settings_link);
        return $links;
    }

    /**
     * Build settings fields
     * @return array Fields to be displayed on settings page
     */
    private function settings_fields() {
        global $PPDashboard_options;

        $PPDashboard_options = get_option('p-p-dash-options');

        //$PPDashboard_between = isset($PPDashboard_options['PPDashboard-chat-between']) && $PPDashboard_options['PPDashboard-chat-between'] != '' ? $PPDashboard_options['PPDashboard-chat-between'] : '0';

        $pages_args = array(
            'numberposts' => -1,
            'fields' => 'ids',
            'post_status' => 'publish',
            'post_type' => 'page',
        );

        $pages = get_posts($pages_args);
        $admin_pages = array(0 => __('Select Page', $this->textdomain));
        //$admin_pages = array();

        if (isset($pages) && !empty($pages)) {

            foreach ($pages as $page) {
                if ($page != "") {
                    $admin_pages[$page] = get_the_title($page);
                }
            }
        }

        $settings['page_settings'] = array(
            'title' => __('Page Settings', $this->textdomain),
            'description' => __('Here you can set general setting of pages.', $this->textdomain),
            'fields' => array(
                array(
                    'id' => 'pp-adashboard-page',
                    'label' => __('Dashboard Page', $this->textdomain),
                    'description' => __('Select the dashboard page.', $this->textdomain),
                    'type' => 'select',
                    'options' => $admin_pages,
                    'default' => '',
                    'class' => '',
                ),
                array(
                    'id' => 'pp-signin-page',
                    'label' => __('Signin Page', $this->textdomain),
                    'description' => __('Select the signin page for login.', $this->textdomain),
                    'type' => 'select',
                    'options' => $admin_pages,
                    'default' => '',
                    'class' => '',
                ),
                array(
                    'id' => 'pp-signup-page',
                    'label' => __('Signup Page', $this->textdomain),
                    'description' => __('Select the signup page for Register.', $this->textdomain),
                    'type' => 'select',
                    'options' => $admin_pages,
                    'default' => '',
                    'class' => '',
                ),
                array(
                    'id' => 'pp-privacy-page',
                    'label' => __('Privacy Policy Page', $this->textdomain),
                    'description' => __('Select the Privacy Policy page before signin.', $this->textdomain),
                    'type' => 'select',
                    'options' => $admin_pages,
                    'default' => '',
                    'class' => '',
                ),
                array(
                    'id' => 'pp-terms-page',
                    'label' => __('Terms of Use Page', $this->textdomain),
                    'description' => __('Select the Terms of Use page before signin.', $this->textdomain),
                    'type' => 'select',
                    'options' => $admin_pages,
                    'default' => '',
                    'class' => '',
                ),
                array(
                    'id' => 'pp-signin-redirect',
                    'label' => __('Signin Redirect URL', $this->textdomain),
                    'description' => __('Select the page to redirect after successfully logged in.', $this->textdomain),
                    'type' => 'select',
                    'options' => $admin_pages,
                    'default' => '',
                    'class' => '',
                ),
                
            )
        );
        
        
        $settings['signup_settings'] = array(
            'title' => __('Signup Settings', $this->textdomain),
            'description' => __('Here you can set general setting of pages.', $this->textdomain),
            'fields' => array(
                // Doc 1
                array(
                    'id' => 'pp-doc1-label',
                    'label' => __('Reed Document 1 Label', $this->textdomain),
                    'description' => __('Add label of 1st must read document.', $this->textdomain),
                    'type' => 'text',
                    'default' => 'Agreement Document',
                    'placeholder'=>'Document Label Here',
                    'class' => '',
                ),
                array(
                    'id' => 'pp-doc1-link',
                    'label' => __('Reed Document 1 Link', $this->textdomain),
                    'description' => __('Add link of 1st must read document.', $this->textdomain),
                    'type' => 'text',
                    'placeholder'=>'Document Link Here',
                    'default' => 'Agreement Document',
                    'class' => '',
                ),
                // Doc 2
                array(
                    'id' => 'pp-doc2-label',
                    'label' => __('Reed Document 2 Label', $this->textdomain),
                    'description' => __('Add label of 2nd must read document.', $this->textdomain),
                    'type' => 'text',
                    'placeholder'=>'Document Label Here',
                    'default' => 'Agreement Document',
                    'class' => '',
                ),
                array(
                    'id' => 'pp-doc2-link',
                    'label' => __('Reed Document 2 Link', $this->textdomain),
                    'description' => __('Add link of 2nd must read document.', $this->textdomain),
                    'type' => 'text',
                    'placeholder'=>'Document Link Here',
                    'default' => 'Agreement Document',
                    'class' => '',
                ),
                // Doc 3
                array(
                    'id' => 'pp-doc3-label',
                    'label' => __('Reed Document 3 Label', $this->textdomain),
                    'description' => __('Add label of 3rd must read document.', $this->textdomain),
                    'type' => 'text',
                    'placeholder'=>'Document Label Here',
                    'default' => 'Agreement Document',
                    'class' => '',
                ),
                array(
                    'id' => 'pp-doc3-link',
                    'label' => __('Reed Document 3rd Link', $this->textdomain),
                    'description' => __('Add link of 3rd must read document.', $this->textdomain),
                    'type' => 'text',
                    'placeholder'=>'Document Link Here',
                    'default' => 'Agreement Document',
                    'class' => '',
                ),
                
                
            )
        );


        $settings['mail_settings'] = array(
            'title' => __('Mail Settings', $this->textdomain),
            'description' => __('Here you can set email setting.', $this->textdomain),
            'fields' => array(
                array(
                    'id' => 'pp-cosigner-admin-mail',
                    'label' => __('Co Signer Admin  Mail', $this->textdomain),
                    'description' => __('Email me after each cosigner registeration.', $this->textdomain),
                    'type' => 'text',
                    'default' => '',
                    'placeholder'=>'Admin Email',
                    'class' => '',
                ),
                array(
                    'id' => 'pp-help-email',
                    'label' => __('Help Information  Email', $this->textdomain),
                    'description' => __('Please add email for help in case of any query for co-signer.', $this->textdomain),
                    'type' => 'text',
                    'default' => '',
                    'placeholder'=>'Help Email',
                    'class' => '',
                ),
                
                
            )
        );
        
        
        

        $settings = apply_filters('plugin_settings_fields', $settings);


        return $settings;
    }

    /**
     * Options getter
     * @return array Options, either saved or default ones.
     */
    public function get_options() {
        $options = get_option($this->plugin_slug);
        if (!$options && is_array($this->settings)) {
            $options = Array();
            foreach ($this->settings as $section => $data) {
                foreach ($data['fields'] as $field) {
                    $options[$field['id']] = isset($field['default']) ? $field['default'] : '';
                }
            }

            add_option($this->plugin_slug, $options);
        }
        return $options;
    }

    /**
     * Register plugin settings
     * @return void
     */
    public function register_settings() {
        if (is_array($this->settings)) {
            register_setting($this->plugin_slug, $this->plugin_slug, array($this, 'validate_fields'));
            foreach ($this->settings as $section => $data) {
                add_settings_section($section, $data['title'], array($this, 'settings_section'), $this->plugin_slug);
                foreach ($data['fields'] as $field) {
                    $fields_args = array('field' => $field);
                    if (isset($field['class']) && $field['class'] != '') {
                        $fields_args = array('field' => $field, 'class' => $field['class']);
                    }
                    add_settings_field($field['id'], $field['label'], array($this, 'display_field'), $this->plugin_slug, $section, $fields_args);
                }
            }
        }
    }

    public function settings_section($section) {
        $html = '<p> ' . $this->settings[$section['id']]['description'] . '</p>' . "\n";
        echo ($html);
    }

    /**
     * Generate HTML for displaying fields
     * @param  array $args Field data
     * @return void
     */
    public function display_field($args) {
        $field = $args['field'];
        $html = '';

        $option_name = $this->plugin_slug . "[" . $field['id'] . "]";

        $default_val = isset($this->options[$field['default']]) && $this->options[$field['default']] != '' ? $this->options[$field['default']] : '';

        $data = isset($this->options[$field['id']]) ? $this->options[$field['id']] : $default_val;


        switch ($field['type']) {
            case 'text':
            case 'password':
            case 'number':
                $html .= '<input id="' . esc_attr($field['id']) . '" type="' . $field['type'] . '" name="' . esc_attr($option_name) . '" placeholder="' . esc_attr($field['placeholder']) . '" value="' . $data . '"/>' . "\n";
                break;
            case 'color':
                $html .= '<input class="ppdashboard-color-field" id="' . esc_attr($field['id']) . '" type="' . $field['type'] . '" name="' . esc_attr($option_name) . '" placeholder="' . esc_attr($field['placeholder']) . '" value="' . $data . '"/>' . "\n";
                break;
            case 'button':
                $html .= '<button class="' . esc_attr($field['ext_class']) . '" id="' . esc_attr($field['id']) . '" type="' . $field['type'] . '" name="' . esc_attr($option_name) . '" >' . esc_attr($field['button_label']) . '</button>' . "\n";
                break;
            case 'text_secret':
                $html .= '<input id="' . esc_attr($field['id']) . '" type="text" name="' . esc_attr($option_name) . '" placeholder="' . esc_attr($field['placeholder']) . '" value=""/>' . "\n";
                break;
            case 'textarea':
                $html .= '<textarea id="' . esc_attr($field['id']) . '" rows="7" cols="70" name="' . esc_attr($option_name) . '" placeholder="' . esc_attr($field['placeholder']) . '">' . $data . '</textarea><br/>' . "\n";
                break;
            case 'checkbox':
                $checked = '';
                if ($data && 'on' == $data) {
                    $checked = 'checked="checked"';
                }
                $html .= '<input id="' . esc_attr($field['id']) . '" type="' . $field['type'] . '" name="' . esc_attr($option_name) . '" ' . $checked . '/>' . "\n";
                break;
            case 'checkbox_multi':
                foreach ($field['options'] as $k => $v) {
                    $checked = false;
                    if (is_array($data) && in_array($k, $data)) {
                        $checked = true;
                    }
                    $html .= '<label for="' . esc_attr($field['id'] . '_' . $k) . '"><input type="checkbox" ' . checked($checked, true, false) . ' name="' . esc_attr($option_name) . '[]" value="' . esc_attr($k) . '" id="' . esc_attr($field['id'] . '_' . $k) . '" /> ' . $v . '</label> ';
                }
                break;
            case 'radio':
                foreach ($field['options'] as $k => $v) {
                    $checked = false;
                    if ($k == $data) {
                        $checked = true;
                    }
                    $html .= '<label for="' . esc_attr($field['id'] . '_' . $k) . '"><input type="radio" ' . checked($checked, true, false) . ' name="' . esc_attr($option_name) . '" value="' . esc_attr($k) . '" id="' . esc_attr($field['id'] . '_' . $k) . '" /> ' . $v . '</label> ';
                }
                break;
            case 'select':
                $html .= '<select name="' . esc_attr($option_name) . '" id="' . esc_attr($field['id']) . '">';
                foreach ($field['options'] as $k => $v) {
                    $selected = false;
                    if ($k == $data) {
                        $selected = true;
                    }
                    $html .= '<option ' . selected($selected, true, false) . ' value="' . esc_attr($k) . '">' . $v . '</option>';
                }
                $html .= '</select> ';
                break;
            case 'select_multi':
                $html .= '<select name="' . esc_attr($option_name) . '[]" id="' . esc_attr($field['id']) . '" multiple="multiple">';
                foreach ($field['options'] as $k => $v) {
                    $selected = false;
                    if (in_array($k, $data)) {
                        $selected = true;
                    }
                    $html .= '<option ' . selected($selected, true, false) . ' value="' . esc_attr($k) . '" />' . $v . '</label> ';
                }
                $html .= '</select> ';
                break;
        }
        switch ($field['type']) {
            case 'checkbox_multi':
            case 'radio':
            case 'select_multi':
                $html .= '<br/><span class="description">' . $field['description'] . '</span>';
                break;
            default:
                $html .= '<label for="' . esc_attr($field['id']) . '"><span class="description">' . $field['description'] . '</span></label>' . "\n";
                break;
        }
        echo ($html);
    }

    /**
     * Validate individual settings field
     * @param  array $data Inputted value
     * @return array       Validated value
     */
    public function validate_fields($data) {
        return $data;
    }

    /**
     * Load settings page content
     * @return void
     */
    public function ppdashboard_settings_page() {
        ?>
        <div class="wrap pp-admin-container" id="<?php echo ($this->plugin_slug); ?>">
            <h2><?php _e('PPDashboard Settings', $this->textdomain); ?></h2>

            <h2 class="nav-tab-wrapper settings-tabs hide-if-no-js">
                <?php
                foreach ($this->settings as $section => $data) {
                    echo '<a href="#' . $section . '" class="nav-tab">' . $data['title'] . '</a>';
                }
                ?>
            </h2>
            <?php $this->do_script_for_tabbed_nav(); ?>
            <!-- Tab navigation ends -->
            <form action="options.php" method="POST">
                <?php settings_fields($this->plugin_slug); ?>
                <div class="settings-container">
                    <?php do_settings_sections($this->plugin_slug); ?>
                </div>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    /**
     * Print jQuery script for tabbed navigation
     * @return void
     */
    private function do_script_for_tabbed_nav() {
        ?>
        <script>
            jQuery(document).ready(function ($) {
                /*
                 * functions to save active tab in cookie
                 */
                function ppdashboard_setCookie(key, value, expiry) {
                    var expires = new Date();
                    expires.setTime(expires.getTime() + (expiry * 24 * 60 * 60 * 1000));
                    document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
                }
                function ppdashboard_getCookie(key) {
                    var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
                    return keyValue ? keyValue[2] : null;
                }
                function ppdashboard_eraseCookie(key) {
                    var keyValue = ppdashboard_getCookie(key);
                    ppdashboard_setCookie(key, keyValue, '-1');
                }

                /*
                 * functions to save active tab in cookie
                 */

                var headings = jQuery('.settings-container > h2, .settings-container > h3');
                var paragraphs = jQuery('.settings-container > p');
                var tables = jQuery('.settings-container > table');
                var triggers = jQuery('.settings-tabs a');
                triggers.each(function (i) {
                    triggers.eq(i).on('click', function (e) {
                        e.preventDefault();
                        triggers.removeClass('nav-tab-active');
                        headings.hide();
                        paragraphs.hide();
                        tables.hide();
                        ppdashboard_eraseCookie('pp-tab-active');
                        triggers.eq(i).addClass('nav-tab-active');
                        headings.eq(i).show();
                        paragraphs.eq(i).show();
                        tables.eq(i).show();
                        ppdashboard_setCookie('pp-tab-active', i, '1'); //(key,value,expiry in days)

                    });
                });
                var pp_active = ppdashboard_getCookie('pp-tab-active');
                pp_active = typeof pp_active !== 'undefined' && pp_active != '' ? pp_active : 0;
                triggers.eq(pp_active).click();
                jQuery('.p-p-dash-chat-between input[type="radio"]').on('click', function (e) {
                    var chat_between = jQuery(this).val();
                    if (typeof chat_between !== 'undefined' && chat_between != '') {
                        if (chat_between == '1' || chat_between == '2') {
                            jQuery('.p-p-dash-admin-dropdown').show();
                        } else {
                            jQuery('.p-p-dash-admin-dropdown').hide();
                        }
                    }
                });
                jQuery('.ppdashboard-usertype input[type="radio"]').on('click', function (e) {
                    var user_type = jQuery(this).val();
                    if (typeof user_type !== 'undefined' && user_type != '') {
                        if (user_type == '2') {
                            jQuery('.ppdashboard-login-type').show();
                            jQuery('.ppdashboard-logintype-field').show();

                        } else {
                            jQuery('.ppdashboard-login-type').hide();
                            jQuery('.ppdashboard-logintype-field').hide();
                        }
                    }
                });
            });
        </script>
        <?php
    }

}

$settings = new PPDashboard_Setting_Page("PPDashboard", "p-p-dash-options", __FILE__);