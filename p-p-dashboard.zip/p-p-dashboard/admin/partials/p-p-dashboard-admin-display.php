<?php
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.teknologics.net
 * @since      1.0.0
 *
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/admin/partials
 */
add_action('wp_ajax_pp_send_rejection_email', 'pp_send_rejection_email_callback');

function pp_send_rejection_email_callback() {

    $post_ID = isset($_POST['post_ID']) && $_POST['post_ID'] != '' ? $_POST['post_ID'] : '';
    $pp_reject_reason = isset($_POST['pp_reject_reason']) && $_POST['pp_reject_reason'] != '' ? $_POST['pp_reject_reason'] : '';


    $return_arr = array();

    if ($post_ID == '') {

        $return_arr = array(
            'status' => 'error',
            'message' => __('Ooops ! something went wrong from fetching post id.', 'pp-dashboard'),
        );

        echo json_encode($return_arr);
        wp_die();
    }

    if ($pp_reject_reason == '') {

        $return_arr = array(
            'status' => 'error',
            'message' => __('Please add the rejection reason in the rejection box.', 'pp-dashboard'),
        );

        echo json_encode($return_arr);
        wp_die();
    }

    $your_email = get_post_meta($post_ID, 'your_email', true);
    $your_email = isset($your_email) && $your_email != '' ? $your_email : '';

    $your_name = get_post_meta($post_ID, 'your_name', true);
    $your_name = isset($your_name) && $your_name != '' ? $your_name : '';


    $pp_dashboard_logo = P_P_DASHBOARD_PLUGIN_URL . '/public/images/logo.png';

    $template_message = 'Sorry ! you are rejected due to the following reason.';

    $html_user_template = '<!DOCTYPE html>
                                <html>
                                   <head>
                                      <title>' . __("User Regection", "pp-dashboard") . '</title>
                                   </head>
                                   <body>
                                      <table class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #f6f6f6; width: 100%;" border="0" cellspacing="0" cellpadding="0">
                                         <tbody>
                                            <tr>
                                               <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;"></td>
                                               <td class="container" style="font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 580px; padding: 10px; width: 580px; margin: 0 auto !important;">
                                                  <div class="content" style="box-sizing: border-box; display: block; margin: 0 auto; max-width: 580px; padding: 10px;">
                                                     <table class="main" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background: #fff; border-radius: 3px; width: 100%;">
                                                        <tbody>
                                                           <tr>
                                                              <td class="wrapper" style="font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 20px;">
                                                                 <table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;" border="0" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                       <tr style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                                          <td class="alert" style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 16px; vertical-align: top; color: #000; font-weight: 500; text-align: center; border-radius: 3px 3px 0 0; background-color: #fff; margin: 0; padding: 20px;" align="center" valign="top" bgcolor="#fff">
                                                                             <img class="alignnone size-full wp-image-1437" src="' . $pp_dashboard_logo . '" width="80" height="80" alt="site logo"/>
                                                                          </td>
                                                                       </tr>
                                                                       <tr>
                                                                          <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;"><span style="font-family: sans-serif; font-weight: normal;">Hello </span><span style="font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;"><b> ' . $your_name . ',</b></span></p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $template_message . '</p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">' . $pp_reject_reason . '</p>
                                                                             <p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;"><strong>Thanks!</strong>
                                                                          </td>
                                                                       </tr>
                                                                    </tbody>
                                                                 </table>
                                                              </td>
                                                           </tr>
                                                        </tbody>
                                                     </table>                     
                                                     &nbsp;
                                                  </div>
                                               </td>               
                                            </tr>
                                         </tbody>
                                      </table>
                                   </body>
                                </html>';

    $subject_admin = 'User Regection';
    $from_d = get_bloginfo('name') . ' <' . get_option('admin_email') . '>';
    $headers = array('Content-Type: text/html; charset=UTF-8', 'From: ' . $from_d . '');

    if (wp_mail($your_email, $subject_admin, $html_user_template, $headers)) {

        $return_arr = array(
            'status' => 'success',
            'message' => __('Rejection mail sent to the user successfullly.', 'pp-dashboard'),
        );

        echo json_encode($return_arr);
        wp_die();
    } else {

        $return_arr = array(
            'status' => 'error',
            'message' => __('Something went wrong mail not sent to the user.', 'pp-dashboard'),
        );

        echo json_encode($return_arr);
        wp_die();
    }
}

/*
 * Items ajax
 * @return html
 */

function pp_add_det_item($post_id = '', $excerpt_length = '') {

    $title = isset($_POST['det_item_title']) ? $_POST['det_item_title'] : '';

    $before_vid_text = isset($_POST['before_vid_text']) ? $_POST['before_vid_text'] : '';
    $course_video_url = isset($_POST['course_video_url']) ? $_POST['course_video_url'] : '';
    $after_vid_text = isset($_POST['after_vid_text']) ? $_POST['after_vid_text'] : '';
    $course_img_id = isset($_POST['course_img']) ? $_POST['course_img'] : '';

    $rand_num = rand(1000000, 99999999);

    ob_start();
    ?>
    <li id="list-<?php echo absint($rand_num) ?>">
        <div class="multi-list-header" id="list-head-<?php echo absint($rand_num) ?>">
            <ul>
                <li class="drag-point"><a><i class="fa fa-arrows-v"></i></a></li>
                <li class="list-title"><?php echo wp_trim_words($title, 5, '...') ?></li>
                <li class="list-actions">
                    <a class="list-open" data-visible="close" data-id="<?php echo absint($rand_num) ?>" href="javascript:void(0)"><i class="fa fa-chevron-down"></i></a>
                    <a class="list-delete" data-id="<?php echo absint($rand_num) ?>" href="javascript:void(0)"><i class="fa fa-trash"></i></a>
                </li>
            </ul>
        </div>
        <div id="list-content-<?php echo absint($rand_num) ?>" class="multi-list-content" style="display:none;">

            <div class="pp-element-field row">
                <div class="elem-label col-md-3 col-sm-12 col-xs-12">
                    <label><?php esc_html_e('Course Deatil Title', 'p-p-dashboard') ?></label>
                </div>
                <div class="elem-field col-md-9 col-sm-12 col-xs-12">
                    <input name="course_detail_title[]" id="course_detail_title" type="text" value="<?php echo esc_html($title); ?>"/>
                </div>
            </div>

            <div class="pp-element-field">
                <div class="elem-label col-md-3 col-sm-12 col-xs-12">
                    <label><?php esc_html_e('Description (Before Video)', 'p-p-dashboard') ?></label>
                </div>
                <div class="elem-field col-md-9 col-sm-12 col-xs-12">
                    <textarea name="before_vid_text[]"  class="course-desc" rows="4"><?php echo esc_html($before_vid_text); ?></textarea>
                </div>
            </div>

            <div class="pp-element-field">
                <div class="elem-label col-md-3 col-sm-12 col-xs-12">
                    <label><?php esc_html_e('Video Url', 'p-p-dashboard') ?> *</label>
                </div>
                <div class="elem-field col-md-9 col-sm-12 col-xs-12">
                    <input name="course_video_url[]" type="text" value="<?php echo esc_html($course_video_url); ?>" />
                </div>
            </div>

            <div class="pp-element-field">
                <div class="elem-label col-md-3 col-sm-12 col-xs-12">
                    <label><?php esc_html_e('Description (After Video)', 'p-p-dashboard') ?></label>
                </div>
                <div class="elem-field col-md-9 col-sm-12 col-xs-12">
                    <textarea name="after_vid_text[]"  class="course-desc" rows="4"><?php echo esc_html($after_vid_text); ?></textarea>
                </div>
            </div>
            
            <div class="pp-element-field">
                    <div class="elem-label col-md-3 col-sm-12 col-xs-12">
                        <label><?php esc_html_e('Course Image', 'p-p-dashboard') ?></label>
                    </div>
                    <div class="elem-field col-md-9 col-sm-12 col-xs-12">
                        <?php echo multi_media_uploader_field('course_img',$course_img_id,true); ?>
                    </div>
            </div>
            
            <div class="multi-list-update">
                <a class="pp-bk-btn" href="javascript:void(0)"><?php esc_html_e('Update', 'p-p-dashboard') ?></a>
            </div>

        </div>
    </li>
    <?php
    $html = ob_get_clean();
    echo json_encode(array('html' => $html));
    die;
}

add_action('wp_ajax_pp_add_detail_item', 'pp_add_det_item');



function multi_media_uploader_field($name, $value = '',$display_name = true) {
    
    $image = '">Add Media';
    $image_str = '';
    $image_size = 'full';
    $display = 'none';
    //$value = explode(',', $value);

    if (!empty($value)) {
        //foreach ($value as $values) {
            if ($image_attributes = wp_get_attachment_image_src($value, $image_size)) {
                $image_str .= '<li data-attechment-id=' . $value . '><a href="' . $image_attributes[0] . '" target="_blank"><img src="' . $image_attributes[0] . '" /></a><i class="dashicons dashicons-no delete-img"></i></li>';
            }
        //}
    }

    if ($image_str) {
        $display = 'inline-block';
    }
    
    $name_attr='id="' . $name . '"';
    
    if($display_name){
        
        $name_attr = 'name="' . $name . '[]"';
        
    }
    
    

    return '<div class="multi-upload-medias"><a href="#" class="wc_multi_upload_image_button button' . $image . '</a><ul class="pp-img-holder">' . $image_str . '</ul><input type="hidden" class="attechments-ids ' . $name . '" '.$name_attr.' value="' . esc_attr($value) . '" /></div>';
}