<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://www.teknologics.net
 * @since      1.0.0
 *
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/admin
 * @author     Joshua Victor <joshua.teknologics@gmail.com>
 */
class P_P_Dashboard_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {

        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->load_dependencies();
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function load_dependencies() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in P_P_Dashboard_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The P_P_Dashboard_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */
        /**
         * The class responsible for defining all actions that occur in the admin area.
         */
        require_once P_P_DASHBOARD_PLUGIN_PATH . 'admin/partials/p-p-dashboard-admin-display.php';
        require_once P_P_DASHBOARD_PLUGIN_PATH . 'admin/partials/p-p-dashboard-settings.php';
        require_once P_P_DASHBOARD_PLUGIN_PATH . 'admin/post-types/p-p-clients.php';
        require_once P_P_DASHBOARD_PLUGIN_PATH . 'admin/post-types/p-p-courses.php';
        require_once P_P_DASHBOARD_PLUGIN_PATH . 'admin/post-types/p-p-meetings.php';
        require_once P_P_DASHBOARD_PLUGIN_PATH . 'admin/post-types/p-p-cosigner.php';
        require_once P_P_DASHBOARD_PLUGIN_PATH . 'admin/post-types/p-p-notifications.php';
        
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in P_P_Dashboard_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The P_P_Dashboard_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */
        
        wp_enqueue_style('jqte', plugin_dir_url(__FILE__) . 'css/jquery-te.css');        
        wp_enqueue_style('p-p-dashboard-admin', plugin_dir_url(__FILE__) . 'css/p-p-dashboard-admin.css', array(), $this->version, 'all');
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in P_P_Dashboard_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The P_P_Dashboard_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */
        
        wp_enqueue_script('jqte', plugin_dir_url(__FILE__) . 'js/jquery-te.min.js');        
        wp_enqueue_script('p-p-dashboard-admin', plugin_dir_url(__FILE__) . 'js/p-p-dashboard-admin.js', array('jquery'), $this->version, false);
        
        
        $healthieo_common_arr = array(
            'plugin_url' => P_P_DASHBOARD_PLUGIN_URL,
            'ajax_url' => admin_url('admin-ajax.php'),
            'are_you_sure' => __('Are you sure!', 'healthieo-supporter'),
            'error_msg' => esc_html__('There is some error.', 'healthieo-supporter'),
            'require_fields' => __('Please fill the require fields.', 'healthieo-supporter'),
        );
        wp_localize_script('p-p-dashboard-admin', 'pp_common_vars', $healthieo_common_arr);
        
        
    }

}
