(function($) {


    /**
     * All of the code for your admin-facing JavaScript source
     * should reside in this file.
     *
     * Note: It has been assumed you will write jQuery code here, so the
     * $ function reference has been prepared for usage within the scope
     * of this function.
     *
     * This enables you to define handlers, for when the DOM is ready:
     *
     * $(function() {
     *
     * });
     *
     * When the window is loaded:
     *
     * $( window ).load(function() {
     *
     * });
     *
     * ...and/or other possibilities.
     *
     * Ideally, it is not considered best practise to attach more than a
     * single DOM-ready or window-load handler for a particular page.
     * Although scripts in the WordPress core, Plugins and Themes may be
     * practising this, we should strive to set a better example in our own work.
     */


    jQuery(document).ready(function($) {

        jQuery(document).on('click', '#send-reject-mail', function(e) {

            e.preventDefault();

            var pp_reject_reason = jQuery('#pp_reject_reason').val();

            var post_ID = jQuery('#post_ID').val();



            if (typeof pp_reject_reason === 'undefined' || pp_reject_reason == '') {
                alert('Please add a short note for rejected user.');
                return false;
            }

            var current_obj = jQuery(this);

            var pp_ajax_ = jQuery('#pp-ajx-url').val();

            var request = jQuery.ajax({
                url: pp_ajax_,
                method: "POST",
                data: { post_ID: post_ID, pp_reject_reason: pp_reject_reason, action: 'pp_send_rejection_email' },
                dataType: "json"
            });

            request.done(function(response) {

                if (typeof response.status !== 'undefined' && response.status == 'success') {
                    alert(response.message);
                } else {
                    alert(response.message);
                }

                return false;

            });

            return false;
        });



        /*
         * Add Courses Details
         */

        $(document).on('click', '.pp-bk-multi-fields .open-add-box', function() {
            var _this = $(this);
            var _this_parent = $(this).parents('.multi-list-add');

            _this_parent.next('.multi-list-add-box').slideDown();
            _this_parent.hide();
        });

        $(document).on('click', '#pp-add-det_item', function() {
            var _this = $(this);
            var _this_rand = _this.data('id');
            var loader_img = pp_common_vars.plugin_url + 'admin/images/ajax-loader.gif';

            var ajax_url = pp_common_vars.ajax_url;
            var this_loader = $(this).next('.ajax-loader');

            var det_item_title = $('#course_detail_title');
            var before_vid_text = $('#before_vid_text');
            var course_video_url = $('#course_video_url');
            var after_vid_text = $('#after_vid_text');
            var course_img = $('#course_img');



            if (det_item_title.val() != '') {
                if (!_this.hasClass('ajax-disabled')) {
                    this_loader.html('<img alt="loader img" src="' + loader_img + '">');
                    var request = $.ajax({
                        url: ajax_url,
                        method: "POST",
                        data: {
                            det_item_title: det_item_title.val(),
                            before_vid_text: before_vid_text.val(),
                            course_video_url: course_video_url.val(),
                            after_vid_text: after_vid_text.val(),
                            course_img: course_img.val(),
                            action: 'pp_add_detail_item',
                        },
                        dataType: "json"
                    });
                    request.done(function(msg) {
                        $("#pp-det_items-con").append(msg.html);

                        det_item_title.val('');
                        before_vid_text.val('');
                        course_video_url.val('');
                        after_vid_text.val('');
                        this_loader.html('');
                        jQuery('li.pp-temp-photo').remove();
                        _this.removeClass('ajax-disabled');

                    });
                    request.fail(function(jqXHR, textStatus) {
                        this_loader.html('');
                        _this.removeClass('ajax-disabled');
                    });
                    _this.addClass('ajax-disabled');
                }
            } else {
                alert(pp_common_vars.require_fields);
                return false;
            }
        });

        $(document).on('click', '.multi-list-header .list-open', function() {
            var _this = $(this);
            var _this_visible = _this.attr('data-visible');
            var _this_id = _this.attr('data-id');
            if (_this_visible == 'open') {
                $('#list-content-' + _this_id).slideUp();
                _this.attr('data-visible', 'close');
                _this.find('span').attr('class', 'dashicons dashicons-arrow-down-alt2');
            } else {
                $('#list-content-' + _this_id).slideDown();
                _this.attr('data-visible', 'open');
                _this.find('span').attr('class', 'dashicons dashicons-arrow-up-alt2');
            }
        });

        $(document).on('click', '.multi-list-add-box .close-box', function() {
            var _this = $(this);
            var _this_parent = $(this).parents('.multi-list-add-box');
            var _this_box_btn = _this_parent.prev('.multi-list-add');

            _this_parent.slideUp(400, function() {
                _this_box_btn.show();
            });
        });

        $(document).on('click', '.multi-list-header .list-delete', function() {
            var _this = $(this);
            var _this_id = _this.attr('data-id');
            var r = confirm(pp_common_vars.are_you_sure);
            if (r == true) {
                $('#list-' + _this_id).remove();
            } else {
                return false;
            }
        });

        $(document).on('click', '.multi-list-update > a', function() {
            var _this_attr = $(this).parents('li').find('.list-open');
            $(this).parents('.multi-list-content').slideUp();
            _this_attr.attr('data-visible', 'close');
            _this_attr.find('i').attr('class', 'fa fa-chevron-down');
        });





    });



})(jQuery);