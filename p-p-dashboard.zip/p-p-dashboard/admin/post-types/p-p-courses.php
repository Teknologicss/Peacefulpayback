<?php

// Register Custom Post Type Course
function create_course_cpt() {

    $labels = array(
        'name' => _x('Courses', 'Post Type General Name', 'p-p-dashboard'),
        'singular_name' => _x('Course', 'Post Type Singular Name', 'p-p-dashboard'),
        'menu_name' => _x('Courses', 'Admin Menu text', 'p-p-dashboard'),
        'name_admin_bar' => _x('Course', 'Add New on Toolbar', 'p-p-dashboard'),
        'archives' => __('Course Archives', 'p-p-dashboard'),
        'attributes' => __('Course Attributes', 'p-p-dashboard'),
        'parent_item_colon' => __('Parent Course:', 'p-p-dashboard'),
        'all_items' => __('All Courses', 'p-p-dashboard'),
        'add_new_item' => __('Add New Course', 'p-p-dashboard'),
        'add_new' => __('Add New', 'p-p-dashboard'),
        'new_item' => __('New Course', 'p-p-dashboard'),
        'edit_item' => __('Edit Course', 'p-p-dashboard'),
        'update_item' => __('Update Course', 'p-p-dashboard'),
        'view_item' => __('View Course', 'p-p-dashboard'),
        'view_items' => __('View Courses', 'p-p-dashboard'),
        'search_items' => __('Search Course', 'p-p-dashboard'),
        'not_found' => __('Not found', 'p-p-dashboard'),
        'not_found_in_trash' => __('Not found in Trash', 'p-p-dashboard'),
        'featured_image' => __('Featured Image', 'p-p-dashboard'),
        'set_featured_image' => __('Set featured image', 'p-p-dashboard'),
        'remove_featured_image' => __('Remove featured image', 'p-p-dashboard'),
        'use_featured_image' => __('Use as featured image', 'p-p-dashboard'),
        'insert_into_item' => __('Insert into Course', 'p-p-dashboard'),
        'uploaded_to_this_item' => __('Uploaded to this Course', 'p-p-dashboard'),
        'items_list' => __('Courses list', 'p-p-dashboard'),
        'items_list_navigation' => __('Courses list navigation', 'p-p-dashboard'),
        'filter_items_list' => __('Filter Courses list', 'p-p-dashboard'),
    );
    $args = array(
        'label' => __('Course', 'p-p-dashboard'),
        'description' => __('responsible for courses data added by the admin and displayed in the dashboard for co-signer', 'p-p-dashboard'),
        'labels' => $labels,
        'menu_icon' => 'dashicons-welcome-write-blog',
        'supports' => array('title', 'thumbnail'),
        'taxonomies' => array(),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => false,
        'exclude_from_search' => false,
        'show_in_rest' => true,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type('pp-course', $args);
}

add_action('init', 'create_course_cpt', 0);


/**
 * Register meta boxes.
 */
add_action('add_meta_boxes', 'register_courses_metaboxes');

function register_courses_metaboxes() {
    add_meta_box('courses-info', __('Courses Information', 'textdomain'), 'courses_information', 'pp-course', 'advanced', 'high');
    add_meta_box('video-info', __('Courses Videos', 'textdomain'), 'courses_video_information', 'pp-course', 'advanced', 'high');
    //add_meta_box('video-infooo', __('Courses Videos', 'textdomain'), 'courses_video_informationzz', 'pp-course', 'advanced', 'high');
}

/*
 * Video Information
 */

//function courses_video_informationzz($post) {
//
//
//    $content = '';
//    $editor_id = 'mycustomeditor';
//
//    //wp_editor('','custom-editor');
//}

/**
 * Meta box display callbac
 *
 */
function courses_information($post) {


    $course_author = get_post_meta($post->ID, 'course_author', true);
    $course_author = isset($course_author) && $course_author != '' ? $course_author : '';

    $course_tagline = get_post_meta($post->ID, 'course_tagline', true);
    $course_tagline = isset($course_tagline) && $course_tagline != '' ? $course_tagline : '';

    $course_hours = get_post_meta($post->ID, 'course_hours', true);
    $course_hours = isset($course_hours) && $course_hours != '' ? $course_hours : '';

    wp_nonce_field('pp_course_custom_box', 'pp_course_custom_box_nonce');
    ?>

<table id="customers">

    <tr>
        <th>Data</th>
        <th>Values</th>
    </tr>

    <tr>
        <td>Course Author</td>
        <td><input type="text" name="course_author" value="<?php echo $course_author; ?>" /></td>
    </tr>

    <tr>
        <td>Course Tagline</td>
        <td><input type="text" name="course_tagline" value="<?php echo $course_tagline; ?>" /></td>
    </tr>

    <tr>
        <td>Course Hours</td>
        <td><input type="text" name="course_hours" value="<?php echo $course_hours; ?>" /></td>
    </tr>

</table>

<?php
}

add_action('save_post_pp-course', 'pp_dashboard_courses_fields_save', 10, 3);

function pp_dashboard_courses_fields_save($post_id, $post, $update) {

    /*
     * We need to verify this came from the our screen and with proper authorization,
     * because save_post can be triggered at other times.
     */

    // Check if our nonce is set.
    if (!isset($_POST['pp_course_custom_box_nonce'])) {
        return $post_id;
    }

    $nonce = $_POST['pp_course_custom_box_nonce'];

    // Verify that the nonce is valid.
    if (!wp_verify_nonce($nonce, 'pp_course_custom_box')) {
        return $post_id;
    }

    /*
     * If this is an autosave, our form has not been submitted,
     * so we don't want to do anything.
     */
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    // Check the user's permissions.
    if ('pp-course' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } else {
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
    }

    // Sanitize the user input.
    $course_author = sanitize_text_field($_POST['course_author']);
    $course_tagline = sanitize_text_field($_POST['course_tagline']);
    $course_hours = sanitize_text_field($_POST['course_hours']);

    // Update the meta field.
    update_post_meta($post_id, 'course_author', $course_author);
    update_post_meta($post_id, 'course_tagline', $course_tagline);
    update_post_meta($post_id, 'course_hours', $course_hours);

    //course video data
    update_post_meta($post_id, 'course_detail_title', $_POST['course_detail_title']);
    update_post_meta($post_id, 'before_vid_text', $_POST['before_vid_text']);
    update_post_meta($post_id, 'course_video_url', $_POST['course_video_url']);
    update_post_meta($post_id, 'after_vid_text', $_POST['after_vid_text']);
    update_post_meta($post_id, 'course_img', $_POST['course_img']);
    update_post_meta($post_id, 'course_reading', $_POST['course_reading']);
}

function courses_video_information($post) {

    $rand_num = rand(1000000, 99999999);
    ?>
<div class="pp-education-box pp-post-1">

    <div class="pp-elem-heading">
        <h2><?php esc_html_e('Course List', 'p-p-dashboard') ?></h2>
    </div>
    <div class="pp-bk-multi-fields">
        <div class="multi-list-add">
            <a class="pp-bk-btn open-add-box"
                href="javascript:void(0)"><?php esc_html_e('Add Course Detail', 'p-p-dashboard') ?></a>
        </div>
        <div class="multi-list-add-box" style="display:none;">
            <div class="close-box"><a href="javascript:void(0)"><i class="dashicons dashicons-dismiss"></i></a></div>
            <div class="pp-course-list">
                <div class="pp-element-field">
                    <div class="elem-label ">
                        <label><?php esc_html_e('Course Deatil Title', 'p-p-dashboard') ?> *</label>
                    </div>
                    <div class="elem-field ">
                        <input id="course_detail_title" type="text" />
                    </div>
                </div>

                <div class="pp-element-field">
                    <div class="elem-label ">
                        <label><?php esc_html_e('Description (Before Video)', 'p-p-dashboard') ?></label>
                    </div>
                    <div class="elem-field ">
                        <textarea id="before_vid_text" rows="4" class="course-desc"></textarea>
                    </div>
                </div>


                <div class="pp-element-field">
                    <div class="elem-label ">
                        <label><?php esc_html_e('Video Url', 'p-p-dashboard') ?> *</label>
                    </div>
                    <div class="elem-field ">
                        <input id="course_video_url" type="text" />
                    </div>
                </div>



                <div class="pp-element-field">
                    <div class="elem-label ">
                        <label><?php esc_html_e('Description (After Video)', 'p-p-dashboard') ?></label>
                    </div>
                    <div class="elem-field ">
                        <textarea id="after_vid_text" rows="4" class="course-desc"></textarea>
                    </div>
                </div>

                <div class="pp-element-field">
                    <div class="elem-label ">
                        <label><?php esc_html_e('Course Image', 'p-p-dashboard') ?></label>
                    </div>
                    <div class="elem-field ">
                        <?php echo multi_media_uploader_field('course_img', '', false); ?>
                    </div>
                </div>


            </div>
            <script type="text/javascript">
            jQuery(function($) {

                $('body').on('click', '.wc_multi_upload_image_button', function(e) {

                    e.preventDefault();

                    var button = $(this),
                        custom_uploader = wp.media({
                            title: 'Insert image',
                            button: {
                                text: 'Use this image'
                            },
                            multiple: false,
                        }).on('select', function() {


                            //var attech_ids = '';
                            var attachments = custom_uploader.state().get('selection'),
                                attachment_ids = new Array(),
                                i = 0;

                            attachments.each(function(attachment) {

                                attachment_ids = attachment['id'];

                                if (attachment.attributes.type == 'image') {
                                    $(button).siblings('ul').html(
                                        '<li class="pp-temp-photo" data-attechment-id="' +
                                        attachment['id'] + '"><a href="' + attachment
                                        .attributes.url +
                                        '" target="_blank"><img class="true_pre_image" src="' +
                                        attachment.attributes.url +
                                        '" /></a><i class=" dashicons dashicons-no delete-img"></i></li>'
                                        );
                                }

                                //i++;
                            });

                            var ids = $(button).siblings('.attechments-ids').attr('value');
                            //if (ids) {
                            //var ids = ids + attech_ids;
                            //$(button).siblings('.attechments-ids').attr('value', ids);
                            //} else {
                            $(button).siblings('.attechments-ids').attr('value', attachment_ids);
                            //}
                            //$(button).siblings('.wc_multi_remove_image_button').show();
                        }).open();
                });

                //                        $('body').on('click', '.wc_multi_remove_image_button', function () {
                //                            $(this).hide().prev().val('').prev().addClass('button').html('Add Media');
                //                            $(this).parent().find('ul').empty();
                //                            return false;
                //                        });

            });

            jQuery(document).ready(function() {
                jQuery(document).on('click', '.multi-upload-medias ul li i.delete-img', function() {
                    var ids = [];
                    var this_c = jQuery(this);
                    jQuery(this).parent().remove();
                    jQuery('.multi-upload-medias ul li').each(function() {
                        ids.push(jQuery(this).attr('data-attechment-id'));
                    });
                    jQuery('.multi-upload-medias').find('input[type="hidden"]').attr('value', ids);
                });
            })
            </script>

            <div class="addto-list-btn"><a id="pp-add-det_item" data-id="<?php echo absint($rand_num) ?>"
                    class="pp-bk-btn"
                    href="javascript:void(0)"><?php esc_html_e('Add to List', 'p-p-dashboard') ?></a><span
                    class="ajax-loader"></span></div>
        </div>
        <?php
            $det_item_list = get_post_meta($post->ID, 'course_detail_title', true);
            $before_vid_text = get_post_meta($post->ID, 'before_vid_text', true);
            $course_video_url = get_post_meta($post->ID, 'course_video_url', true);
            $after_vid_text = get_post_meta($post->ID, 'after_vid_text', true);
            $course_image = get_post_meta($post->ID, 'course_img', true);

            $course_reading = get_post_meta($post->ID, 'course_reading', true);
            ?>
        <ul id="pp-det_items-con" class="pp-bk-sortable">
            <?php
                if (isset($det_item_list) && !empty($det_item_list) && is_array($det_item_list) && sizeof($det_item_list) > 0) {

                    $course_counter = 0;
                    foreach ($det_item_list as $det_item) {
                        $rand_num = rand(1000000, 99999999);

                        $each_before_vid_text = isset($before_vid_text[$course_counter]) ? $before_vid_text[$course_counter] : '';
                        $each_course_video_url = isset($course_video_url[$course_counter]) ? $course_video_url[$course_counter] : '';
                        $each_after_vid_text = isset($after_vid_text[$course_counter]) ? $after_vid_text[$course_counter] : '';
                        $each_course_image = isset($course_image[$course_counter]) ? $course_image[$course_counter] : '';
                        ?>
            <li id="list-<?php echo absint($rand_num) ?>">

                <div class="multi-list-header" id="list-head-<?php echo absint($rand_num) ?>">
                    <ul>
                        <li class="drag-point"><a href="javascript:void(0)"><span
                                    class="dashicons dashicons-move"></span></a></li>
                        <li class="list-title"><?php echo wp_trim_words($det_item, 5, '...') ?></li>
                        <li class="list-actions">
                            <a class="list-open" data-visible="close" data-id="<?php echo absint($rand_num) ?>"
                                href="javascript:void(0)"><span class="dashicons dashicons-arrow-down-alt2"></span></a>
                            <a class="list-delete" data-id="<?php echo absint($rand_num) ?>"
                                href="javascript:void(0)"><span class="dashicons dashicons-trash"></span></a>
                        </li>
                    </ul>
                </div>

                <div id="list-content-<?php echo absint($rand_num) ?>" class="multi-list-content" style="display:none;">
                    <div class="pp-course-list">
                        <div class="pp-element-field">
                            <div class="elem-label ">
                                <label><?php esc_html_e('Course Deatil Title', 'p-p-dashboard') ?></label>
                            </div>
                            <div class="elem-field ">
                                <input name="course_detail_title[]" type="text"
                                    value="<?php echo esc_html($det_item); ?>" />
                            </div>
                        </div>

                        <div class="pp-element-field">
                            <div class="elem-label ">
                                <label><?php esc_html_e('Description (Before Video)', 'p-p-dashboard') ?></label>
                            </div>
                            <div class="elem-field ">
                                <textarea name="before_vid_text[]" class="course-desc"
                                    rows="4"><?php echo esc_html($each_before_vid_text); ?></textarea>
                            </div>
                        </div>

                        <div class="pp-element-field">
                            <div class="elem-label ">
                                <label><?php esc_html_e('Video Url', 'p-p-dashboard') ?> *</label>
                            </div>
                            <div class="elem-field ">
                                <input name="course_video_url[]" type="text"
                                    value="<?php echo esc_html($each_course_video_url); ?>" />
                            </div>
                        </div>

                        <div class="pp-element-field">
                            <div class="elem-label ">
                                <label><?php esc_html_e('Description (After Video)', 'p-p-dashboard') ?></label>
                            </div>
                            <div class="elem-field ">
                                <textarea name="after_vid_text[]" class="course-desc"
                                    rows="4"><?php echo esc_html($each_after_vid_text); ?></textarea>
                            </div>
                        </div>

                        <div class="pp-element-field">
                            <div class="elem-label ">
                                <label><?php esc_html_e('Course Image', 'p-p-dashboard') ?></label>
                            </div>
                            <div class="elem-field ">
                                <?php echo multi_media_uploader_field('course_img', $each_course_image, true); ?>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="course_reading[]" value="" />

                    <div class="multi-list-update">
                        <a class="pp-bk-btn"
                            href="javascript:void(0)"><?php esc_html_e('Update', 'p-p-dashboard') ?></a>
                    </div>
                </div>
            </li>
            <?php
                        $course_counter ++;
                    }
                }
                ?>
        </ul>
    </div>
</div>
<?php
}