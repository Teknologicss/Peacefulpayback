<?php

// Register Custom Post Type Meeting
function create_meeting_cpt() {

    $labels = array(
        'name' => _x('Meetings', 'Post Type General Name', 'p-p-dashboard'),
        'singular_name' => _x('Meeting', 'Post Type Singular Name', 'p-p-dashboard'),
        'menu_name' => _x('Meetings', 'Admin Menu text', 'p-p-dashboard'),
        'name_admin_bar' => _x('Meeting', 'Add New on Toolbar', 'p-p-dashboard'),
        'archives' => __('Meeting Archives', 'p-p-dashboard'),
        'attributes' => __('Meeting Attributes', 'p-p-dashboard'),
        'parent_item_colon' => __('Parent Meeting:', 'p-p-dashboard'),
        'all_items' => __('All Meetings', 'p-p-dashboard'),
        'add_new_item' => __('Add New Meeting', 'p-p-dashboard'),
        'add_new' => __('Add New', 'p-p-dashboard'),
        'new_item' => __('New Meeting', 'p-p-dashboard'),
        'edit_item' => __('Edit Meeting', 'p-p-dashboard'),
        'update_item' => __('Update Meeting', 'p-p-dashboard'),
        'view_item' => __('View Meeting', 'p-p-dashboard'),
        'view_items' => __('View Meetings', 'p-p-dashboard'),
        'search_items' => __('Search Meeting', 'p-p-dashboard'),
        'not_found' => __('Not found', 'p-p-dashboard'),
        'not_found_in_trash' => __('Not found in Trash', 'p-p-dashboard'),
        'featured_image' => __('Featured Image', 'p-p-dashboard'),
        'set_featured_image' => __('Set featured image', 'p-p-dashboard'),
        'remove_featured_image' => __('Remove featured image', 'p-p-dashboard'),
        'use_featured_image' => __('Use as featured image', 'p-p-dashboard'),
        'insert_into_item' => __('Insert into Meeting', 'p-p-dashboard'),
        'uploaded_to_this_item' => __('Uploaded to this Meeting', 'p-p-dashboard'),
        'items_list' => __('Meetings list', 'p-p-dashboard'),
        'items_list_navigation' => __('Meetings list navigation', 'p-p-dashboard'),
        'filter_items_list' => __('Filter Meetings list', 'p-p-dashboard'),
    );
    $args = array(
        'label' => __('Meeting', 'p-p-dashboard'),
        'description' => __('responsible for up coming meetings data added by the admin and displayed in the dashboard for co-signer', 'p-p-dashboard'),
        'labels' => $labels,
        'menu_icon' => 'dashicons-groups',
        'supports' => array('title'),
        'taxonomies' => array(),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => false,
        'exclude_from_search' => false,
        'show_in_rest' => true,
        'publicly_queryable' => false,
        'capability_type' => 'post',
    );
    register_post_type('pp-meeting', $args);
}

add_action('init', 'create_meeting_cpt', 0);


/**
 * Register meta boxes.
 */
add_action('add_meta_boxes', 'register_meetings_metaboxes');

function register_meetings_metaboxes() {
    add_meta_box('meeting-info', __('Meeting Information', 'textdomain'), 'meeting_information', 'pp-meeting', 'advanced', 'high');
}

/**
 * Meta box display callbac
 *
 */
function meeting_information($post) {


    $meeting_price = get_post_meta($post->ID, 'meeting_price', true);
    $meeting_price = isset($meeting_price) && $meeting_price != '' ? $meeting_price : '';

    $meeting_client_name = get_post_meta($post->ID, 'meeting_client_name', true);
    $meeting_client_name = isset($meeting_client_name) && $meeting_client_name != '' ? $meeting_client_name : '';

    $meeting_location = get_post_meta($post->ID, 'meeting_location', true);
    $meeting_location = isset($meeting_location) && $meeting_location != '' ? $meeting_location : '';

    $meeting_link = get_post_meta($post->ID, 'meeting_link', true);
    $meeting_link = isset($meeting_link) && $meeting_link != '' ? $meeting_link : '';

    wp_nonce_field('pp_meeting_custom_box', 'pp_meeting_custom_box_nonce');
    
    
    ?>

    <table id="customers">


        <tr>
            <th>Data</th>
            <th>Values</th>
        </tr>

        <tr>
            <td>Meeting Price</td>
            <td><input type="text" name="meeting_price" value="<?php echo $meeting_price; ?>"/></td>
        </tr>

        <tr>
            <td>Meeting Client name</td>
            <td><input type="text" name="meeting_client_name" value="<?php echo $meeting_client_name; ?>"/></td>
        </tr>

        <tr>
            <td>Location</td>
            <td><input type="text" name="meeting_location" value="<?php echo $meeting_location; ?>"/></td>
        </tr>

        <tr>
            <td>Meeting Join Link</td>
            <td><input type="text" name="meeting_link" value="<?php echo $meeting_link; ?>"/></td>
        </tr>


    </table>

    <?php
}

add_action('save_post_pp-meeting', 'pp_dashboard_meetings_fields_save', 10, 3);

function pp_dashboard_meetings_fields_save($post_id, $post, $update) {

    /*
     * We need to verify this came from the our screen and with proper authorization,
     * because save_post can be triggered at other times.
     */

    // Check if our nonce is set.
    if (!isset($_POST['pp_meeting_custom_box_nonce'])) {
        return $post_id;
    }

    $nonce = $_POST['pp_meeting_custom_box_nonce'];

    // Verify that the nonce is valid.
    if (!wp_verify_nonce($nonce, 'pp_meeting_custom_box')) {
        return $post_id;
    }

    /*
     * If this is an autosave, our form has not been submitted,
     * so we don't want to do anything.
     */
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    // Check the user's permissions.
    if ('pp-meeting' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } else {
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
    }

    /* OK, it's safe for us to save the data now. */

    // Sanitize the user input.
    $meeting_price = sanitize_text_field($_POST['meeting_price']);
    $meeting_client_name = sanitize_text_field($_POST['meeting_client_name']);
    $meeting_location = sanitize_text_field($_POST['meeting_location']);
    $meeting_link = sanitize_text_field($_POST['meeting_link']);
    


    // Update the meta field.
    update_post_meta($post_id, 'meeting_price', $meeting_price);
    update_post_meta($post_id, 'meeting_client_name', $meeting_client_name);
    update_post_meta($post_id, 'meeting_location', $meeting_location);
    update_post_meta($post_id, 'meeting_link', $meeting_link);
    
}
