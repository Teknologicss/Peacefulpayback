<?php

// Register Custom Post Type Notification
function create_notification_cpt() {

	$labels = array(
		'name' => _x( 'Notifications', 'Post Type General Name', 'pp-dashboard' ),
		'singular_name' => _x( 'Notification', 'Post Type Singular Name', 'pp-dashboard' ),
		'menu_name' => _x( 'Notifications', 'Admin Menu text', 'pp-dashboard' ),
		'name_admin_bar' => _x( 'Notification', 'Add New on Toolbar', 'pp-dashboard' ),
		'archives' => __( 'Notification Archives', 'pp-dashboard' ),
		'attributes' => __( 'Notification Attributes', 'pp-dashboard' ),
		'parent_item_colon' => __( 'Parent Notification:', 'pp-dashboard' ),
		'all_items' => __( 'All Notifications', 'pp-dashboard' ),
		'add_new_item' => __( 'Add New Notification', 'pp-dashboard' ),
		'add_new' => __( 'Add New', 'pp-dashboard' ),
		'new_item' => __( 'New Notification', 'pp-dashboard' ),
		'edit_item' => __( 'Edit Notification', 'pp-dashboard' ),
		'update_item' => __( 'Update Notification', 'pp-dashboard' ),
		'view_item' => __( 'View Notification', 'pp-dashboard' ),
		'view_items' => __( 'View Notifications', 'pp-dashboard' ),
		'search_items' => __( 'Search Notification', 'pp-dashboard' ),
		'not_found' => __( 'Not found', 'pp-dashboard' ),
		'not_found_in_trash' => __( 'Not found in Trash', 'pp-dashboard' ),
		'featured_image' => __( 'Featured Image', 'pp-dashboard' ),
		'set_featured_image' => __( 'Set featured image', 'pp-dashboard' ),
		'remove_featured_image' => __( 'Remove featured image', 'pp-dashboard' ),
		'use_featured_image' => __( 'Use as featured image', 'pp-dashboard' ),
		'insert_into_item' => __( 'Insert into Notification', 'pp-dashboard' ),
		'uploaded_to_this_item' => __( 'Uploaded to this Notification', 'pp-dashboard' ),
		'items_list' => __( 'Notifications list', 'pp-dashboard' ),
		'items_list_navigation' => __( 'Notifications list navigation', 'pp-dashboard' ),
		'filter_items_list' => __( 'Filter Notifications list', 'pp-dashboard' ),
	);
	$args = array(
		'label' => __( 'Notification', 'pp-dashboard' ),
		'description' => __( 'Responsible for Peaceful Payback Notifications', 'pp-dashboard' ),
		'labels' => $labels,
		'menu_icon' => 'dashicons-bell',
		'supports' => array('title'),
		'taxonomies' => array(),
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 5,
		'show_in_admin_bar' => true,
		'show_in_nav_menus' => true,
		'can_export' => false,
		'has_archive' => false,
		'hierarchical' => false,
		'exclude_from_search' => false,
		'show_in_rest' => true,
		'publicly_queryable' => false,
		'capability_type' => 'post',
	);
	register_post_type( 'pp-notification', $args );

}
add_action( 'init', 'create_notification_cpt', 0 );