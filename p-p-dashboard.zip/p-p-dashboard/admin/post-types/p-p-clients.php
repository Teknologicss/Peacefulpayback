<?php

// Register Custom Post Type Client
function create_client_cpt() {

    $labels = array(
        'name' => _x('Clients', 'Post Type General Name', 'p-p-dashboard'),
        'singular_name' => _x('Client', 'Post Type Singular Name', 'p-p-dashboard'),
        'menu_name' => _x('Clients', 'Admin Menu text', 'p-p-dashboard'),
        'name_admin_bar' => _x('Client', 'Add New on Toolbar', 'p-p-dashboard'),
        'archives' => __('Client Archives', 'p-p-dashboard'),
        'attributes' => __('Client Attributes', 'p-p-dashboard'),
        'parent_item_colon' => __('Parent Client:', 'p-p-dashboard'),
        'all_items' => __('All Clients', 'p-p-dashboard'),
        'add_new_item' => __('Add New Client', 'p-p-dashboard'),
        'add_new' => __('Add New', 'p-p-dashboard'),
        'new_item' => __('New Client', 'p-p-dashboard'),
        'edit_item' => __('Edit Client', 'p-p-dashboard'),
        'update_item' => __('Update Client', 'p-p-dashboard'),
        'view_item' => __('View Client', 'p-p-dashboard'),
        'view_items' => __('View Clients', 'p-p-dashboard'),
        'search_items' => __('Search Client', 'p-p-dashboard'),
        'not_found' => __('Not found', 'p-p-dashboard'),
        'not_found_in_trash' => __('Not found in Trash', 'p-p-dashboard'),
        'featured_image' => __('Featured Image', 'p-p-dashboard'),
        'set_featured_image' => __('Set featured image', 'p-p-dashboard'),
        'remove_featured_image' => __('Remove featured image', 'p-p-dashboard'),
        'use_featured_image' => __('Use as featured image', 'p-p-dashboard'),
        'insert_into_item' => __('Insert into Client', 'p-p-dashboard'),
        'uploaded_to_this_item' => __('Uploaded to this Client', 'p-p-dashboard'),
        'items_list' => __('Clients list', 'p-p-dashboard'),
        'items_list_navigation' => __('Clients list navigation', 'p-p-dashboard'),
        'filter_items_list' => __('Filter Clients list', 'p-p-dashboard'),
    );
    $args = array(
        'label' => __('Client', 'p-p-dashboard'),
        'description' => __('responsible for clients( borrower) data added by the co-signer', 'p-p-dashboard'),
        'labels' => $labels,
        'menu_icon' => 'dashicons-admin-users',
        'supports' => array('title'),
        'taxonomies' => array(),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => false,
        'exclude_from_search' => false,
        'show_in_rest' => true,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type('pp-client', $args);
}

add_action('init', 'create_client_cpt', 0);



/**
 * Register meta boxes.
 */
add_action('add_meta_boxes', 'register_client_metaboxes');

function register_client_metaboxes() {

    add_meta_box('client-user-info', __('Client Information', 'textdomain'), 'client_user_information', 'pp-client', 'advanced', 'high');
    add_meta_box('client-business-info', __('Client Business Information', 'textdomain'), 'client_business_information', 'pp-client', 'advanced', 'high');
}

/**
 * Meta box display callbac
 *
 */
function client_user_information($post) {


    $bowrer_name = get_post_meta($post->ID, 'bowrer_name', true);
    $bowrer_name = isset($bowrer_name) && $bowrer_name != '' ? $bowrer_name : '';

    $bowrer_address = get_post_meta($post->ID, 'bowrer_address', true);
    $bowrer_address = isset($bowrer_address) && $bowrer_address != '' ? $bowrer_address : '';

    $bowrer_dob = get_post_meta($post->ID, 'bowrer_dob', true);
    $bowrer_dob = isset($bowrer_dob) && $bowrer_dob != '' ? $bowrer_dob : '';

    $bowrer_phone = get_post_meta($post->ID, 'bowrer_phone', true);
    $bowrer_phone = isset($bowrer_phone) && $bowrer_phone != '' ? $bowrer_phone : '';

    $bowrer_email = get_post_meta($post->ID, 'bowrer_email', true);
    $bowrer_email = isset($bowrer_email) && $bowrer_email != '' ? $bowrer_email : '';

    //$bowrer_doc_sb = get_post_meta($post->ID, 'bowrer_doc_sb', true);
    //$bowrer_doc_sb = isset($bowrer_doc_sb) && $bowrer_doc_sb != '' ? $bowrer_doc_sb : '';

    $bowrer_due_amount = get_post_meta($post->ID, 'bowrer_due_amount', true);
    $bowrer_due_amount = isset($bowrer_due_amount) && $bowrer_due_amount != '' ? $bowrer_due_amount : '';

    $bowrer_pay_date = get_post_meta($post->ID, 'bowrer_pay_date', true);
    $bowrer_pay_date = isset($bowrer_pay_date) && $bowrer_pay_date != '' ? $bowrer_pay_date : '';

    $bowrer_credit_score = get_post_meta($post->ID, 'bowrer_credit_score', true);
    $bowrer_credit_score = isset($bowrer_credit_score) && $bowrer_credit_score != '' ? $bowrer_credit_score : '';

    $pp_cosigner_id = get_post_meta($post->ID, 'pp_cosigner_id', true);
    $pp_cosigner_id = isset($pp_cosigner_id) && $pp_cosigner_id != '' ? $pp_cosigner_id : '';

    $cosigner_post_id = get_user_meta($pp_cosigner_id, 'cosigner_post_id', true);
    ?>
    <table id="customers">
        <thead>
            <tr>
                <th>Data</th>
                <th>Values</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Borrower Name</td>
                <td><?php echo $bowrer_name; ?></td>
            </tr>

            <tr>
                <td>Borrower Address</td>
                <td><?php echo $bowrer_address; ?></td>
            </tr>

            <tr>
                <td>Borrower Date of Birth</td>
                <td><?php echo $bowrer_dob; ?></td>
            </tr>

            <tr>
                <td>Borrower Phone</td>
                <td><?php echo $bowrer_phone; ?></td>
            </tr>

            <tr>
                <td>Borrower Email</td>
                <td><?php echo $bowrer_email; ?></td>
            </tr>
            <tr>
                <td>Borrower Due Amount</td>
                <td><?php echo $bowrer_due_amount; ?></td>
            </tr>

            <tr>
                <td>Borrower Due Amount</td>
                <td><?php echo $bowrer_due_amount; ?></td>
            </tr>

            <tr>
                <td>Borrower Pay Date</td>
                <td><?php echo $bowrer_pay_date; ?></td>
            </tr>

            <tr>
                <td>Borrower Credit Scores</td>
                <td><?php echo $bowrer_credit_score; ?></td>
            </tr>

            <tr>
                <td>Borrower Refferal</td>
                <td><?php echo get_the_title($cosigner_post_id); ?></td>
            </tr>
        </tbody>
    </table>
    <?php
}

/*
 * Business Information
 * 
 */

function client_business_information($post) {


    $business_name = get_post_meta($post->ID, 'bowrer_bname', true);
    $business_name = isset($business_name) && $business_name != '' ? $business_name : '';

    $business_address = get_post_meta($post->ID, 'bowrer_baddress', true);
    $business_address = isset($business_address) && $business_address != '' ? $business_address : '';

    $business_position = get_post_meta($post->ID, 'bowrer_position', true);
    $business_position = isset($business_position) && $business_position != '' ? $business_position : '';

    $basic_salary = get_post_meta($post->ID, 'bowrer_salary', true);
    $basic_salary = isset($basic_salary) && $basic_salary != '' ? $basic_salary : '';

    $getpaid = get_post_meta($post->ID, 'bowrer_paid', true);
    $getpaid = isset($getpaid) && $getpaid != '' ? $getpaid : '';

    $job_duration = get_post_meta($post->ID, 'job_duration', true);
    $job_duration = isset($job_duration) && $job_duration != '' ? $job_duration : '';

    $hiring_party_mail = get_post_meta($post->ID, 'bowrer_hiring_email', true);
    $hiring_party_mail = isset($hiring_party_mail) && $hiring_party_mail != '' ? $hiring_party_mail : '';

    $hiring_party_phone = get_post_meta($post->ID, 'bowrer_hiring_phone', true);
    $hiring_party_phone = isset($hiring_party_phone) && $hiring_party_phone != '' ? $hiring_party_phone : '';
    ?>

    <table id="customers">
        <tr>
            <th>Data</th>
            <th>Values</th>
        </tr>
        <tr>
            <td>Business Name</td>
            <td><?php echo $business_name; ?></td>
        </tr>

        <tr>
            <td>Business Address</td>
            <td><?php echo $business_address; ?></td>
        </tr>

        <tr>
            <td>Business Position</td>
            <td><?php echo $business_position; ?></td>
        </tr>

        <tr>
            <td>Basic Salary</td>
            <td><?php echo $basic_salary; ?></td>
        </tr>

        <tr>
            <td>How often You get paid</td>
            <td><?php echo $getpaid; ?></td>
        </tr>

        <tr>
            <td>Length of time in months worked on job</td>
            <td><?php echo $job_duration; ?></td>
        </tr>

        <tr>
            <td>Hiring Party Email</td>
            <td><?php echo $hiring_party_mail; ?></td>
        </tr>

        <tr>
            <td>Phone Number of Hiring Party</td>
            <td><?php echo $hiring_party_phone; ?></td>
        </tr>


    </table>

    <?php
}

add_filter('manage_pp-client_posts_columns', function($columns) {
    unset($columns['date']);

    $columns['title'] = 'Client Name';



    return array_merge($columns, ['refferer' => __('Borrwer Refferer', 'textdomain')]);
});

add_action('manage_pp-client_posts_custom_column', function($column_key, $post_id) {
    if ($column_key == 'refferer') {


        $pp_cosigner_id = get_post_meta($post_id, 'pp_cosigner_id', true);
        $pp_cosigner_id = isset($pp_cosigner_id) && $pp_cosigner_id != '' ? $pp_cosigner_id : '';

        $cosigner_post_id = get_user_meta($pp_cosigner_id, 'cosigner_post_id', true);

        $cosigner_name = get_post_meta($cosigner_post_id, 'your_name', true);

        $cosigner_email = get_post_meta($cosigner_post_id, 'your_email', true);



        echo '<strong><a class="row-title" target="__blank" href="' . get_edit_post_link($cosigner_post_id) . '" >' . $cosigner_name . ' ( ' . $cosigner_email . ' ) ' . '</a></strong>';
    }
}, 10, 2);
