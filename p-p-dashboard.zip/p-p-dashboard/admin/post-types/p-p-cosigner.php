<?php

// Register Custom Post Type Cosigner
function create_cosigner_cpt() {

    $labels = array(
        'name' => _x('Cosigners', 'Post Type General Name', 'p-p-dashboard'),
        'singular_name' => _x('Cosigner', 'Post Type Singular Name', 'p-p-dashboard'),
        'menu_name' => _x('Cosigners', 'Admin Menu text', 'p-p-dashboard'),
        'name_admin_bar' => _x('Cosigner', 'Add New on Toolbar', 'p-p-dashboard'),
        'archives' => __('Cosigner Archives', 'p-p-dashboard'),
        'attributes' => __('Cosigner Attributes', 'p-p-dashboard'),
        'parent_item_colon' => __('Parent Cosigner:', 'p-p-dashboard'),
        'all_items' => __('All Cosigners', 'p-p-dashboard'),
        'add_new_item' => __('Add New Cosigner', 'p-p-dashboard'),
        'add_new' => __('Add New', 'p-p-dashboard'),
        'new_item' => __('New Cosigner', 'p-p-dashboard'),
        'edit_item' => __('Edit Cosigner', 'p-p-dashboard'),
        'update_item' => __('Update Cosigner', 'p-p-dashboard'),
        'view_item' => __('View Cosigner', 'p-p-dashboard'),
        'view_items' => __('View Cosigners', 'p-p-dashboard'),
        'search_items' => __('Search Cosigner', 'p-p-dashboard'),
        'not_found' => __('Not found', 'p-p-dashboard'),
        'not_found_in_trash' => __('Not found in Trash', 'p-p-dashboard'),
        'featured_image' => __('Featured Image', 'p-p-dashboard'),
        'set_featured_image' => __('Set featured image', 'p-p-dashboard'),
        'remove_featured_image' => __('Remove featured image', 'p-p-dashboard'),
        'use_featured_image' => __('Use as featured image', 'p-p-dashboard'),
        'insert_into_item' => __('Insert into Cosigner', 'p-p-dashboard'),
        'uploaded_to_this_item' => __('Uploaded to this Cosigner', 'p-p-dashboard'),
        'items_list' => __('Cosigners list', 'p-p-dashboard'),
        'items_list_navigation' => __('Cosigners list navigation', 'p-p-dashboard'),
        'filter_items_list' => __('Filter Cosigners list', 'p-p-dashboard'),
    );
    $args = array(
        'label' => __('Cosigner', 'p-p-dashboard'),
        'description' => __('responsible for all cosigner data while signup and waiting approval by the admin', 'p-p-dashboard'),
        'labels' => $labels,
        'menu_icon' => 'dashicons-businessperson',
        'supports' => array('title'),
        'taxonomies' => array(),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => false,
        'exclude_from_search' => false,
        'show_in_rest' => true,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type('pp-cosigner', $args);
}

add_action('init', 'create_cosigner_cpt', 0);

/**
 * Register meta boxes.
 */
add_action('add_meta_boxes', 'register_cosigner_metaboxes');

function register_cosigner_metaboxes() {
    add_meta_box('cosigner-user-info', __('User Information', 'textdomain'), 'co_signer_user_information', 'pp-cosigner', 'advanced', 'high');
    add_meta_box('cosigner-business-info', __('Business Information', 'textdomain'), 'co_signer_business_information', 'pp-cosigner', 'advanced', 'high');
    add_meta_box('cosigner-user-docs', __('User Documents', 'textdomain'), 'co_signer_user_docs', 'pp-cosigner', 'advanced', 'high');
    add_meta_box('cosigner-user-reject', __('User Rejection', 'textdomain'), 'co_signer_user_rejection', 'pp-cosigner', 'side', 'high');
}

/**
 * Meta box display callbac
 *
 */
function co_signer_user_information($post) {

//    echo '<pre>';
//    print_r(get_post_meta($post->ID));
//    echo '</pre>';


    $your_name = get_post_meta($post->ID, 'your_name', true);
    $your_name = isset($your_name) && $your_name != '' ? $your_name : '';

    $your_email = get_post_meta($post->ID, 'your_email', true);
    $your_email = isset($your_email) && $your_email != '' ? $your_email : '';

    $your_address = get_post_meta($post->ID, 'your_address', true);
    $your_address = isset($your_address) && $your_address != '' ? $your_address : '';

    $your_dob = get_post_meta($post->ID, 'your_dob', true);
    $your_dob = isset($your_dob) && $your_dob != '' ? $your_dob : '';

    $your_phone = get_post_meta($post->ID, 'your_phone', true);
    $your_phone = isset($your_phone) && $your_phone != '' ? $your_phone : '';
    ?>

    <table id="customers">
        <tr>
            <th>Data</th>
            <th>Values</th>
        </tr>
        <tr>
            <td>User Name</td>
            <td><?php echo $your_name; ?></td>
        </tr>

        <tr>
            <td>User Email</td>
            <td><?php echo $your_email; ?></td>
        </tr>

        <tr>
            <td>User Address</td>
            <td><?php echo $your_address; ?></td>
        </tr>

        <tr>
            <td>User Date of Birth</td>
            <td><?php echo $your_dob; ?></td>
        </tr>

        <tr>
            <td>User Phone Number</td>
            <td><?php echo $your_phone; ?></td>
        </tr>

    </table>



    <?php
}

/*
 * Business Information
 * 
 */

function co_signer_business_information($post) {


    $business_name = get_post_meta($post->ID, 'business_name', true);
    $business_name = isset($business_name) && $business_name != '' ? $business_name : '';

    $business_address = get_post_meta($post->ID, 'business_address', true);
    $business_address = isset($business_address) && $business_address != '' ? $business_address : '';

    $business_position = get_post_meta($post->ID, 'business_position', true);
    $business_position = isset($business_position) && $business_position != '' ? $business_position : '';

    $basic_salary = get_post_meta($post->ID, 'basic_salary', true);
    $basic_salary = isset($basic_salary) && $basic_salary != '' ? $basic_salary : '';

    $getpaid = get_post_meta($post->ID, 'getpaid', true);
    $getpaid = isset($getpaid) && $getpaid != '' ? $getpaid : '';

    $job_duration = get_post_meta($post->ID, 'job_duration', true);
    $job_duration = isset($job_duration) && $job_duration != '' ? $job_duration : '';

    $hiring_party_mail = get_post_meta($post->ID, 'hiring_party_mail', true);
    $hiring_party_mail = isset($hiring_party_mail) && $hiring_party_mail != '' ? $hiring_party_mail : '';

    $hiring_party_phone = get_post_meta($post->ID, 'hiring_party_phone', true);
    $hiring_party_phone = isset($hiring_party_phone) && $hiring_party_phone != '' ? $hiring_party_phone : '';

    $bank_money = get_post_meta($post->ID, 'bank_money', true);
    $bank_money = isset($bank_money) && $bank_money != '' ? $bank_money : '';
    
    ?>

    <table id="customers">
        <tr>
            <th>Data</th>
            <th>Values</th>
        </tr>
        <tr>
            <td>Business Name</td>
            <td><?php echo $business_name; ?></td>
        </tr>

        <tr>
            <td>Business Address</td>
            <td><?php echo $business_address; ?></td>
        </tr>

        <tr>
            <td>Business Position</td>
            <td><?php echo $business_position; ?></td>
        </tr>

        <tr>
            <td>Basic Salary</td>
            <td><?php echo $basic_salary; ?></td>
        </tr>

        <tr>
            <td>How often You get paid</td>
            <td><?php echo $getpaid; ?></td>
        </tr>

        <tr>
            <td>Length of time in months worked on job</td>
            <td><?php echo $job_duration; ?></td>
        </tr>

        <tr>
            <td>Hiring Party Email</td>
            <td><?php echo $hiring_party_mail; ?></td>
        </tr>

        <tr>
            <td>Phone Number of Hiring Party</td>
            <td><?php echo $hiring_party_phone; ?></td>
        </tr>

        <tr>
            <td>Money in The Bank</td>
            <td><?php echo $bank_money; ?></td>
        </tr>

    </table>

    <?php
}

/*
 * Documents Information
 * 
 */

function co_signer_user_docs($post) {


    $pp_uploads_files = get_post_meta($post->ID, 'pp_uploads_files', true);
    $pp_uploads_files = isset($pp_uploads_files) && $pp_uploads_files != '' ? $pp_uploads_files : '';


    if (isset($pp_uploads_files) && $pp_uploads_files != '') {
        ?>
        <div class="pp-admin-docs">
            <?php
            foreach ($pp_uploads_files as $key => $attach_id) {

                $attach_url = wp_get_attachment_url($attach_id);
                $attach_title = get_the_title($attach_id);
                ?>

                <div class="pp-doc-item">
                    <a href="<?php echo $attach_url; ?>" target="__blank">
                        <img height="100" width="80" src="<?php echo P_P_DASHBOARD_PLUGIN_URL; ?>/admin/images/pdf-file.png" alt="" />
                        <h4><?php echo $attach_title; ?></h4>
                    </a>
                </div>

                <?php
            }
            ?>
        </div>
        <?php
    } else {
        ?>
        <div class="pp-admin-docs">
            <div class="pp-doc-item">
                <h4>There is no file to display</h4>
            </div>
        </div>
        <?php
    }
}

/*
 * User Rejection
 * 
 */

function co_signer_user_rejection($post) {


    $business_name = get_post_meta($post->ID, 'business_name', true);
    $business_name = isset($business_name) && $business_name != '' ? $business_name : '';
    ?>

<table id="customers">        
           
        <tr><td><textarea style="width: 100%;" name="pp_reject_reason" id="pp_reject_reason" rows="8" placeholder="Reject Reason"></textarea></td></tr>
        <tr><td><a href="javascript:void(0)" id="send-reject-mail" class="button button-primary button-large"> Reject User </a></td></tr>
        <tr><input type="hidden" id="pp-ajx-url" value="<?php echo admin_url('admin-ajax.php');?>" /></tr>
    </table>

    <?php
}

add_filter('gettext', 'change_publish_button', 10, 2);

function change_publish_button($translation, $text) {
    if ('pp-cosigner' == get_post_type())
        if ($text == 'Publish')
            return 'Approve User';
    return $translation;
}

add_action('transition_post_status', function ( $new_status, $old_status, $post ) {

    if ($old_status == 'pending' && $new_status == 'publish' && get_post_type($post->ID) == 'pp-cosigner') {

        $cosigner_id = get_post_meta($post->ID, 'cosigner_user_id', true);
        update_user_meta($cosigner_id, 'cosigner_user_status', 'approved');
        
    }
    
    if ($old_status == 'draft' && $new_status == 'publish' && get_post_type($post->ID) == 'pp-cosigner') {

        $cosigner_id = get_post_meta($post->ID, 'cosigner_user_id', true);
        update_user_meta($cosigner_id, 'cosigner_user_status', 'approved');
        
    }
    
    
}, 10, 3);

