(function($) {
    // 'use strict';

    /**
     * All of the code for your public-facing JavaScript source
     * should reside in this file.
     *
     * Note: It has been assumed you will write jQuery code here, so the
     * $ function reference has been prepared for usage within the scope
     * of this function.
     *
     * This enables you to define handlers, for when the DOM is ready:
     *
     * $(function() {
     *
     * });
     *
     * When the window is loaded:
     *
     * $( window ).load(function() {
     *
     * });
     *
     * ...and/or other possibilities.
     *
     * Ideally, it is not considered best practise to attach more than a
     * single DOM-ready or window-load handler for a particular page.
     * Although scripts in the WordPress core, Plugins and Themes may be
     * practising this, we should strive to set a better example in our own work.
     */





    $(document).ready(function() {




        //        resetForm = () => {
        //            document.getElementById("regForm").reset();
        //        };
        validateForm = () => {
            // This function deals with validation of the form fields
            var tab, input, i, valid = true;

            tab = document.getElementsByClassName("tab");
            input = tab[currentTab].getElementsByTagName("input");
            // A loop that checks every input field in the current tab:
            for (i = 0; i < input.length; i++) {

                // If a field is empty...
                if (input[i].value == "") {
                    // add an "invalid" class to the field:
                    input[i].className += " invalid";
                    // and set the current valid status to false
                    valid = false;

                    //return valid;
                }

                if (input[i].type == "email") {

                    if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(input[i].value))) {

                        input[i].className += " invalid";
                        valid = false;
                    }

                    //return valid;

                }






            }

            return valid; // return the valid status
        };
        showTab = (n) => {

            if (n == 0) {
                document.getElementById('needed-documents').style.display = "flex";
                document.getElementById("ppBtnBottom0").style.marginTop = "172px";
                //                document.getElementById("nextBtn").innerHTML = "Apply For Account";
                //                document.getElementById("prevBtn").innerHTML = "Cancel";
            } else if (n == 1) {
                document.getElementById('needed-documents').style.display = "none";
                document.getElementById("ppBtnBottom1").style.marginTop = "132px";
                //                document.getElementById("nextBtn").innerHTML = "Continue";
                //                document.getElementById("prevBtn").innerHTML = "Back";
            } else if (n == 2) {
                document.getElementById('needed-documents').style.display = "none";
                document.getElementById("ppBtnBottom2").style.marginTop = "132px";
                //                document.getElementById("nextBtn").innerHTML = "Continue";
                //                document.getElementById("prevBtn").innerHTML = "Back";

            } else if (n == 3) {
                document.getElementById('needed-documents').style.display = "none";
                document.getElementById("ppBtnBottom3").style.marginTop = "132px";
                jQuery("#nextBtn").addClass('co-signer-submit');
                //                document.getElementById("nextBtn").innerHTML = "Submit";
                //                document.getElementById("prevBtn").innerHTML = "Back";
            }

            //if (n > 3) return false;

            var tab = document.getElementsByClassName("tab")[n];
            //            if (n > 3) return false;
            tab.style.display = "block";

            // resetForm();
        };

        nextPrev = (n) => {
            var tab = document.getElementsByClassName("tab");

            // VALIDATION
            if (n == 1 && !validateForm())
                return false;

            //            if (!(tab.length > 0)) {
            //                return false;
            //            }

            //if (n > 3) return false;
            //            if(n > 4){
            //                return;
            //            }else{
            if (n > 3) {
                return;
            } else {
                tab[currentTab].style.display = "none";
                currentTab = currentTab + n;
            }

            //            }

            //            if (currentTab >= tab.length) {
            //
            //                document.getElementById("regForm").submit();
            //                return false;
            //            }

            showTab(currentTab);
        };
        var currentTab = 0;
        showTab(currentTab);
    });


})(jQuery);