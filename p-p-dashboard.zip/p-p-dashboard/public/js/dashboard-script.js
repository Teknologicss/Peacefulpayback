(function($) {


    $(document).ready(function() {


        function loading() {
            document.querySelectorAll(".bar").forEach(function(current) {
                let startWidth = 0;
                const endWidth = current.dataset.size;

                /* 
                 setInterval() time sholud be set as trasition time / 100. 
                 In our case, 2 seconds / 100 = 20 milliseconds. 
                 */
                const interval = setInterval(frame, 20);

                function frame() {
                    if (startWidth >= endWidth) {
                        clearInterval(interval);
                    } else {
                        startWidth++;
                        current.style.width = `${endWidth}%`;
                        current.firstElementChild.innerText = `${startWidth}%`;
                    }
                }
            });
        }

        setTimeout(loading, 1000);
        $(document).ready(function() {
            //   upcoming training slider


            if (jQuery('.pp-upcomming-Swiper').length > 0) {
                var swiper = new Swiper(".pp-upcomming-Swiper", {
                    slidesPerView: 1,
                    spaceBetween: 20,
                    breakpoints: {
                        640: {
                            slidesPerView: 1.1,
                            spaceBetween: 20
                        },
                        899: {
                            slidesPerView: 1.3,
                            spaceBetween: 20
                        },
                        1025: {
                            slidesPerView: 2,
                            spaceBetween: 20
                        },
                        1200: {
                            slidesPerView: 2.1,
                            spaceBetween: 30
                        }
                    },
                    loop: true,
                    speed: 3000,
                    allowTouchMove: true,
                    allowSlideNext: true,
                    allowSlidePrev: true,
                    autoplay: {
                        delay: 3000,
                    },
                });
            }




            //   end upcoming training slider
        });

        //                var $content = $('.main-container');
        //
        //                function showContent(type) {
        //                    $content.hide().filter('.' + type).show();
        //                }
        //        
        //                $('.nav_list').on('click', '.nav_link', function (e) {
        //                    showContent(e.currentTarget.hash.slice(1));
        //                    e.preventDefault();
        //                });

        //showContent('dashboard');

        // popups validations and js



        //        resetForm = () => {
        //            document.getElementById("addClientForm").reset();
        //        };

        validateForm = () => {
            // This function deals with validation of the form fields
            var x, y, i, valid = true;

            x = document.getElementsByClassName("tabs");
            y = x[currentTab].getElementsByTagName("input");
            // A loop that checks every input field in the current tab:
            for (i = 0; i < y.length; i++) {
                // If a field is empty...
                if (y[i].value == "") {
                    // add an "invalid" class to the field:
                    y[i].className += " invalid";
                    // and set the current valid status to false
                    valid = false;
                }

                if (y[i].type == "email") {

                    if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(y[i].value))) {

                        y[i].className += " invalid";
                        valid = false;
                    }

                    //return valid;

                }



            }
            // If the valid status is true, mark the step as finished and valid:
            //   if (valid) {
            //     document.getElementsByClassName("step")[currentTab].className += " finish";
            //   }
            return valid; // return the valid status
        };

        showPopupTab = (n) => {


            if (jQuery('.tabs').length > 0) {


                var x = document.getElementsByClassName("tabs")[n];
                x.style.display = "block";

                if (n == 0) {
                    document.getElementById("prevBtn").style.display = "inline";
                    document.getElementById("pp-about-form").style.display = "none";
                    document.getElementById("inner-text").innerHTML = "Your Work Information";

                }
                //                    else {
                //                        document.getElementById("prevBtn").style.display = "inline";
                //                        document.getElementById("inner-text").innerHTML = "Your Business Information (s)";
                //                    }
                //if (n == (x.length - 1)) {
                if (n == 1) {
                    document.getElementById("prevBtn").style.display = "inline";
                    document.getElementById("inner-text").innerHTML = "Your Personal Information (s)";
                }
                //                    else {
                //                        document.getElementById("nextBtn").innerHTML = "Add Borrower";
                //                        document.getElementById("prevBtn").innerHTML = "Back";
                //                    }
                //resetForm();

            }

        };

        popNextPrev = (n) => {
            var x = document.getElementsByClassName("tabs");

            // VALIDATION
            //if (n == 1 && !validateForm()) return false;

            x[currentTab].style.display = "none";

            currentTab = currentTab + n;

            //                    if (currentTab >= x.length) {
            //        
            //                        document.getElementById("addClientForm").submit();
            //                        return false;
            //                    }

            showPopupTab(currentTab);
        };
        var currentTab = 0;
        showPopupTab(currentTab);


        if (screen.width > 991) {

            if (document.getElementById("right-search") !== null) {
                document.getElementById("right-search").style.display = "block";
            }

        }
        // search bar togler

        const openSearchDropdown = () => {

            document.getElementById("right-search").style.display = "block";
            document.getElementById("close").style.display = "block";
            document.getElementById("open").style.display = "none";
        }

        const closeSearchDropdown = () => {

            document.getElementById("right-search").style.display = "none";
            document.getElementById("open").style.display = "block";
            document.getElementById("close").style.display = "none";

        }

    });

})(jQuery);