(function($) {

    /*
     * responsible for Routing APIS
     */


    var loader_icon = '<i class="bx bx-loader-circle bx-spin bx-rotate-90"></i>';
    var content_loader = '<div class="pp-loader"><div class="container"><div class="loader"><div class="loader-shap"></div><div class="loader-shap"></div><div class="loader-shap"></div></div></div></div>';


    /*
     * Bowrer signup
     */

    $(document).on('click', '.pp-sb-borrower', function(e) {

        e.preventDefault();

        var this_obj = jQuery(this);

        var old_text = this_obj.html();
        this_obj.html(loader_icon);
        this_obj.prop("disabled", true);


        var borrower_data = new FormData();

        borrower_data.append('borrower_data', $("form#pp-add-borrower").serialize());
        borrower_data.append('nonce', pp_globals.nonce);

        jQuery.ajax({
            url: pp_globals.root + 'add-borrower',
            method: 'POST',
            data: borrower_data,
            dataType: 'json',
            crossDomain: true,
            cache: false,
            enctype: 'multipart/form-data',
            async: true,
            processData: false,
            contentType: false,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },

        }).done(function(response) {

            if (response.status == 'error') {

                Message.add(response.message, { type: 'error', skin: 'ico-medium' });
                this_obj.html(old_text);
                this_obj.prop("disabled", false);

                return false;

            }

            if (response.status == 'success') {

                Message.add(response.message, { type: 'success', skin: 'ico-medium' });
                this_obj.html(old_text);
                this_obj.prop("disabled", false);
                jQuery("#pp-add-borrower")[0].reset();
                jQuery('.btn-close').trigger('click');

            }

        });

    });

    $(document).ready(function() {
        const queryString = window.location.search;

        const urlParams = new URLSearchParams(queryString);

        const page_type = urlParams.get('act')


        if (typeof page_type !== 'undefined' && page_type != null && page_type == 'non-cosigner') {

            Message.add("Please signin as a cosigner to access the dashboard.", { type: 'error', skin: 'ico-medium' });

        }

        /*
         * Add dropdown menu class
         */

        $(document).on('click', '.pp-user-tog', function(e) {

            jQuery('.logout-drop').toggleClass('active');

        });


    });

    $(document).on('click', '#pp-submit-signin', function(e) {

        e.preventDefault();

        var this_obj = jQuery(this);
        var old_text = this_obj.html();
        this_obj.html(loader_icon);
        this_obj.prop("disabled", true);


        var your_email = jQuery('input[name=your_email]');
        var your_password = jQuery('input[name=your_password]');


        if (typeof your_email.val() === 'undefined' || your_email.val() == '') {
            Message.add("Email field is required", { type: 'error', skin: 'ico-medium' });
            this_obj.html(old_text);
            this_obj.prop("disabled", false);
            return false;
        }

        if (typeof your_email.val() !== 'undefined' && your_email.val() != '') {

            if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(your_email.val()))) {

                Message.add("Provide a valid email address", { type: 'error', skin: 'ico-medium' });
                this_obj.html(old_text);
                this_obj.prop("disabled", false);
                return false;
            }

        }

        if (typeof your_password.val() === 'undefined' || your_password.val() == '') {
            Message.add("Please provide your account secret key.", { type: 'error', skin: 'ico-medium' });
            this_obj.html(old_text);
            this_obj.prop("disabled", false);
            return false;
        }

        var signin_data = new FormData();

        signin_data.append('signin_data', $("form.pp-signin-form").serialize());
        signin_data.append('nonce', pp_globals.nonce);

        jQuery.ajax({
            url: pp_globals.root + 'cosigner-signin',
            method: 'POST',
            data: signin_data,
            dataType: 'json',
            crossDomain: true,
            cache: false,
            enctype: 'multipart/form-data',
            async: true,
            processData: false,
            contentType: false,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },

        }).done(function(response) {

            if (response.status == 'error') {
                Message.add(response.message, { type: 'error', skin: 'ico-medium' });
                this_obj.html(old_text);
                this_obj.prop("disabled", false);
            }

            if (response.status == 'success') {

                Message.add(response.message, { type: 'success', skin: 'ico-medium' });
                window.location = response.redirect;

            }

        });

    });

    $(document).on('click', '.co-signer-submit', function(e) {

        e.preventDefault();

        var this_obj = jQuery(this);


        var old_text = this_obj.html();
        this_obj.html(loader_icon);
        this_obj.prop("disabled", true);

        var valid = true;

        var bank_money = jQuery('input[name=bank_money]');

        if (bank_money.val() == '') {
            bank_money.addClass('invalid');
            valid = false;
        }


        var images_files = jQuery(".pp-hiddenbtn");

        jQuery.each((images_files), function(key, upload_file) {

            if (images_files[key].files.length == 0) {

                Message.add("Please upload all required files in pdf format", { type: 'error', skin: 'ico-medium' });
                valid = false;
                this_obj.html(old_text);
                this_obj.prop("disabled", false);
                return false;

            } else {

                if (images_files[key].files[0].type != 'application/pdf') {
                    Message.add("Files should be in pdf format", { type: 'error', skin: 'ico-medium' });
                    valid = false;
                    this_obj.html(old_text);
                    this_obj.prop("disabled", false);
                    return false;
                }

            }

        });

        if (!valid) {
            this_obj.html(old_text);
            this_obj.prop("disabled", false);
            return false;
        }



        var signup_data = new FormData();

        var images_files = jQuery(".pp-hiddenbtn");

        jQuery.each((images_files), function(key, upload_file) {

            if (images_files[key].files.length > 0) {

                signup_data.append(key, images_files[key].files[0]);
            }

        });

        signup_data.append('cosigner_data', $("form#pp-cosigner-signup").serialize());
        signup_data.append('nonce', pp_globals.nonce);

        jQuery.ajax({
            url: pp_globals.root + 'cosigner-register',
            method: 'POST',
            data: signup_data,
            dataType: 'json',
            crossDomain: true,
            cache: false,
            enctype: 'multipart/form-data',
            async: true,
            processData: false,
            contentType: false,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },

        }).done(function(response) {


            if (response.status == 'error') {

                Message.add(response.message, { type: 'error', skin: 'ico-medium' });
                this_obj.html(old_text);
                this_obj.prop("disabled", false);

                jQuery('.pp-done-last').html(response.html);

                return false;

            }

            if (response.status == 'success') {

                Message.add(response.message, { type: 'success', skin: 'ico-medium' });
                jQuery('form#pp-cosigner-signup').remove();
                jQuery('.pp-done-last').show();

            }

        });



    });


    /*
     * Dashboard Links 
     */



    $(document).on('click', '.pp-dash-link-sidebar .nav_link, .pp-dashboard-nav .pp-go-back, .pp-profile-det, .pp-user-notification, .pp-notify-link, .pp-change-pass', function(e) {


        var this_obj = jQuery(this);

        if (jQuery('.logout-drop').hasClass('active')) {
            jQuery('.logout-drop').removeClass('active');
        }


        var action_val = this_obj.attr('data-action');


        var old_content = jQuery('.main-container').html();
        jQuery('.main-container').html(content_loader);


        jQuery('.pp-dash-link-sidebar .nav_link').removeClass('active');

        this_obj.addClass('active');

        jQuery.ajax({
            url: pp_globals.root + 'dashboard',
            method: 'POST',
            data: {
                action_val: action_val,
                nonce: pp_globals.nonce,
            },
            method: 'POST',
            dataType: 'json',
            crossDomain: true,
            cache: false,
            async: true,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },

        }).done(function(response) {

            if (response.status == 'error') {
                Message.add(response.message, { type: 'error', skin: 'ico-medium' });
                jQuery('.main-container').html(old_content);
                return false;
            }

            if (response.status == 'success') {


                jQuery('.main-container').html(response.content_html);
                jQuery('.pp-dashboard-nav').html(response.nav_html);
                courses_swiper_slider();

            }

        });

    });


    /*
     * Course Detail
     */

    $(document).on('click', '.pp-course-det', function(e) {


        var this_obj = jQuery(this);

        var course_id = this_obj.attr('data-course-id');
        var courser_det_red = this_obj.attr('data-redirect');

        courser_det_red = typeof courser_det_red !== 'undefined' && courser_det_red == 'dashboard' ? 'dashboard' : 'courses';

        jQuery('.main-container').html(content_loader);


        jQuery.ajax({
            url: pp_globals.root + 'course-detail',
            method: 'POST',
            data: {
                course_id: course_id,
                redirection: courser_det_red,
                nonce: pp_globals.nonce,
            },
            method: 'POST',
            dataType: 'json',
            crossDomain: true,
            cache: false,
            async: true,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },

        }).done(function(response) {

            //            if (response.status == 'error') {
            //                Message.add(response.message, {type: 'error', skin: 'ico-medium'});
            //                return false;
            //            }

            //pp_youtube_duration_count();

            if (response.status == 'success') {

                jQuery('.main-container').html(response.content_html);
                jQuery('.pp-dashboard-nav').html(response.nav_html);

                //pp_youtube_duration_count();

                //Message.add(response.message, {type: 'success', skin: 'ico-medium'});
                //                jQuery('.main-container').html(response.html);
                // courses_swiper_slider();

            }

        });

    });



    /*
     * Course Detail
     */

    $(document).on('click', '.pp-forgot-pass', function(e) {

        e.preventDefault();


        var this_obj = jQuery(this);

        var old_text = this_obj.html();
        this_obj.html(loader_icon);
        this_obj.prop("disabled", true);

        var change_pass_data = new FormData();

        change_pass_data.append('password_data', $("form.pp-forgot-form").serialize());
        change_pass_data.append('nonce', pp_globals.nonce);


        jQuery.ajax({
            url: pp_globals.root + 'forgot-password',
            method: 'POST',
            data: change_pass_data,
            dataType: 'json',
            crossDomain: true,
            cache: false,
            enctype: 'multipart/form-data',
            async: true,
            processData: false,
            contentType: false,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },

        }).done(function(response) {

            if (response.status == 'error') {

                Message.add(response.message, { type: 'error', skin: 'ico-medium' });
                this_obj.html(old_text);
                this_obj.prop("disabled", false);
                return false;

            }

            if (response.status == 'success') {

                Message.add(response.message, { type: 'success', skin: 'ico-medium' });
                window.location = response.redirect;
                this_obj.html(old_text);
                this_obj.prop("disabled", false);

            }

        });

    });



    /*
     * Update Password
     */

    $(document).on('click', '.pp-update-pass', function(e) {

        e.preventDefault();


        var this_obj = jQuery(this);

        var old_text = this_obj.html();
        this_obj.html(loader_icon);
        this_obj.prop("disabled", true);

        var change_pass_data = new FormData();

        change_pass_data.append('password_data', $("form.pp-password-update").serialize());
        change_pass_data.append('nonce', pp_globals.nonce);


        jQuery.ajax({
            url: pp_globals.root + 'password-update',
            method: 'POST',
            data: change_pass_data,
            dataType: 'json',
            crossDomain: true,
            cache: false,
            enctype: 'multipart/form-data',
            async: true,
            processData: false,
            contentType: false,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },

        }).done(function(response) {

            if (response.status == 'error') {

                Message.add(response.message, { type: 'error', skin: 'ico-medium' });
                this_obj.html(old_text);
                this_obj.prop("disabled", false);
                return false;

            }

            if (response.status == 'success') {

                Message.add(response.message, { type: 'success', skin: 'ico-medium' });
                window.location = response.redirect;
                this_obj.html(old_text);
                this_obj.prop("disabled", false);

            }

        });

    });




    /*
     * 
     * Youtube Duration Count
     */






    $(document).on('click', '.pp-course-title', function(e) {



        //        var active_course = jQuery(this).attr('data-active-id');
        //
        //        jQuery('.pp-course-data.active').css('display', 'none');
        //        jQuery('.pp-course-data.active').removeClass('active');
        //
        //        jQuery('#' + active_course + '').css('display', 'block');
        //        jQuery('#' + active_course + '').addClass('active');

        jQuery('.main-container').html(content_loader);

        var to_dis_course = jQuery(this).attr('data-active-id');
        var course_id = jQuery(this).attr('data-course-id');


        jQuery.ajax({
            url: pp_globals.root + 'get-course',
            method: 'POST',
            data: {
                display_course: to_dis_course,
                course_id: course_id,
                nonce: pp_globals.nonce,
            },
            method: 'POST',
            dataType: 'json',
            crossDomain: true,
            cache: false,
            async: true,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },
        }).done(function(response) {



            if (response.status == 'success') {

                jQuery('.main-container').html(response.course_html);
                pp_yt_data();
                return false;

            }

        });



    });


    //

    function pp_yt_data() {






    }









    $(document).on('click', '.pp-load-more', function(e) {

        var this_obj = jQuery(this);

        var post_type = this_obj.attr('data-post');
        var post_page = this_obj.attr('data-page');
        var post_offset = this_obj.attr('data-offset');
        var post_number = this_obj.attr('data-number');

        var old_text = this_obj.html();
        this_obj.html(loader_icon);
        this_obj.prop("disabled", true);


        jQuery.ajax({
            url: pp_globals.root + 'load-more',
            method: 'POST',
            data: {
                post_type: post_type,
                page: post_page,
                offset: post_offset,
                number: post_number,
                nonce: pp_globals.nonce,
            },
            method: 'POST',
            dataType: 'json',
            crossDomain: true,
            cache: false,
            async: true,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },
        }).done(function(response) {

            if (response.status == 'error') {
                Message.add(response.message, { type: 'error', skin: 'ico-medium' });

                this_obj.html(old_text);
                this_obj.prop("disabled", false);

                if (response.html == "") {
                    this_obj.remove();
                }

                return false;
            }

            if (response.status == 'success') {

                //Message.add(response.message, {type: 'success', skin: 'ico-medium'});
                //jQuery('.pp-post-content').append(response.html);

                if (post_type == 'pp-meeting') {
                    jQuery('.pp-meating').append(response.html);
                } else {
                    jQuery('.pp-post-content').append(response.html);
                }

                this_obj.attr('data-offset', response.offset);
                this_obj.attr('data-page', response.page);

                this_obj.html(old_text);
                this_obj.prop("disabled", false);

                return false;

            }

        });




    });


    /*
     * PP Functions
     */


    function courses_swiper_slider() {

        if (jQuery('.pp-upcomming-Swiper').length > 0) {
            var swiper = new Swiper(".pp-upcomming-Swiper", {
                slidesPerView: 1,
                spaceBetween: 20,
                breakpoints: {
                    640: {
                        slidesPerView: 1.1,
                        spaceBetween: 20
                    },
                    899: {
                        slidesPerView: 1.3,
                        spaceBetween: 20
                    },
                    1025: {
                        slidesPerView: 2,
                        spaceBetween: 20
                    },
                    1200: {
                        slidesPerView: 2.1,
                        spaceBetween: 30
                    }
                },
                loop: true,
                allowTouchMove: true,
                allowSlideNext: true,
                allowSlidePrev: true,
                autoplay: {
                    delay: 2000,
                },
            });
        }

    }

    /*
     * 
     */


    $(document).on('keyup', '.nosubmit', function(e) {

        var this_obj = jQuery(this);

        var search_key = this_obj.val();

        var old_content = jQuery('.main-container').html();
        jQuery('.main-container').html(content_loader);

        jQuery.ajax({
            url: pp_globals.root + 'search',
            method: 'POST',
            data: {
                search_key: search_key,
                nonce: pp_globals.nonce
            },
            method: 'POST',
            dataType: 'json',
            crossDomain: true,
            cache: false,
            async: true,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },

        }).done(function(response) {



            if (response.status == 'error') {

                Message.add(response.message, { type: 'error', skin: 'ico-medium' });

                return false;

            }

            if (response.status == 'success') {

                jQuery('.main-container').html(response.content_html);
                jQuery('.pp-dashboard-nav').html(response.nav_html);
                return false;

            }

        });



    });


    $(document).on('click', '.update-profile', function(e) {

        e.preventDefault();

        var this_obj = jQuery(this);


        var old_text = this_obj.html();
        this_obj.html(loader_icon);
        this_obj.prop("disabled", true);

        var cosigner_data = new FormData();

        cosigner_data.append('cosigner_data', $("form.pp-profile-update").serialize());
        cosigner_data.append('nonce', pp_globals.nonce);

        jQuery.ajax({
            url: pp_globals.root + 'update-profile',
            method: 'POST',
            data: cosigner_data,
            dataType: 'json',
            crossDomain: true,
            cache: false,
            enctype: 'multipart/form-data',
            async: true,
            processData: false,
            contentType: false,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', pp_globals.nonce);
            },

        }).done(function(response) {


            if (response.status == 'error') {

                Message.add(response.message, { type: 'error', skin: 'ico-medium' });
                this_obj.html(old_text);
                this_obj.prop("disabled", false);

                return false;

            }

            if (response.status == 'success') {

                Message.add(response.message, { type: 'success', skin: 'ico-medium' });
                this_obj.html(old_text);
                this_obj.prop("disabled", false);
                return false;

            }

        });



    });



    /*
     * Client View
     */

    jQuery(document).on('click', '.pp-client-view', function(e) {

        var current_obj = jQuery(this);
        var client_id = jQuery(this).attr('data-client-id');
        var ajax_url = pp_globals.ajax_url;
        jQuery('#ppclientmodal .pp-dis-client').html('<div class="pp-loader client-loader"><div class="container"><div class="loader"><div class="loader-shap"></div><div class="loader-shap"></div><div class="loader-shap"></div></div></div></div>');


        var request = $.ajax({
            url: ajax_url,
            method: "POST",
            data: { client_id: client_id, action: 'pp_client_view', },
            dataType: "json"
        });
        request.done(function(response) {

            if (typeof response.status !== 'undefined' && response.status == 'success') {

                jQuery('#ppclientmodal .pp-dis-client').html(response.html);


            }
            return false;

        });
    });





})(jQuery);