(function($) {
    'use strict';

    $(document).ready(function() {

        if ($('.pp-sign-main').length > 0) {

            $('#shiftnav-toggle-main').remove();

        }

        if ($('.body-pd').length > 0) {

            $('#shiftnav-toggle-main').remove();

        }



        document.addEventListener("DOMContentLoaded", function(event) {

            const showNavbar = (toggleId, navId, bodyId, headerId) => {
                const toggle = document.getElementById(toggleId),
                    nav = document.getElementById(navId),
                    bodypd = document.getElementById(bodyId),
                    headerpd = document.getElementById(headerId)

                // Validate that all variables exist
                if (toggle && nav && bodypd && headerpd) {
                    toggle.addEventListener('click', () => {
                        // show navbar
                        nav.classList.toggle('show')
                            // change icon
                        toggle.classList.toggle('bx-x')
                            // add padding to body
                        bodypd.classList.toggle('body-pd')
                            // add padding to header
                        headerpd.classList.toggle('body-pd')
                    })
                }
            }

            showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header')

            /*===== LINK ACTIVE =====*/
            const linkColor = document.querySelectorAll('.nav_link')

            function colorLink() {
                if (linkColor) {
                    linkColor.forEach(l => l.classList.remove('active'))
                    this.classList.add('active')
                }
            }
            linkColor.forEach(l => l.addEventListener('click', colorLink))

            // Your code to run since DOM is loaded and ready
        });


        jQuery(document).on('change', '.pp-hiddenbtn', function(e) {

            var crt_obj = $(this);

            var crt_obj_id = crt_obj[0].id;

            if (crt_obj[0].files.length > 0) {

                jQuery('label[for=' + crt_obj_id + ']').text(crt_obj[0].files[0].name);
            } else {

                jQuery('label[for=' + crt_obj_id + ']').text('Upload File');

            }
        });


    });

    // search bar togler


})(jQuery);

const openSearchDropdown = () => {

    document.getElementById("right-search").style.display = "block";
    document.getElementById("close").style.display = "block";
    document.getElementById("open").style.display = "none";
}

const closeSearchDropdown = () => {

    document.getElementById("right-search").style.display = "none";
    document.getElementById("open").style.display = "block";
    document.getElementById("close").style.display = "none";
}

// remove notification 

// document.body.addEventListener("mousedown", function(el) {
//     const e = el.target;
//     if (e.nodeName === "SPAN") {
//         e.parentNode.style.opacity = 0; /* fade transition for fun */
//         setTimeout(function() {
//             document.getElementById(e.parentNode.id).remove();
//             document.getElementsByClassName("notification-list ul").innerHTML = "LI " + e.parentNode.id + " removed !";
//             if (document.getElementsByTagName("li").length <= 0) {
//                 document.getElementsByClassName("notification-list ul").innerHTML = "Nothing more to click ;(";
//             }
//         }, 500);
//     }
// });