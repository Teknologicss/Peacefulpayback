<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://www.teknologics.net
 * @since      1.0.0
 *
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/public
 * @author     Joshua Victor <joshua.teknologics@gmail.com>
 */
class P_P_Dashboard_Public {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of the plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

        $this->file_inclusion();
    }

    /*
     * Responsible for file inclusion
     */

    public function file_inclusion() {


        require_once P_P_DASHBOARD_PLUGIN_PATH . '/includes/routes/pp-routes.php';
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in P_P_Dashboard_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The P_P_Dashboard_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.   
         */
        wp_enqueue_style('bootstrap', plugin_dir_url(__FILE__) . 'css/bootstrap.min.css', array(), $this->version, 'all');
        wp_enqueue_style('swiper', plugin_dir_url(__FILE__) . 'css/swiper-bundle.min.css', array(), $this->version, 'all');
        wp_enqueue_style('font-style', plugin_dir_url(__FILE__) . 'css/font-style.css', array(), $this->version, 'all');
        wp_enqueue_style('p-p-signup', plugin_dir_url(__FILE__) . 'css/p-p-signup.css', array(), $this->version, 'all');
        
        wp_enqueue_style('course-detail-style', plugin_dir_url(__FILE__) . 'css/course-detail-style.css', array(), $this->version, 'all');
        wp_enqueue_style('dashboard-font-style', plugin_dir_url(__FILE__) . 'css/dashboard-font-style.css', array(), $this->version, 'all');
        wp_enqueue_style('dashboard-styles', plugin_dir_url(__FILE__) . 'css/dashboard-styles.css', array(), $this->version, 'all');
        
        
        wp_enqueue_style('pp-icon', 'https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css', array(), $this->version, 'all');

        //wp_enqueue_style('p-p-dashboard', plugin_dir_url(__FILE__) . 'css/pp-dashboard.css', array(), $this->version, 'all');
        
        wp_enqueue_style('notific', plugin_dir_url(__FILE__) . 'css/notific.css', array(), $this->version, 'all');
        
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in P_P_Dashboard_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The P_P_Dashboard_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */
        wp_enqueue_script('bootstrap', plugin_dir_url(__FILE__) . 'js/bootstrap.bundle.min.js', array('jquery'), $this->version, false);
        
        
        wp_enqueue_script('dashboard-navbar', plugin_dir_url(__FILE__) . 'js/dashboard-navbar.js', array('jquery'), $this->version, true);
        wp_enqueue_script('dashboard-script', plugin_dir_url(__FILE__) . 'js/dashboard-script.js', array('jquery'), $this->version, false);
        wp_enqueue_script('swiper-bundle.min', plugin_dir_url(__FILE__) . 'js/swiper-bundle.min.js', array('jquery'), $this->version, false);
        
        
        //wp_enqueue_script('pp-youtube-player-api', plugin_dir_url(__FILE__) . 'js/ytplayers-api.js', array('jquery'), $this->version, false);
        
        
        
        if(is_page_template('pp-signup.php')){
            wp_enqueue_script('pp-dashboard', plugin_dir_url(__FILE__) . 'js/p-p-dashboard-public.js', array('jquery'), $this->version, false);
        }
        
        wp_enqueue_script('notific', plugin_dir_url(__FILE__) . 'js/notific.js', array('jquery'), $this->version, false);
        
        wp_enqueue_script('pp-script', plugin_dir_url(__FILE__) . 'js/script.js', array('jquery'), $this->version, true);
        wp_enqueue_script('pp-routes', plugin_dir_url(__FILE__) . 'js/routes.js', array('jquery'), $this->version, true);

        /*
         * Localizing Strings
         */
        wp_localize_script('pp-routes', 'pp_globals', $this->pp_localize_strings('route'));
    }

    function pp_localize_strings($file_type = 'public') {

        $routes_scripts = array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wp_rest'),
            'root' => esc_url_raw(rest_url('/p-p-dashboard/v1/')),
        );


        return $routes_scripts;
    }

}
