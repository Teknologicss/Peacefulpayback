<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.teknologics.net
 * @since      1.0.0
 *
 * @package    P_P_Dashboard
 * @subpackage P_P_Dashboard/public/partials
 */

